// Copyright (c) 2019 Centre Tecnologic de Telecomunicacions de Catalunya (CTTC)
//
// SPDX-License-Identifier: GPL-2.0-only

#include "nr-mac-scheduler-ue-info.h"

#include "ns3/log.h"

#include <algorithm>
#include <cmath>
#include <numeric>

namespace ns3
{

NS_LOG_COMPONENT_DEFINE("NrMacSchedulerUeInfo");

NrMacSchedulerUeInfo::NrMacSchedulerUeInfo(uint16_t rnti, BeamId beamId, const GetRbPerRbgFn& fn)
    : m_rnti(rnti),
      m_beamId(beamId),
      m_getNumRbPerRbg(fn)
{
}

NrMacSchedulerUeInfo::~NrMacSchedulerUeInfo()
{
}

std::vector<uint16_t>&
NrMacSchedulerUeInfo::GetDlRBG(const UePtr& ue)
{
    return ue->m_dlRBG;
}

std::vector<uint16_t>&
NrMacSchedulerUeInfo::GetUlRBG(const UePtr& ue)
{
    return ue->m_ulRBG;
}

std::vector<uint8_t>&
NrMacSchedulerUeInfo::GetDlSym(const UePtr& ue)
{
    return ue->m_dlSym;
}

std::vector<uint8_t>&
NrMacSchedulerUeInfo::GetUlSym(const UePtr& ue)
{
    return ue->m_ulSym;
}

uint8_t&
NrMacSchedulerUeInfo::GetDlMcs(const UePtr& ue)
{
    return ue->m_dlMcs;
}

template <typename T>
uint8_t
ComputeMcs(const NrMacSchedulerUeInfo* ueInfo,
           T NrMacSchedulerUeInfo::SbMcsInfo::* field,
           std::function<uint8_t(double)> postProcessing)
{
    // Compute average field of allocated RBGs
    const auto sum = std::transform_reduce(
        ueInfo->m_dlRBG.begin(),
        ueInfo->m_dlRBG.end(),
        0.0,
        [](auto a, auto b) { return a + b; },
        [ueInfo, field](auto a) {
            return ueInfo->m_dlSbMcsInfo.at(ueInfo->m_rbgToSb.at(a)).*field;
        });
    const auto avg = sum / ueInfo->m_dlRBG.size();
    return postProcessing(avg);
}

uint8_t
NrMacSchedulerUeInfo::GetDlMcs() const
{
    const auto csiMcs = GetDlMcsFromCsi();

    // Outer-loop link adaptation. The CSI-derived MCS above is an open-loop estimate: it is
    // what the UE predicted, on the CSI reference resource, would hit the CQI table's BLER
    // target (TS 38.214 Sect. 5.2.2.1). Any systematic bias in that prediction never corrects
    // itself, because nothing feeds the *measured* error rate back here. m_dlOlla is that
    // missing feedback, driven from first-transmission HARQ outcomes in
    // NrMacSchedulerNs3::ProcessHARQFeedbacks. 3GPP does not specify the loop, so it stays off
    // by default and this function then returns the CSI estimate unchanged.
    if (m_dlOllaMax == 0.0)
    {
        return csiMcs;
    }
    const auto maxMcs = static_cast<int>(m_dlAmc->GetMaxMcs());
    const auto corrected = static_cast<int>(std::lround(csiMcs + m_dlOlla));
    return static_cast<uint8_t>(std::clamp(corrected, 0, maxMcs));
}

std::pair<uint8_t, uint8_t>
NrMacSchedulerUeInfo::UlLinkFor(uint32_t rbs) const
{
    const auto measured = static_cast<uint32_t>(m_ulSinrMeas.size());
    if (!m_ulMcsPerRbs || measured == 0 || rbs == 0 || rbs == measured || !m_ulModel)
    {
        return {m_ulMcs, m_ulCqi.m_wbCqi};
    }
    auto it = m_ulMcsByRbs.find(rbs);
    if (it == m_ulMcsByRbs.end())
    {
        // The measured SINR of the RBs (in turn, for more RBs than were measured), times the
        // share of the UE's power each RB gets now against then
        SpectrumValue sinr(m_ulModel);
        const double scale = static_cast<double>(measured) / rbs;
        const auto bands = std::min<uint32_t>(rbs, m_ulModel->GetNumBands());
        for (uint32_t i = 0; i < bands; ++i)
        {
            sinr[i] = m_ulSinrMeas.at(i % measured) * scale;
        }
        uint8_t mcs = 0;
        const uint8_t cqi = m_ulAmc->CreateCqiFeedbackSiso(sinr, mcs);
        it = m_ulMcsByRbs.emplace(rbs, std::make_pair(mcs, cqi)).first;
    }
    return it->second;
}

uint8_t
NrMacSchedulerUeInfo::GetUlMcsFor(uint32_t rbs) const
{
    int mcs = UlLinkFor(rbs).first;
    if (m_ulOllaMax != 0.0)
    {
        mcs = static_cast<int>(std::lround(mcs + m_ulOlla));
    }
    return static_cast<uint8_t>(std::clamp(mcs, 0, static_cast<int>(m_ulAmc->GetMaxMcs())));
}

uint32_t
NrMacSchedulerUeInfo::GetUlMaxRbs() const
{
    if (!m_ulMcsPerRbs || m_ulSinrMeas.empty() || !m_ulModel)
    {
        return UINT32_MAX;
    }
    if (m_ulMaxRbs == 0)
    {
        // The SINR of each RB falls as the RBs grow: the last count whose CQI is above 0
        const uint32_t bands = m_ulModel->GetNumBands();
        uint32_t most = 1;
        for (uint32_t rbs = 1; rbs <= bands; ++rbs)
        {
            if (UlLinkFor(rbs).second == 0)
            {
                break;
            }
            most = rbs;
        }
        m_ulMaxRbs = most;
    }
    return m_ulMaxRbs;
}

uint32_t
NrMacSchedulerUeInfo::GetUlRbs() const
{
    std::vector<uint16_t> rbgs(m_ulRBG);
    std::sort(rbgs.begin(), rbgs.end());
    rbgs.erase(std::unique(rbgs.begin(), rbgs.end()), rbgs.end());
    return static_cast<uint32_t>(rbgs.size()) * GetNumRbPerRbg();
}

uint8_t
NrMacSchedulerUeInfo::GetDlMcsFromCsi() const
{
    // Return maximum allowed MCS according to Fronthaul control
    if (m_fhMaxMcsAssignable.has_value())
    {
        return m_fhMaxMcsAssignable.value();
    }

    // In case there is no sub-band info or no RBG has been allocated, return the wideband MCS
    if (m_dlSbMcsInfo.empty() || m_dlRBG.empty() || (m_mcsCsiSource == McsCsiSource::WIDEBAND_MCS))
    {
        return m_dlMcs;
    }

    // Otherwise, compute the SINR of allocated RBGs
    switch (m_mcsCsiSource)
    {
    // Estimate MCS based on the average MCS of allocated RBGs
    case McsCsiSource::AVG_MCS: {
        return ComputeMcs(this, &SbMcsInfo::mcs, [](double avg) { return (uint8_t)floor(avg); });
    }
    // Estimate MCS based on the average spectral efficiency of allocated RBGs
    case McsCsiSource::AVG_SPEC_EFF: {
        return ComputeMcs(this,
                          &SbMcsInfo::specEff,
                          std::bind_front(&NrAmc::GetMcsFromSpectralEfficiency, m_dlAmc));
    }
    // Estimate MCS based on the average SINR of allocated RBGs
    case McsCsiSource::AVG_SINR: {
        return ComputeMcs(this, &SbMcsInfo::sinr, [amc = m_dlAmc](double avgSinr) {
            return amc->GetMcsFromSpectralEfficiency(amc->GetSpectralEfficiencyForSinr(avgSinr));
        });
    }
    default:
        NS_ABORT_MSG("Invalid csi source for MCS computation");
    }
}

uint8_t&
NrMacSchedulerUeInfo::GetUlMcs(const UePtr& ue)
{
    return ue->m_ulMcs;
}

uint32_t&
NrMacSchedulerUeInfo::GetDlTBS(const UePtr& ue)
{
    return ue->m_dlTbSize;
}

std::unordered_map<uint8_t, LCGPtr>&
NrMacSchedulerUeInfo::GetDlLCG(const UePtr& ue)
{
    return ue->m_dlLCG;
}

std::unordered_map<uint8_t, LCGPtr>&
NrMacSchedulerUeInfo::GetUlLCG(const UePtr& ue)
{
    return ue->m_ulLCG;
}

NrMacHarqVector&
NrMacSchedulerUeInfo::GetDlHarqVector(const UePtr& ue)
{
    return ue->m_dlHarq;
}

NrMacHarqVector&
NrMacSchedulerUeInfo::GetUlHarqVector(const UePtr& ue)
{
    return ue->m_ulHarq;
}

void
NrMacSchedulerUeInfo::PrintLcInfo(uint16_t ue,
                                  uint8_t lcgId,
                                  uint8_t lcId,
                                  uint8_t fiveQi,
                                  uint8_t P,
                                  uint8_t minP)
{
    NS_LOG_DEBUG("UE " << ue << " LCG ID: " << static_cast<uint32_t>(lcgId) << " LC ID "
                       << static_cast<uint32_t>(lcId) << " QCI: " << static_cast<uint32_t>(fiveQi)
                       << " P: " << static_cast<uint32_t>(P) << " minP: " << +minP);
}

void
NrMacSchedulerUeInfo::ResetDlSchedInfo()
{
    m_dlMRBRetx = 0;
    m_dlRBG.clear();
    m_dlSym.clear();
    m_dlTbSize = 0;
}

void
NrMacSchedulerUeInfo::ResetUlSchedInfo()
{
    m_ulMRBRetx = 0;
    m_ulRBG.clear();
    m_ulSym.clear();
    m_ulTbSize = 0;
}

void
NrMacSchedulerUeInfo::UpdateDlMetric()
{
    if (m_dlRBG.empty())
    {
        m_dlTbSize = 0;
    }
    else
    {
        m_dlTbSize =
            m_dlAmc->CalculateTbSize(GetDlMcs(), m_dlRank, m_dlRBG.size() * GetNumRbPerRbg());
    }
}

void
NrMacSchedulerUeInfo::ResetDlMetric()
{
    m_dlTbSize = 0;
}

void
NrMacSchedulerUeInfo::UpdateUlMetric()
{
    if (m_ulRBG.empty())
    {
        m_ulTbSize = 0;
    }
    else
    {
        m_ulTbSize = m_ulAmc->CalculateTbSize(GetUlMcsFor(GetUlRbs()),
                                              m_ulRank,
                                              m_ulRBG.size() * GetNumRbPerRbg());
    }
}

void
NrMacSchedulerUeInfo::ResetUlMetric()
{
    m_ulTbSize = 0;
}

uint32_t
NrMacSchedulerUeInfo::GetTotalDlBuffer() const
{
    uint32_t totBuffer = 0;
    for (const auto& lcgInfo : m_dlLCG)
    {
        const auto& lcg = lcgInfo.second;
        totBuffer += lcg->GetTotalSize();
    }
    return totBuffer;
}

uint32_t
NrMacSchedulerUeInfo::GetTotalNumDlLc() const
{
    NS_LOG_FUNCTION(this);

    uint32_t total = 0;
    for (const auto& [lcgId, lcg] : m_dlLCG)
    {
        total += lcg->NumOfLC();
    }

    return total;
}

uint32_t
NrMacSchedulerUeInfo::GetTotalNumUlLc() const
{
    NS_LOG_FUNCTION(this);

    uint32_t total = 0;
    for (const auto& [lcgId, lcg] : m_ulLCG)
    {
        total += lcg->NumOfLC();
    }

    return total;
}

uint32_t
NrMacSchedulerUeInfo::GetTotalNumActiveDlLc() const
{
    NS_LOG_FUNCTION(this);

    uint32_t total = 0;
    for (const auto& [lcgId, lcg] : m_dlLCG)
    {
        total += lcg->NumOfActiveLC();
    }

    return total;
}

uint32_t
NrMacSchedulerUeInfo::GetTotalNumActiveUlLc() const
{
    NS_LOG_FUNCTION(this);

    uint32_t total = 0;
    for (const auto& [lcgId, lcg] : m_ulLCG)
    {
        total += lcg->NumOfActiveLC();
    }

    return total;
}

bool
NrMacSchedulerUeInfo::HasPendingDlSignalingTraffic() const
{
    constexpr uint8_t dlSignalingLcgId = 0;
    auto it = m_dlLCG.find(dlSignalingLcgId);
    return it != m_dlLCG.end() && it->second && it->second->GetTotalSize() > 0;
}

uint32_t
NrMacSchedulerUeInfo::GetNumRbPerRbg() const
{
    return m_getNumRbPerRbg();
}

void
NrMacSchedulerUeInfo::ReleaseLC(uint8_t lcid)
{
    for (auto lcgIt = m_dlLCG.begin(); lcgIt != m_dlLCG.end(); lcgIt++)
    {
        lcgIt->second->ReleaseLC(lcid);
    }
    for (auto lcgIt = m_ulLCG.begin(); lcgIt != m_ulLCG.end(); lcgIt++)
    {
        lcgIt->second->ReleaseLC(lcid);
    }
    auto it = m_dlLCG.begin();
    while (it != m_dlLCG.end())
    {
        if (it->second->GetLCId().empty())
        {
            m_dlLCG.erase(it);
            it = m_dlLCG.begin();
        }
        else
        {
            it++;
        }
    }
    it = m_ulLCG.begin();
    while (it != m_ulLCG.end())
    {
        if (it->second->GetLCId().empty())
        {
            m_ulLCG.erase(it);
            it = m_ulLCG.begin();
        }
        else
        {
            it++;
        }
    }
}

} // namespace ns3
