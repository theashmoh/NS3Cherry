// Copyright (c) 2019 Centre Tecnologic de Telecomunicacions de Catalunya (CTTC)
//
// SPDX-License-Identifier: GPL-2.0-only

#pragma once

#include "nr-mac-scheduler-ofdma-symbol-per-beam.h"
#include "nr-mac-scheduler-tdma.h"

#include "ns3/nr-export.h"
#include "ns3/traced-value.h"

#include <set>
#include <unordered_set>

namespace ns3
{
class NrSchedOfdmaSymbolPerBeamTestCase;
class UniformRandomVariable;

/**
 * @ingroup scheduler
 * @brief The base for all the OFDMA schedulers
 *
 * An example of OFDMA-based scheduling is the following:
 * <pre>
 * (f)
 * ^
 * |=|======|=======|=|
 * |C| U  E | U  E  |C|
 * |T|  1   |  3    |T|
 * | |======|=======| |
 * |R| U  E | U  E  |R|
 * |L|  2   |   4   |L|
 * |----------------------------> (t)
 * </pre>
 *
 * The UEs are scheduled by prioritizing the assignment of frequencies: the entire
 * available spectrum is divided among UEs of the same beam, by a number of
 * symbols which is pre-computed and depends on the total byte to transmit
 * of each beam.
 *
 * The OFDMA scheduling is only done in downlink. In uplink, the division in
 * time is used, and therefore the class is based on top of NrMacSchedulerTdma.
 *
 * The implementation details to construct a slot like the one showed before
 * are in the functions AssignDLRBG() and AssignULRBG().
 * The choice of the UEs to be scheduled is, however, demanded to the subclasses.
 *
 * The DCI is created by CreateDlDci() or CreateUlDci(), which call CreateDci()
 * to perform the "hard" work.
 *
 * @see NrMacSchedulerOfdmaRR
 * @see NrMacSchedulerOfdmaPF
 * @see NrMacSchedulerOfdmaMR
 */
class NR_EXPORT NrMacSchedulerOfdma : public NrMacSchedulerTdma
{
  public:
    /**
     * @brief GetTypeId
     * @return The TypeId of the class
     */
    static TypeId GetTypeId();

    /**
     * @brief NrMacSchedulerOfdma constructor
     */
    NrMacSchedulerOfdma();

    /**
     * @brief Deconstructor
     */
    ~NrMacSchedulerOfdma() override;

  protected:
    BeamSymbolMap AssignDLRBG(uint32_t symAvail, const ActiveUeMap& activeDl) const override;
    BeamSymbolMap AssignULRBG(uint32_t symAvail, const ActiveUeMap& activeUl) const override;

    std::shared_ptr<DciInfoElementTdma> CreateDlDci(
        PointInFTPlane* spoint,
        const std::shared_ptr<NrMacSchedulerUeInfo>& ueInfo,
        uint32_t maxSym) const override;
    std::shared_ptr<DciInfoElementTdma> CreateUlDci(
        PointInFTPlane* spoint,
        const std::shared_ptr<NrMacSchedulerUeInfo>& ueInfo,
        uint32_t maxSym) const override;

    /**
     * @brief Advance the starting point by the number of symbols specified,
     * resetting the RB count to 0
     * @param spoint Starting point
     * @param symOfBeam Number of symbols for the beam
     */
    void ChangeDlBeam(PointInFTPlane* spoint, uint32_t symOfBeam) const override;

    void ChangeUlBeam(PointInFTPlane* spoint, uint32_t symOfBeam) const override;

    /**
     * @brief Calculate the number of symbols to assign to each beam by calling using the technique
     * selected in m_symPerBeamType
     * @param symAvail Number of available symbols
     * @param activeDl Map of active DL UE and their beam
     * @return symbols per beam allocation map
     */
    NrMacSchedulerOfdma::BeamSymbolMap GetSymPerBeam(uint32_t symAvail,
                                                     const ActiveUeMap& activeDl) const;

    uint8_t GetTpc() const override;
    uint32_t GetMaxUesPerSlot(uint32_t symAvail) const override;

    /**
     * @brief HARQ retransmissions take resource block groups over the data symbols of the slot,
     * which new data shares (attribute HarqRetxInFrequency)
     */
    bool HarqInFrequency() const override
    {
        return m_harqRetxInFrequency;
    }

    /**
     * @brief Enumeration of techniques to distribute the available symbols to the active beams
     */
    enum class SymPerBeamType
    {
        LOAD_BASED, //!< Distributes symbols to beams proportionally to the buffer size of its users
        ROUND_ROBIN, //!< Distributes all symbols to the first active beam in the m_rrBeams queue
        PROPORTIONAL_FAIR //!< Distributes symbols to beams proportionally to mean achievable rate
    };

    /**
     * @brief Assign OFDMA and parent random streams.
     */
    int64_t AssignStreams(int64_t stream) override;

  private:
    /**
     * @brief Create RBG bitmask from allocated RBG vector
     * @param allocatedRbgs vector of allocated RBGs
     * @return RBG bitmask
     */
    std::vector<bool> CreateRbgBitmaskFromAllocatedRbgs(
        const std::vector<uint16_t>& allocatedRbgs) const;

    /**
     * @brief Advances schedInfoIt iterator to the next UE to be scheduled
     *
     * Iterate all the way from beginning to the end iterators of the vector of UEs to schedule,
     * looking for the first UE that hasn't had scheduled enough resources to fill its entire
     * buffer.
     *
     * In case an UE hasn't had enough resources scheduled, and the fronthaul policy allows
     * (ShouldScheduleUeBasedOnFronthaul), it will be scheduled in the next iteration, returning
     * true.
     *
     * If the fronthaul does now allow it, or there is no UE with more data to transmit, then return
     * false to indicate scheduling has ended for this beam.
     * @param schedInfoIt iterator pointing to the beginning of vector with UEs to be scheduled
     * @param end end iterator of vector of UEs to be scheduled
     * @param resourcesAssignable number of resources that can be scheduled per time (symbols per
     * beam * 1 rbg)
     * @return true in case scheduling should be done for a UE pointed by current schedInfoIt, false
     * in case scheduling for beam should stop
     */
    bool AdvanceToNextUeToSchedule(std::vector<UePtrAndBufferReq>::iterator& schedInfoIt,
                                   const std::vector<UePtrAndBufferReq>::iterator end,
                                   uint32_t resourcesAssignable) const;
    /**
     * @brief Decides whether UE pointed by schedInfoIt should be scheduled based on fronthaul
     * policy
     *
     * @param schedInfoIt iterator pointing to the beginning of vector with UEs to be scheduled
     * @param resourcesAssignable number of resources that can be scheduled per time (symbols per
     * beam * 1 rbg)
     * @return true in case scheduling should be done for a UE pointed by current schedInfoIt, false
     * in case UE should not be scheduled
     */
    bool ShouldScheduleUeBasedOnFronthaul(
        const std::vector<UePtrAndBufferReq>::iterator& schedInfoIt,
        uint32_t resourcesAssignable) const;

    /**
     * @brief Apply fronthaul control policy to constrain allocation post-fact, by deallocating
     * resources
     * @param ueVector Reference to vector of UEs scheduled for a beam
     * @param beamSym Reference to number of resources (symbols per beam * 1 rbg) available
     * @param assignedResources Reference to currently assigned resources (symbols, rbgs)
     * @param availableRbgs Reference to vector of available RBGs
     */
    void DeallocateResourcesDueToFronthaulConstraint(const std::vector<UePtrAndBufferReq>& ueVector,
                                                     const uint32_t& beamSym,
                                                     FTResources& assignedResources,
                                                     std::vector<bool>& availableRbgs) const;
    /**
     * @brief Allocate resources defined by currentRbg (RBG)*beamSym (symbols per beam) from
     * currentUe, then update list of assignedResources and availableRbgs
     * @param currentUe Pointer to UE that should have currentRbg deallocated
     * @param currentRbg RBG to be deallocated
     * @param beamSym Symbols per beam to be deallocated
     * @param assignedResources Reference to total assigned resources
     * @param availableRbgs Reference vector of available RBGs for scheduling
     */
    static void AllocateCurrentResourceToUe(std::shared_ptr<NrMacSchedulerUeInfo> currentUe,
                                            const uint32_t& currentRbg,
                                            const uint32_t beamSym,
                                            FTResources& assignedResources,
                                            std::vector<bool>& availableRbgs);
    /**
     * @brief Deallocate resources defined by currentRbg (RBG)*beamSym (symbols per beam) from
     * currentUe, then update list of assignedResources and availableRbgs
     * @param currentUe Pointer to UE that should have currentRbg deallocated
     * @param currentRbg RBG to be deallocated
     * @param beamSym Symbols per beam to be deallocated
     * @param assignedResources Reference to total assigned resources
     * @param availableRbgs Reference vector of available RBGs for scheduling
     * @param isDl True to deallocate DL resources, false to deallocate UL resources
     */
    static void DeallocateCurrentResourceFromUe(std::shared_ptr<NrMacSchedulerUeInfo> currentUe,
                                                const uint32_t& currentRbg,
                                                const uint32_t beamSym,
                                                FTResources& assignedResources,
                                                std::vector<bool>& availableRbgs,
                                                const bool isDl = true);
    /**
     * @brief Reap the resources of the UE with the smallest TBS, in case that TBS is
     * below the minimum required to create a DCI (10 bytes in DL, 12 bytes in UL, as
     * enforced by CreateDlDci and CreateUlDci), returning them to remainingRbgSet so
     * that they can be redistributed to the other UEs of the same beam. Without this,
     * when the active UEs outnumber the schedulable resources and all of them are at
     * a low MCS, every allocation is discarded at DCI creation and the cell starves.
     * @param ueVector Reference to the vector of UEs of the beam being scheduled
     * @param remainingRbgSet Reference to set of available RBGs to be scheduled
     * @param beamSym Number of symbols per beam to be scheduled
     * @param assignedResources Reference to total assigned resources
     * @param availableRbgs Mask of available RBGs
     * @param isDl True to reap DL resources, false to reap UL resources
     * @return true if a UE was reaped and scheduling should be retried, false otherwise
     */
    bool ReapStarvedUeResources(std::vector<UePtrAndBufferReq>& ueVector,
                                std::set<uint32_t>& remainingRbgSet,
                                const uint32_t beamSym,
                                FTResources& assignedResources,
                                std::vector<bool>& availableRbgs,
                                const bool isDl) const;
    /**
     * @brief Try to schedule the best RBG out of remainingRbgSet to an UE referenced by
     * schedInfoIt, for beamSym symbols, then update the list of assignedResources and availableRbgs
     * @param schedInfoIt Reference to the UE to be scheduled
     * @param remainingRbgSet Reference to set of available RBGs to be scheduled
     * @param beamSym Number of symbols per beam to be scheduled
     * @param assignedResources Number of resources scheduled
     * @param availableRbgs Mask of available RBGs
     * @return true if scheduled, false if not scheduled
     */
    bool AttemptAllocationOfCurrentResourceToUe(
        std::vector<UePtrAndBufferReq>::iterator schedInfoIt,
        std::set<uint32_t>& remainingRbgSet,
        const uint32_t beamSym,
        FTResources& assignedResources,
        std::vector<bool>& availableRbgs) const;

    /**
     * Estimates the total achievable transport block (TB) capacity for a given UE, considering
     * all available resource block groups (RBGs) and the current resource assignment state.
     *
     * This method calculates the maximum possible TB size that can be achieved for the given UE
     * by temporarily allocating all available resources and evaluating the allocation. The result
     * is used to assess if the UE should be scheduled or prioritized based on its potential
     * capacity.
     *
     * @param schedInfoIt Iterator pointing to the scheduling information of the UE within the
     * scheduling container.
     * @param currentUe Shared pointer to the scheduling information object for the current UE.
     * @param availableRbgs Vector representing the availability of resource block groups (RBGs).
     *        Each element indicates whether the corresponding RBG is available for allocation.
     * @param beamSym Number of symbols available in the current beam.
     * @param assignedResources Reference to the structure that tracks the resources currently
     * assigned to UEs during scheduling.
     * @return The maximum transport block size (in bits) that can be achieved for the UE with
     *         the given resources and configurations.
     */
    uint32_t EstimateTotalTbCapacity(
        std::vector<std::pair<std::shared_ptr<ns3::NrMacSchedulerUeInfo>, unsigned int>>::iterator
            schedInfoIt,
        std::shared_ptr<NrMacSchedulerUeInfo> currentUe,
        const std::vector<bool>& availableRbgs,
        const uint32_t beamSym,
        FTResources& assignedResources) const;

    void SetSymPerBeamType(SymPerBeamType type);
    TracedValue<uint32_t>
        m_tracedValueSymPerBeam; //!< Variable to trace symbols per beam allocation

    SymPerBeamType m_symPerBeamType; //!< Holds the type of symbol scheduling done for each beam
    bool m_harqRetxInFrequency{true};                   //!< Attribute HarqRetxInFrequency
    Ptr<NrMacSchedulerOfdmaSymbolPerBeam> m_symPerBeam; //!< Holds a symbol per beam allocator

    mutable Ptr<UniformRandomVariable>
        m_fhRng; //!< Random distribution for fronthaul management shuffling

    /// Make it friend of the test case, so that the test case can access m_symPerBeam
    friend class NrSchedOfdmaSymbolPerBeamTestCase;
    friend class NrSchedOfdmaMcsTestCase;
};
} // namespace ns3
