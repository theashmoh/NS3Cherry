// Copyright (c) 2011 Centre Tecnologic de Telecomunicacions de Catalunya (CTTC)
// Copyright (c) 2015 NYU WIRELESS, Tandon School of Engineering, New York University
// Copyright (c) 2019 Centre Tecnologic de Telecomunicacions de Catalunya (CTTC)
//
// SPDX-License-Identifier: GPL-2.0-only

#define NS_LOG_APPEND_CONTEXT                                                                      \
    do                                                                                             \
    {                                                                                              \
        std::clog << " [ CellId " << GetCellId() << ", bwpId " << GetBwpId() << "] ";              \
    } while (false);

#include "nr-ue-phy.h"

#include "beam-manager.h"
#include "nr-ch-access-manager.h"
#include "nr-pdcch.h"
#include "nr-radio-bearer-tag.h"
#include "nr-ue-net-device.h"
#include "nr-ue-power-control.h"

#include "ns3/boolean.h"
#include "ns3/double.h"
#include "ns3/enum.h"
#include "ns3/log.h"
#include "ns3/node.h"
#include "ns3/pointer.h"
#include "ns3/simulator.h"

#include <algorithm>
#include <cfloat>
#include <cmath>

namespace ns3
{

const Time NR_DEFAULT_PMI_INTERVAL_WB{MilliSeconds(10)}; // Wideband PMI update interval
const Time NR_DEFAULT_PMI_INTERVAL_SB{MilliSeconds(2)};  // Subband PMI update interval

NS_LOG_COMPONENT_DEFINE("NrUePhy");
NS_OBJECT_ENSURE_REGISTERED(NrUePhy);

NrUePhy::NrUePhy()
{
    NS_LOG_FUNCTION(this);
    m_wbCqiLast = Simulator::Now();
    m_ueCphySapProvider = new MemberNrUeCphySapProvider<NrUePhy>(this);
    m_powerControl = CreateObject<NrUePowerControl>(this);
    m_isConnected = false;
    Simulator::Schedule(m_ueMeasurementsFilterPeriod, &NrUePhy::ReportUeMeasurements, this);
}

NrUePhy::~NrUePhy()
{
    NS_LOG_FUNCTION(this);
}

void
NrUePhy::DoDispose()
{
    NS_LOG_FUNCTION(this);
    delete m_ueCphySapProvider;
    m_nextSlotEvent.Cancel();
    m_ctrlMsgsForSlot.clear();
    if (m_powerControl)
    {
        m_powerControl->Dispose();
        m_powerControl = nullptr;
    }
    if (m_cam)
    {
        m_cam->Dispose();
        m_cam = nullptr;
    }
    NrPhy::DoDispose();
}

TypeId
NrUePhy::GetTypeId()
{
    static TypeId tid =
        TypeId("ns3::NrUePhy")
            .SetParent<NrPhy>()
            .AddConstructor<NrUePhy>()
            .AddAttribute("TxPower",
                          "Transmission power in dBm",
                          DoubleValue(2.0),
                          MakeDoubleAccessor(&NrUePhy::m_txPower),
                          MakeDoubleChecker<double>())
            .AddAttribute(
                "NoiseFigure",
                "Loss (dB) in the Signal-to-Noise-Ratio due to non-idealities in the receiver."
                " According to Wikipedia (http://en.wikipedia.org/wiki/Noise_figure), this is "
                "\"the difference in decibels (dB) between"
                " the noise output of the actual receiver to the noise output of an "
                " ideal receiver with the same overall gain and bandwidth when the receivers "
                " are connected to sources at the standard noise temperature T0.\" "
                "In this model, we consider T0 = 290K.",
                DoubleValue(5.0), // nr code from NYU and UniPd assumed in the code the value of
                                  // 5dB, that is why we configure the default value to that
                MakeDoubleAccessor(&NrPhy::SetNoiseFigure, &NrPhy::GetNoiseFigure),
                MakeDoubleChecker<double>())
            .AddAttribute(
                "PowerAllocationType",
                "Defines the type of the power allocation. Currently are supported "
                "two types: \"UniformPowerAllocBw\", which is a uniform power allocation over all "
                "bandwidth (over all RBs), and \"UniformPowerAllocBw\", which is a uniform "
                "power allocation over used (active) RBs. By default is set a uniform power "
                "allocation over used RBs .",
                EnumValue(NrSpectrumValueHelper::UNIFORM_POWER_ALLOCATION_USED),
                MakeEnumAccessor<NrSpectrumValueHelper::PowerAllocationType>(
                    &NrPhy::SetPowerAllocationType,
                    &NrPhy::GetPowerAllocationType),
                MakeEnumChecker(NrSpectrumValueHelper::UNIFORM_POWER_ALLOCATION_BW,
                                "UniformPowerAllocBw",
                                NrSpectrumValueHelper::UNIFORM_POWER_ALLOCATION_USED,
                                "UniformPowerAllocUsed"))
            .AddAttribute("SpectrumPhy",
                          "The SpectrumPhy associated to this NrPhy",
                          TypeId::ATTR_GET,
                          PointerValue(),
                          MakePointerAccessor(&NrPhy::GetSpectrumPhy),
                          MakePointerChecker<NrSpectrumPhy>())
            .AddAttribute("LBTThresholdForCtrl",
                          "After a DL/UL transmission, if we have less than this value to send the "
                          "UL CTRL, we consider the channel as granted",
                          TimeValue(MicroSeconds(25)),
                          MakeTimeAccessor(&NrUePhy::m_lbtThresholdForCtrl),
                          MakeTimeChecker())
            .AddAttribute("TbDecodeLatency",
                          "Transport block decode latency",
                          TimeValue(MicroSeconds(100)),
                          MakeTimeAccessor(&NrPhy::SetTbDecodeLatency, &NrPhy::GetTbDecodeLatency),
                          MakeTimeChecker())
            .AddAttribute(
                "TimingAdvance",
                "Ideal timing advance: the UE's estimate of the one-way propagation delay to its "
                "serving gNB (a Rel-17 NTN UE derives it from GNSS and the SIB19 ephemeris). The "
                "UE's slot clock runs this much ahead of the gNB's, so every uplink transmission "
                "(data, control, SRS, PRACH) reaches the gNB in the slot it was scheduled for, "
                "and the slot offsets carried by downlink messages (K1, K2, the Msg3 grant) are "
                "counted from the gNB slot that carried them. Can be changed at run time. Zero "
                "keeps the terrestrial timeline. In FDD set it on every BWP PHY of the UE.",
                TimeValue(Seconds(0)),
                MakeTimeAccessor(&NrUePhy::SetTimingAdvance, &NrUePhy::GetTimingAdvance),
                MakeTimeChecker(Seconds(0)))
            .AddAttribute("EnableUplinkPowerControl",
                          "If true, Uplink Power Control will be enabled.",
                          BooleanValue(false),
                          MakeBooleanAccessor(&NrUePhy::SetEnableUplinkPowerControl),
                          MakeBooleanChecker())
            .AddAttribute("WbPmiUpdateInterval",
                          "Wideband PMI update interval",
                          TimeValue(NR_DEFAULT_PMI_INTERVAL_WB),
                          MakeTimeAccessor(&NrUePhy::m_wbPmiUpdateInterval),
                          MakeTimeChecker())
            .AddAttribute("SbPmiUpdateInterval",
                          "Subband PMI update interval",
                          TimeValue(NR_DEFAULT_PMI_INTERVAL_SB),
                          MakeTimeAccessor(&NrUePhy::m_sbPmiUpdateInterval),
                          MakeTimeChecker())
            .AddAttribute("AlphaCovMat",
                          "The alpha parameter for the calculation of the interference covariance "
                          "matrix moving average",
                          DoubleValue(1),
                          MakeDoubleAccessor(&NrUePhy::SetAlphaCovMat, &NrUePhy::GetAlphaCovMat),
                          MakeDoubleChecker<double>(0.0, 1))
            .AddAttribute(
                "CsiImDuration",
                "CSI-IM duration in the number of OFDM symbols",
                UintegerValue(1),
                MakeUintegerAccessor(&NrUePhy::SetCsiImDuration, &NrUePhy::GetCsiImDuration),
                MakeUintegerChecker<uint8_t>(1, 12))
            // The reported value is NrUePhy::ComputeAvgSinr(): a linear SINR (apply 10*log10() for
            // dB) averaged over the RBs of the received PDSCH. Fired only in SISO CQI feedback
            // configurations (CsiFeedbackFlags = CQI_PDSCH_SISO, or a channel without a
            // phased-array loss model): the value is the per-RB C/(I+N) computed by NrInterference
            // (noise included), emitted at the end of each PDSCH data reception, and feeds the SISO
            // wideband CQI. MIMO CSI feedback configurations do not fire this trace; see
            // CqiFeedbackTrace.
            .AddTraceSource("DlDataSinr",
                            "Effective DL data SINR used for CQI/CSI feedback, reported as a "
                            "linear ratio (not dB) averaged over the allocated RBs.",
                            MakeTraceSourceAccessor(&NrUePhy::m_dlDataSinrTrace),
                            "ns3::NrUePhy::DlDataSinrTracedCallback")
            .AddTraceSource("DlCtrlSinr",
                            "Report the SINR computed for DL CTRL",
                            MakeTraceSourceAccessor(&NrUePhy::m_dlCtrlSinrTrace),
                            "ns3::NrUePhy::DlCtrlSinrTracedCallback")
            .AddAttribute("UeMeasurementsFilterPeriod",
                          "Time period for reporting UE measurements, i.e., the"
                          "length of layer-1 filtering.",
                          TimeValue(MilliSeconds(200)),
                          MakeTimeAccessor(&NrUePhy::m_ueMeasurementsFilterPeriod),
                          MakeTimeChecker())
            .AddTraceSource("ReportUplinkTbSize",
                            "Report allocated uplink TB size for trace.",
                            MakeTraceSourceAccessor(&NrUePhy::m_reportUlTbSize),
                            "ns3::UlTbSize::TracedCallback")
            .AddTraceSource("ReportDownlinkTbSize",
                            "Report allocated downlink TB size for trace.",
                            MakeTraceSourceAccessor(&NrUePhy::m_reportDlTbSize),
                            "ns3::DlTbSize::TracedCallback")
            .AddTraceSource("ReportRsrp",
                            "RSRP statistics.",
                            MakeTraceSourceAccessor(&NrUePhy::m_reportRsrpTrace),
                            "ns3::CurrentRsrp::TracedCallback")
            .AddTraceSource("UePhyRxedCtrlMsgsTrace",
                            "Ue PHY Control Messages Traces.",
                            MakeTraceSourceAccessor(&NrUePhy::m_phyRxedCtrlMsgsTrace),
                            "ns3::NrPhyRxTrace::RxedUePhyCtrlMsgsTracedCallback")
            .AddTraceSource("UePhyTxedCtrlMsgsTrace",
                            "Ue PHY Control Messages Traces.",
                            MakeTraceSourceAccessor(&NrUePhy::m_phyTxedCtrlMsgsTrace),
                            "ns3::NrPhyRxTrace::TxedUePhyCtrlMsgsTracedCallback")
            .AddTraceSource("UePhyRxedDlDciTrace",
                            "Ue PHY DL DCI Traces.",
                            MakeTraceSourceAccessor(&NrUePhy::m_phyUeRxedDlDciTrace),
                            "ns3::NrPhyRxTrace::RxedUePhyDlDciTracedCallback")
            .AddTraceSource("UePhyTxedHarqFeedbackTrace",
                            "Ue PHY DL HARQ Feedback Traces.",
                            MakeTraceSourceAccessor(&NrUePhy::m_phyUeTxedHarqFeedbackTrace),
                            "ns3::NrPhyRxTrace::TxedUePhyHarqFeedbackTracedCallback")
            .AddTraceSource("ReportPowerSpectralDensity",
                            "Power Spectral Density data.",
                            MakeTraceSourceAccessor(&NrUePhy::m_reportPowerSpectralDensity),
                            "ns3::NrUePhy::PowerSpectralDensityTracedCallback")
            .AddTraceSource("CqiFeedbackTrace",
                            "Mimo CQI feedback traces containing RNTI, WB CQI, MCS, and RI ",
                            MakeTraceSourceAccessor(&NrUePhy::m_cqiFeedbackTrace),
                            "ns3::NrUePhy::CqiFeedbackTracedCallback")
            .AddTraceSource("ReportUeMeasurements",
                            "Report UE measurements RSRP (dBm) and RSRQ (dB).",
                            MakeTraceSourceAccessor(&NrUePhy::m_reportUeMeasurements),
                            "ns3::NrUePhy::RsrpRsrqTracedCallback")
            .AddAttribute("Qout",
                          "corresponds to 10% block error rate of a hypothetical PDCCH transmission"
                          "taking into account the PCFICH errors with transmission parameters."
                          "see 3GPP TS 36.213 4.2.1 and TS 36.133 7.6",
                          DoubleValue(-5),
                          MakeDoubleAccessor(&NrUePhy::m_qOut),
                          MakeDoubleChecker<double>())
            .AddAttribute("Qin",
                          "corresponds to 2% block error rate of a hypothetical PDCCH transmission"
                          "taking into account the PCFICH errors with transmission parameters."
                          "see 3GPP TS 36.213 4.2.1 and TS 36.133 7.6",
                          DoubleValue(-3.9),
                          MakeDoubleAccessor(&NrUePhy::m_qIn),
                          MakeDoubleChecker<double>())
            .AddAttribute(
                "NumQoutEvalSf",
                "This specifies the total number of consecutive subframes"
                "which corresponds to the Qout evaluation period",
                UintegerValue(200), // see 3GPP 3GPP TS 36.133 7.6.2.1
                MakeUintegerAccessor(&NrUePhy::SetNumQoutEvalSf, &NrUePhy::GetNumQoutEvalSf),
                MakeUintegerChecker<uint16_t>())
            .AddAttribute(
                "NumQinEvalSf",
                "This specifies the total number of consecutive subframes"
                "which corresponds to the Qin evaluation period",
                UintegerValue(100), // see 3GPP 3GPP TS 36.133 7.6.2.1
                MakeUintegerAccessor(&NrUePhy::SetNumQinEvalSf, &NrUePhy::GetNumQinEvalSf),
                MakeUintegerChecker<uint16_t>())
            .AddAttribute("EnableRlfDetection",
                          "If true, RLF detection will be enabled.",
                          BooleanValue(true),
                          MakeBooleanAccessor(&NrUePhy::m_enableRlfDetection),
                          MakeBooleanChecker())
            .AddAttribute("PdcchErrorModel",
                          "If true, the PDCCH has a block error rate: 10% at Qout, 2% at Qin.",
                          BooleanValue(false),
                          MakeBooleanAccessor(&NrUePhy::m_pdcchErrorModel),
                          MakeBooleanChecker())
            .AddAttribute("RlmFromPdcchTable",
                          "With NrPdcch on: Qout and Qin of PdcchErrorModel come from its table.",
                          BooleanValue(true),
                          MakeBooleanAccessor(&NrUePhy::m_rlmFromPdcchTable),
                          MakeBooleanChecker())
            .AddAttribute("PdcchSinrReportPeriod",
                          "With NrPdcch on: the UE reports its control SINR this often; 0 = never.",
                          TimeValue(MilliSeconds(10)),
                          MakeTimeAccessor(&NrUePhy::m_pdcchSinrReportPeriod),
                          MakeTimeChecker())
            .AddTraceSource("PdcchReception",
                            "PdcchErrorModel: a DCI for this UE: RNTI, SINR of the control "
                            "symbol in dB, uplink grant or not, missed or not.",
                            MakeTraceSourceAccessor(&NrUePhy::m_pdcchReceptionTrace),
                            "ns3::NrUePhy::PdcchReceptionTracedCallback");
    return tid;
}

void
NrUePhy::ChannelAccessGranted([[maybe_unused]] const Time& time)
{
    NS_LOG_FUNCTION(this);
    // That will be granted only till the end of the slot
    m_channelStatus = GRANTED;
}

void
NrUePhy::ChannelAccessDenied()
{
    NS_LOG_FUNCTION(this);
    m_channelStatus = NONE;
}

void
NrUePhy::SetUeCphySapUser(NrUeCphySapUser* s)
{
    NS_LOG_FUNCTION(this);
    m_ueCphySapUser = s;
}

NrUeCphySapProvider*
NrUePhy::GetUeCphySapProvider()
{
    NS_LOG_FUNCTION(this);
    return (m_ueCphySapProvider);
}

void
NrUePhy::SetEnableUplinkPowerControl(bool enable)
{
    m_enableUplinkPowerControl = enable;
}

void
NrUePhy::SetAlphaCovMat(double alpha)
{
    m_alphaCovMat = alpha;
}

double
NrUePhy::GetAlphaCovMat() const
{
    return m_alphaCovMat;
}

void
NrUePhy::SetCsiImDuration(uint8_t csiImDuration)
{
    m_csiImDuration = csiImDuration;
}

uint8_t
NrUePhy::GetCsiImDuration() const
{
    return m_csiImDuration;
}

void
NrUePhy::SetTxPower(double pow)
{
    m_txPower = pow;
    m_powerControl->SetTxPower(pow);
}

double
NrUePhy::GetTxPower() const
{
    return m_txPower;
}

double
NrUePhy::GetRsrp() const
{
    return m_rsrp;
}

void
NrUePhy::SetNumQoutEvalSf(uint16_t numSubframes)
{
    NS_LOG_FUNCTION(this << numSubframes);
    NS_ABORT_MSG_IF(numSubframes % 10 != 0,
                    "Number of subframes used for Qout "
                    "evaluation must be multiple of 10");
    m_numOfQoutEvalSf = numSubframes;
}

void
NrUePhy::SetNumQinEvalSf(uint16_t numSubframes)
{
    NS_LOG_FUNCTION(this << numSubframes);
    NS_ABORT_MSG_IF(numSubframes % 10 != 0,
                    "Number of subframes used for Qin "
                    "evaluation must be multiple of 10");
    m_numOfQinEvalSf = numSubframes;
}

uint16_t
NrUePhy::GetNumQoutEvalSf() const
{
    return m_numOfQoutEvalSf;
}

uint16_t
NrUePhy::GetNumQinEvalSf() const
{
    return m_numOfQinEvalSf;
}

Ptr<NrUePowerControl>
NrUePhy::GetUplinkPowerControl() const
{
    NS_LOG_FUNCTION(this);
    return m_powerControl;
}

void
NrUePhy::SetUplinkPowerControl(Ptr<NrUePowerControl> pc)
{
    m_powerControl = pc;
}

void
NrUePhy::SetDlAmc(const Ptr<const NrAmc>& amc)
{
    m_amc = amc;

    if (m_pmSearch)
    {
        m_pmSearch->SetAmc(amc);
    }
}

void
NrUePhy::SetSubChannelsForTransmission(const std::vector<int>& mask, uint32_t numSym)
{
    Ptr<SpectrumValue> txPsd = GetTxPowerSpectralDensity(mask);
    NS_ASSERT(txPsd);

    m_reportPowerSpectralDensity(m_currentSlot,
                                 txPsd,
                                 numSym * GetSymbolPeriod(),
                                 m_rnti,
                                 m_imsi,
                                 GetBwpId(),
                                 GetCellId());
    m_spectrumPhy->SetTxPowerSpectralDensity(txPsd);
}

void
NrUePhy::DoSendControlMessage(Ptr<NrControlMessage> msg)
{
    NS_LOG_FUNCTION(this << msg);
    EnqueueCtrlMessage(msg);
}

void
NrUePhy::DoSendControlMessageNow(Ptr<NrControlMessage> msg)
{
    NS_LOG_FUNCTION(this << msg);
    EnqueueCtrlMsgNow(msg);
}

bool
NrUePhy::ProcessDataDci(const SfnSf& ulSfnSf,
                        const std::shared_ptr<DciInfoElementTdma>& dciInfoElem)
{
    NS_LOG_FUNCTION(this);

    NS_LOG_DEBUG("UE" << m_rnti << " UL-DCI received for slot " << ulSfnSf << " symStart "
                      << static_cast<uint32_t>(dciInfoElem->m_symStart) << " numSym "
                      << static_cast<uint32_t>(dciInfoElem->m_numSym) << " tbs "
                      << dciInfoElem->m_tbSize << " harqId "
                      << static_cast<uint32_t>(dciInfoElem->m_harqProcess));

    return InsertUlAllocation(ulSfnSf, dciInfoElem);
}

bool
NrUePhy::InsertUlAllocation(const SfnSf& ulSfnSf,
                            const std::shared_ptr<DciInfoElementTdma>& dciInfoElem)
{
    NS_LOG_FUNCTION(this << ulSfnSf);

    if (ulSfnSf == m_currentSlot)
    {
        InsertAllocation(dciInfoElem);
        return true;
    }
    if (m_nominalGrid && ulSfnSf < m_currentSlot)
    {
        // Slot offsets carried by downlink messages are counted from the gNB slot that carried
        // them, which lies 2 * TimingAdvance behind the UE's clock: a K2 (or Msg3) offset that
        // does not cover that gap points at a slot this UE has already transmitted.
        NS_LOG_WARN("UE" << m_rnti << " dropping UL allocation for slot " << ulSfnSf
                         << ", which precedes the current slot " << m_currentSlot
                         << ": NrGnbPhy::CellSpecificKoffset does not cover the round-trip time "
                            "of TimingAdvance "
                         << m_timingAdvance.As(Time::US));
        return false;
    }
    InsertFutureAllocation(ulSfnSf, dciInfoElem);
    return true;
}

void
NrUePhy::SetTimingAdvance(Time timingAdvance)
{
    NS_LOG_FUNCTION(this << timingAdvance);
    NS_ABORT_MSG_IF(timingAdvance.IsStrictlyNegative(), "TimingAdvance cannot be negative");
    if (timingAdvance == m_timingAdvance)
    {
        return;
    }
    m_timingAdvance = timingAdvance;
    if (!m_timingAdvance.IsZero())
    {
        m_nominalGrid = true;
    }
    if (m_nominalGrid && m_slotMachineIdle && m_nextSlotEvent.IsPending())
    {
        // Re-time the pending slot start onto the new grid: a smaller advance starts it later,
        // a larger one right away (StartSlot() then runs it late, on the grid).
        const SfnSf next = m_currentSlot; // already advanced by the end-of-slot bookkeeping
        m_nextSlotEvent.Cancel();
        const Time delay = Max(Time(0), GetNominalSlotStart(next) - Simulator::Now());
        m_nextSlotEvent = Simulator::Schedule(delay, &NrUePhy::StartSlot, this, next);
    }
}

void
NrUePhy::SetTimingAdvanceCallback(Callback<Time> callback)
{
    NS_LOG_FUNCTION(this);
    m_timingAdvanceCallback = callback;
    SetTimingAdvance(m_timingAdvanceCallback());
}

Time
NrUePhy::GetTimingAdvance() const
{
    return m_timingAdvance;
}

Time
NrUePhy::GetNominalSlotStart(const SfnSf& slot) const
{
    return GetSlotPeriod() * static_cast<int64_t>(slot.Normalize()) - m_timingAdvance;
}

SfnSf
NrUePhy::FirstSlotNotBefore(Time t) const
{
    const int64_t period = GetSlotPeriod().GetTimeStep();
    const int64_t shifted = std::max<int64_t>(0, (t + m_timingAdvance).GetTimeStep());
    const int64_t index = (shifted + period - 1) / period; // ceil
    SfnSf slot(0, 0, 0, GetNumerology());
    slot.Add(static_cast<uint32_t>(index));
    return slot;
}

SfnSf
NrUePhy::GetDlArrivalSlot(const SfnSf& currentSlot) const
{
    if (m_timingAdvance.IsZero())
    {
        return currentSlot;
    }
    // A downlink message whose reception ends now left the gNB one propagation delay ago; the
    // gNB's slot clock is anchored at t = 0 like ours, without the advance.
    const Time gnbTime = Max(Time(0), Simulator::Now() - m_timingAdvance);
    SfnSf slot(0, 0, 0, currentSlot.GetNumerology());
    slot.Add(static_cast<uint32_t>(gnbTime.GetTimeStep() / GetSlotPeriod().GetTimeStep()));
    return slot;
}

void
NrUePhy::SendRachPreamble(uint32_t PreambleId, uint32_t Rnti)
{
    NS_LOG_FUNCTION(this << PreambleId);
    m_raPreambleId = PreambleId;
    Ptr<NrRachPreambleMessage> msg = Create<NrRachPreambleMessage>();
    msg->SetSourceBwpArfcn(DoGetArfcn());
    msg->SetRapId(PreambleId);
    EnqueueCtrlMsgNow(msg);
}

void
NrUePhy::ProcessSrsDci(const SfnSf& ulSfnSf, const std::shared_ptr<DciInfoElementTdma>& dciInfoElem)
{
    NS_LOG_FUNCTION(this);
    // Instruct PHY for transmitting the SRS
    InsertUlAllocation(ulSfnSf, dciInfoElem);
}

void
NrUePhy::RegisterToGnb(uint16_t cellId)
{
    NS_LOG_FUNCTION(this);

    InitializeMessageList();
    DoSetCellId(cellId);
}

void
NrUePhy::SetUlCtrlSyms(uint8_t ulCtrlSyms)
{
    m_ulCtrlSyms = ulCtrlSyms;
}

void
NrUePhy::SetDlCtrlSyms(uint8_t dlCtrlSyms)
{
    m_dlCtrlSyms = dlCtrlSyms;
}

void
NrUePhy::SetNumRbPerRbg(uint32_t numRbPerRbg)
{
    m_numRbPerRbg = numRbPerRbg;
}

void
NrUePhy::SetPattern(const std::string& pattern)
{
    NS_LOG_FUNCTION(this);

    static std::unordered_map<std::string, LteNrTddSlotType> lookupTable = {
        {"DL", LteNrTddSlotType::DL},
        {"UL", LteNrTddSlotType::UL},
        {"S", LteNrTddSlotType::S},
        {"F", LteNrTddSlotType::F},
    };

    std::vector<LteNrTddSlotType> vector;
    std::stringstream ss(pattern);
    std::string token;
    std::vector<std::string> extracted;

    while (std::getline(ss, token, '|'))
    {
        extracted.push_back(token);
    }

    vector.reserve(extracted.size());
    for (const auto& v : extracted)
    {
        vector.push_back(lookupTable[v]);
    }

    m_tddPattern = vector;
    // Check if pure UL BWP
    const auto ulSlots = std::count(m_tddPattern.begin(), m_tddPattern.end(), LteNrTddSlotType::UL);
    if (static_cast<size_t>(ulSlots) == m_tddPattern.size())
    {
        // In case Downlink CSI feedback is enabled, disable it
        m_csiFeedbackType = 0;
    }
}

uint32_t
NrUePhy::GetNumRbPerRbg() const
{
    return m_numRbPerRbg;
}

void
NrUePhy::SetCurrentSfnSf(const SfnSf& currentSfnSf)
{
    m_currentSlot = currentSfnSf;
}

void
NrUePhy::SetLastSlotStart(Time startTime)
{
    m_lastSlotStart = startTime;
}

Time
NrUePhy::GetLastSlotStart() const
{
    return m_lastSlotStart;
}

NrUePhySapUser*
NrUePhy::GetPhySapUser() const
{
    return m_phySapUser;
}

double
NrUePhy::ComputeAvgSinr(const SpectrumValue& sinr)
{
    // averaged SINR among RBs
    double sum = 0.0;
    uint16_t rbNum = 0;
    Values::const_iterator it;

    for (it = sinr.ConstValuesBegin(); it != sinr.ConstValuesEnd(); it++)
    {
        sum += (*it);
        rbNum++;
    }

    double avrgSinr = (rbNum > 0) ? (sum / rbNum) : DBL_MAX;

    return avrgSinr;
}

void
NrUePhy::InsertAllocation(const std::shared_ptr<DciInfoElementTdma>& dci)
{
    NS_LOG_FUNCTION(this);

    VarTtiAllocInfo varTtiInfo(dci);
    m_currSlotAllocInfo.m_varTtiAllocInfo.push_back(varTtiInfo);
    std::stable_sort(m_currSlotAllocInfo.m_varTtiAllocInfo.begin(),
                     m_currSlotAllocInfo.m_varTtiAllocInfo.end());
}

void
NrUePhy::InsertFutureAllocation(const SfnSf& sfnSf, const std::shared_ptr<DciInfoElementTdma>& dci)
{
    NS_LOG_FUNCTION(this);

    VarTtiAllocInfo varTtiInfo(dci);
    if (SlotAllocInfoExists(sfnSf))
    {
        auto& ulSlot = PeekSlotAllocInfo(sfnSf);
        ulSlot.m_varTtiAllocInfo.push_back(varTtiInfo);
        std::stable_sort(ulSlot.m_varTtiAllocInfo.begin(), ulSlot.m_varTtiAllocInfo.end());
    }
    else
    {
        SlotAllocInfo slotAllocInfo = SlotAllocInfo(sfnSf);
        slotAllocInfo.m_varTtiAllocInfo.push_back(varTtiInfo);
        PushBackSlotAllocInfo(slotAllocInfo);
    }
}

void
NrUePhy::PhyCtrlMessagesReceived(const Ptr<NrControlMessage>& msg)
{
    NS_LOG_FUNCTION(this);

    if (msg->GetMessageType() == NrControlMessage::DL_DCI)
    {
        auto dciMsg = DynamicCast<NrDlDciMessage>(msg);
        auto dciInfoElem = dciMsg->GetDciInfoElement();

        m_phyRxedCtrlMsgsTrace(m_currentSlot, GetCellId(), m_rnti, GetBwpId(), msg);

        if (dciInfoElem->m_rnti != 0 && dciInfoElem->m_rnti != m_rnti)
        {
            return; // DCI not for me
        }
        if (dciInfoElem->m_sps == DciInfoElementTdma::SPS_RELEASE)
        {
            return; // the release of an SPS configuration schedules nothing (MarkMissedDcis())
        }

        SfnSf dciSfn = GetDlArrivalSlot(m_currentSlot);
        uint32_t k0Delay = dciMsg->GetKDelay();
        dciSfn.Add(k0Delay);

        NS_LOG_DEBUG("UE" << m_rnti << " DL-DCI received for slot " << dciSfn << " symStart "
                          << static_cast<uint32_t>(dciInfoElem->m_symStart) << " numSym "
                          << static_cast<uint32_t>(dciInfoElem->m_numSym) << " tbs "
                          << dciInfoElem->m_tbSize << " harqId "
                          << static_cast<uint32_t>(dciInfoElem->m_harqProcess));

        /* BIG ASSUMPTION: We assume that K0 is always 0 */

        auto it = m_harqIdToK1Map.find(dciInfoElem->m_harqProcess);
        if (it != m_harqIdToK1Map.end())
        {
            m_harqIdToK1Map.erase(m_harqIdToK1Map.find(dciInfoElem->m_harqProcess));
        }

        m_harqIdToK1Map.insert(std::make_pair(dciInfoElem->m_harqProcess, dciMsg->GetK1Delay()));
        m_harqIdToDlSlotMap[dciInfoElem->m_harqProcess] = dciSfn;

        m_phyUeRxedDlDciTrace(m_currentSlot,
                              GetCellId(),
                              m_rnti,
                              GetBwpId(),
                              dciInfoElem->m_harqProcess,
                              dciMsg->GetK1Delay());

        // The data comes on the symbol grid of the gNB slot that carried this DCI, and the
        // control messages of a gNB slot all travel in its first symbol. The slot machine can
        // receive the data only if our own slot started when that gNB slot arrived: then the
        // DCI comes as our first symbol ends. (With a DL CTRL of one symbol the slot machine
        // is still running at that time only if it is so. With two or three it is running
        // for longer, and data inserted on our own grid would be expected too early: one
        // transport block is received all the same, a second one for this UE in the slot
        // would take its place before it has come in.)
        const bool onOurGrid =
            !m_slotMachineIdle && Simulator::Now() - m_lastSlotStart <= GetSymbolPeriod();
        if (!onOurGrid)
        {
            // The DCI arrived after the slot machine ran out of allocations for this slot (the
            // gNB's DL CTRL is not aligned with our slot start when the propagation delay is
            // not a whole number of slots): an allocation inserted now would be discarded at
            // the next slot start, so receive the data outside the slot machine.
            StartDetachedDlData(dciInfoElem);
        }
        else
        {
            InsertAllocation(dciInfoElem);
        }

        m_phySapUser->ReceiveControlMessage(msg);

        if (m_enableUplinkPowerControl)
        {
            m_powerControl->ReportTpcPusch(dciInfoElem->m_tpc);
            m_powerControl->ReportTpcPucch(dciInfoElem->m_tpc);
        }
    }
    else if (msg->GetMessageType() == NrControlMessage::UL_DCI)
    {
        auto dciMsg = DynamicCast<NrUlDciMessage>(msg);
        auto dciInfoElem = dciMsg->GetDciInfoElement();

        m_phyRxedCtrlMsgsTrace(m_currentSlot, GetCellId(), m_rnti, GetBwpId(), msg);

        if (dciInfoElem->m_rnti != 0 && dciInfoElem->m_rnti != m_rnti)
        {
            return; // DCI not for me
        }

        SfnSf ulSfnSf = GetDlArrivalSlot(m_currentSlot);
        uint32_t k2Delay = dciMsg->GetKDelay();
        ulSfnSf.Add(k2Delay);

        if (dciInfoElem->m_sps == DciInfoElementTdma::SPS_RELEASE)
        {
            // The release of a configured grant grants nothing; the MAC confirms it, if the
            // UE decoded it (MarkMissedDcis())
            if (!dciInfoElem->m_pdcchMissed)
            {
                m_phySapUser->ReceiveControlMessage(msg);
            }
        }
        else if (dciInfoElem->m_sps != DciInfoElementTdma::DYNAMIC && dciInfoElem->m_pdcchMissed)
        {
            // A block of a configured grant the UE does not know of: it missed the DCI that
            // activated the configuration. It sends nothing and keeps its data, and the gNB
            // receives nothing (MarkMissedDcis()).
            dciInfoElem->m_cgSkipped = true;
        }
        else if (dciInfoElem->m_type == DciInfoElementTdma::DATA)
        {
            if (ProcessDataDci(ulSfnSf, dciInfoElem))
            {
                m_phySapUser->ReceiveControlMessage(msg);
            }
        }
        else if (dciInfoElem->m_type == DciInfoElementTdma::SRS)
        {
            ProcessSrsDci(ulSfnSf, dciInfoElem);
            // Do not pass the DCI to MAC
        }
    }
    else if (msg->GetMessageType() == NrControlMessage::MIB)
    {
        NS_LOG_DEBUG("received MIB");
        Ptr<NrMibMessage> msg2 = DynamicCast<NrMibMessage>(msg);
        m_phyRxedCtrlMsgsTrace(m_currentSlot, GetCellId(), m_rnti, GetBwpId(), msg);
        m_ueCphySapUser->RecvMasterInformationBlock(GetCellId(), DoGetArfcn(), msg2->GetMib());
    }
    else if (msg->GetMessageType() == NrControlMessage::SIB1)
    {
        Ptr<NrSib1Message> msg2 = DynamicCast<NrSib1Message>(msg);
        m_phyRxedCtrlMsgsTrace(m_currentSlot, GetCellId(), m_rnti, GetBwpId(), msg);
        m_ueCphySapUser->RecvSystemInformationBlockType1(
            msg2->GetSib1().cellAccessRelatedInfo.cellIdentity,
            DoGetArfcn(),
            msg2->GetSib1());
    }
    else if (msg->GetMessageType() == NrControlMessage::RAR)
    {
        Ptr<NrRarMessage> rarMsg = DynamicCast<NrRarMessage>(msg);

        ProcessRar(rarMsg);
    }
    else
    {
        NS_LOG_INFO("Message type not recognized " << msg->GetMessageType());
        m_phyRxedCtrlMsgsTrace(m_currentSlot, GetCellId(), m_rnti, GetBwpId(), msg);
        m_phySapUser->ReceiveControlMessage(msg);
    }
}

void
NrUePhy::ProcessRar(const Ptr<NrRarMessage>& rarMsg)
{
    NS_LOG_FUNCTION(this);
    bool myRar = false;
    {
        for (auto it = rarMsg->RarListBegin(); it != rarMsg->RarListEnd(); ++it)
        {
            NS_LOG_INFO("Received RAR in slot" << m_currentSlot << " with RA preamble ID: "
                                               << std::to_string(it->rarPayload.raPreambleId));
            if (it->rarPayload.raPreambleId == m_raPreambleId)
            {
                NS_LOG_INFO("Received RAR with RA preamble ID:" << +it->rarPayload.raPreambleId
                                                                << " current RA preamble ID is :"
                                                                << m_raPreambleId);
                // insert allocation
                SfnSf ulSfnSf = GetDlArrivalSlot(m_currentSlot);
                uint32_t k2Delay = it->rarPayload.k2Delay;
                ulSfnSf.Add(k2Delay);
                NS_LOG_DEBUG("Insert RAR UL DCI allocation for " << ulSfnSf);
                // A Msg3 grant that cannot be honoured is dropped by ProcessDataDci; the MAC
                // is still told about the RAR, which completes the random access.
                ProcessDataDci(ulSfnSf, (*it).rarPayload.ulMsg3Dci);
                myRar = true;
                // notify MAC and above about transmission opportunity
                m_phySapUser->ReceiveControlMessage(rarMsg);
                // fire CTRL msg trace
                m_phyRxedCtrlMsgsTrace(m_currentSlot, GetCellId(), m_rnti, GetBwpId(), rarMsg);
                // reset RACH variables with out of range values
                m_raPreambleId = 255;
            }
        }
        if (!myRar)
        {
            NS_LOG_DEBUG("Skipping RAR, does not contain preamble ID."
                         << "\n My preamble id: " << std::to_string(m_raPreambleId) << " found:");
            for (auto it = rarMsg->RarListBegin(); it != rarMsg->RarListEnd(); ++it)
            {
                NS_LOG_DEBUG("rapId: " << std::to_string(it->rapId));
            }
        }
    }
}

void
NrUePhy::TryToPerformLbt()
{
    NS_LOG_FUNCTION(this);
    uint8_t ulCtrlSymStart = 0;
    uint8_t ulCtrlNumSym = 0;

    for (const auto& alloc : m_currSlotAllocInfo.m_varTtiAllocInfo)
    {
        if (alloc.m_dci->m_type == DciInfoElementTdma::CTRL &&
            alloc.m_dci->m_format == DciInfoElementTdma::UL)
        {
            ulCtrlSymStart = alloc.m_dci->m_symStart;
            ulCtrlNumSym = alloc.m_dci->m_numSym;
            break;
        }
    }

    if (ulCtrlNumSym != 0)
    {
        // We have an UL CTRL symbol scheduled and we have to transmit CTRLs..
        // .. so we check that we have at least 25 us between the latest DCI,
        // or we have to schedule an LBT event.

        Time limit = m_lastSlotStart + GetSlotPeriod() -
                     ((GetSymbolsPerSlot() - ulCtrlSymStart) * GetSymbolPeriod()) -
                     m_lbtThresholdForCtrl;

        for (const auto& alloc : m_currSlotAllocInfo.m_varTtiAllocInfo)
        {
            int64_t symbolPeriod = GetSymbolPeriod().GetMicroSeconds();
            int64_t dciEndsAt = m_lastSlotStart.GetMicroSeconds() +
                                ((alloc.m_dci->m_numSym + alloc.m_dci->m_symStart) * symbolPeriod);

            if (alloc.m_dci->m_type != DciInfoElementTdma::DATA &&
                alloc.m_dci->m_type != DciInfoElementTdma::MSG3)
            {
                continue;
            }

            if (limit.GetMicroSeconds() < dciEndsAt)
            {
                NS_LOG_INFO("This data DCI ends at "
                            << MicroSeconds(dciEndsAt)
                            << " which is inside the LBT shared COT (the limit is " << limit
                            << "). No need for LBT");
                m_lbtEvent.Cancel(); // Forget any LBT we previously set, because of the new
                // DCI information
                m_channelStatus = GRANTED;
            }
            else
            {
                NS_LOG_INFO("This data DCI starts at "
                            << +alloc.m_dci->m_symStart << " for " << +alloc.m_dci->m_numSym
                            << " ends at " << MicroSeconds(dciEndsAt)
                            << " which is outside the LBT shared COT (the limit is " << limit
                            << ").");
            }
        }
        if (m_channelStatus != GRANTED)
        {
            Time sched = m_lastSlotStart - Simulator::Now() + (GetSymbolPeriod() * ulCtrlSymStart) -
                         MicroSeconds(25);
            NS_LOG_DEBUG("Scheduling an LBT for sending the UL CTRL at "
                         << Simulator::Now() + sched);
            m_lbtEvent.Cancel();
            m_lbtEvent = Simulator::Schedule(sched, &NrUePhy::RequestAccess, this);
        }
        else
        {
            NS_LOG_DEBUG("Not scheduling LBT: the UE has a channel status that is GRANTED");
        }
    }
    else
    {
        NS_LOG_DEBUG("Not scheduling LBT; the UE has no UL CTRL symbols available");
    }
}

void
NrUePhy::RequestAccess()
{
    NS_LOG_FUNCTION(this);
    NS_LOG_DEBUG("Request access because we have to transmit UL CTRL");
    m_cam->RequestAccess(); // This will put the m_channelStatus to granted when
                            // the channel will be granted.
}

void
NrUePhy::PushCtrlAllocations(const SfnSf currentSfnSf)
{
    NS_LOG_FUNCTION(this);

    // The UE does not know anything from the GNB yet, so listen on the default
    // bandwidth.
    std::vector<bool> rbgBitmask(GetRbNum(), true);

    // The UE still doesn't know the TDD pattern, so just add a DL CTRL
    if (m_tddPattern.empty())
    {
        NS_LOG_INFO("TDD Pattern unknown, insert DL CTRL at the beginning of the slot");
        VarTtiAllocInfo dlCtrlSlot(std::make_shared<DciInfoElementTdma>(0,
                                                                        m_dlCtrlSyms,
                                                                        DciInfoElementTdma::DL,
                                                                        DciInfoElementTdma::CTRL,
                                                                        rbgBitmask));
        m_currSlotAllocInfo.m_varTtiAllocInfo.push_front(dlCtrlSlot);
        return;
    }

    uint64_t currentSlotN = currentSfnSf.Normalize() % m_tddPattern.size();
    const auto overlapsRange = [this](uint8_t start, uint8_t numSym) {
        const uint8_t end = start + numSym;
        return std::any_of(m_currSlotAllocInfo.m_varTtiAllocInfo.begin(),
                           m_currSlotAllocInfo.m_varTtiAllocInfo.end(),
                           [start, end](const auto& alloc) {
                               const uint8_t allocStart = alloc.m_dci->m_symStart;
                               const uint8_t allocEnd = allocStart + alloc.m_dci->m_numSym;
                               return allocStart < end && start < allocEnd;
                           });
    };

    if (m_tddPattern[currentSlotN] < LteNrTddSlotType::UL)
    {
        if (!overlapsRange(0, m_dlCtrlSyms))
        {
            NS_LOG_DEBUG("The current TDD pattern indicates that we are in a "
                         << m_tddPattern[currentSlotN]
                         << " slot, so insert DL CTRL at the beginning of the slot");
            VarTtiAllocInfo dlCtrlSlot(
                std::make_shared<DciInfoElementTdma>(0,
                                                     m_dlCtrlSyms,
                                                     DciInfoElementTdma::DL,
                                                     DciInfoElementTdma::CTRL,
                                                     rbgBitmask));
            m_currSlotAllocInfo.m_varTtiAllocInfo.push_front(dlCtrlSlot);
        }
        else
        {
            NS_LOG_WARN("Skipping DL CTRL insertion because the reserved DL CTRL symbols are "
                        "already occupied");
        }
    }
    if (m_tddPattern[currentSlotN] > LteNrTddSlotType::DL)
    {
        const uint8_t ulCtrlStart = GetSymbolsPerSlot() - m_ulCtrlSyms;
        if (!overlapsRange(ulCtrlStart, m_ulCtrlSyms))
        {
            NS_LOG_DEBUG("The current TDD pattern indicates that we are in a "
                         << m_tddPattern[currentSlotN]
                         << " slot, so insert UL CTRL at the end of the slot");
            VarTtiAllocInfo ulCtrlSlot(
                std::make_shared<DciInfoElementTdma>(ulCtrlStart,
                                                     m_ulCtrlSyms,
                                                     DciInfoElementTdma::UL,
                                                     DciInfoElementTdma::CTRL,
                                                     rbgBitmask));
            m_currSlotAllocInfo.m_varTtiAllocInfo.push_back(ulCtrlSlot);
        }
        else
        {
            NS_LOG_WARN("Skipping UL CTRL insertion because the reserved UL CTRL symbols are "
                        "already occupied");
        }
    }
}

void
NrUePhy::StartSlot(const SfnSf& s)
{
    NS_LOG_FUNCTION(this);

    if (GetNumerology() != s.GetNumerology())
    {
        // The active PHY numerology changed (e.g. the UE re-tuned to a cell on a
        // different numerology during cell (re)selection or an inter-frequency
        // handover). The in-flight slot 's' belongs to the abandoned numerology
        // timeline, so its frame/subframe/slot indices are meaningless here.
        // Drop the stale allocations and re-stamp the slot machine onto the new
        // numerology so that the event loop keeps running instead of stalling
        // forever (which would silently kill the UE PHY, e.g. preventing RACH
        // preambles from ever being transmitted on the target cell).
        NS_LOG_INFO("Numerology changed from " << s.GetNumerology() << " to " << GetNumerology()
                                               << ", restarting slot loop on the new numerology.");
        PurgeStaleSlotAllocInfo();

        // Rebuild a slot index consistent with the new numerology from the
        // current absolute time (on this UE's grid, which runs TimingAdvance
        // ahead of the gNB's), and align to the next slot boundary.
        Time slotPeriod = GetSlotPeriod();
        uint64_t slotsElapsed =
            (Simulator::Now() + m_timingAdvance).GetTimeStep() / slotPeriod.GetTimeStep();
        Time nextSlotStart = slotPeriod * (slotsElapsed + 1) - m_timingAdvance - Simulator::Now();
        SfnSf restartSlot(0, 0, 0, GetNumerology());
        restartSlot.Add(static_cast<uint32_t>(slotsElapsed + 1));
        m_slotMachineIdle = true;
        m_nextSlotEvent =
            Simulator::Schedule(nextSlotStart, &NrUePhy::StartSlot, this, restartSlot);
        return;
    }

    const Time nominalStart = GetNominalSlotStart(s);
    if (m_nominalGrid && nominalStart != Simulator::Now())
    {
        if (nominalStart > Simulator::Now())
        {
            // Early: the timing advance shrank. Wait for the grid.
            m_slotMachineIdle = true;
            m_nextSlotEvent =
                Simulator::Schedule(nominalStart - Simulator::Now(), &NrUePhy::StartSlot, this, s);
            return;
        }
        if (Simulator::Now() - nominalStart >= GetSlotPeriod())
        {
            // Late by a slot or more: the loop started at t = 0 with an advance of at least a
            // slot, or the advance grew by that much. Skip to the first slot of the grid that
            // has not started yet; the skipped slots lose their allocations.
            const SfnSf next = FirstSlotNotBefore(Simulator::Now());
            for (SfnSf skipped = s; skipped < next; skipped.Add(1))
            {
                if (SlotAllocInfoExists(skipped))
                {
                    NS_LOG_WARN("UE" << m_rnti << " skipping slot " << skipped
                                     << " and its allocations: the timing advance moved the "
                                        "slot grid past it");
                    RetrieveSlotAllocInfo(skipped);
                }
            }
            NS_LOG_INFO("UE" << m_rnti << " slot grid starts at " << next << " at "
                             << GetNominalSlotStart(next).As(Time::US) << " (TimingAdvance "
                             << m_timingAdvance.As(Time::US) << ")");
            m_slotMachineIdle = true;
            m_nextSlotEvent = Simulator::Schedule(GetNominalSlotStart(next) - Simulator::Now(),
                                                  &NrUePhy::StartSlot,
                                                  this,
                                                  next);
            return;
        }
        // Late by less than a slot (the timing advance grew): run the slot on the grid, so
        // that the allocations that have not started yet stay aligned with the gNB.
        NS_LOG_INFO("UE" << m_rnti << " slot " << s << " starts "
                         << (Simulator::Now() - nominalStart).As(Time::US)
                         << " after its nominal start");
    }

    m_currentSlot = s;
    m_lastSlotStart = m_nominalGrid ? nominalStart : Simulator::Now();
    m_slotMachineIdle = false;

    // Control messages timed by slot number (DL HARQ feedback on the timing-advance grid) go
    // out in this slot, together with anything already due
    for (auto it = m_ctrlMsgsForSlot.begin();
         it != m_ctrlMsgsForSlot.end() && it->first <= m_currentSlot.Normalize();
         it = m_ctrlMsgsForSlot.erase(it))
    {
        EnqueueCtrlMsgNow(it->second);
    }

    // Call MAC before doing anything in PHY
    m_phySapUser->SlotIndication(m_currentSlot); // trigger mac

    // update the current slot object, and insert DL/UL CTRL allocations depending on the TDD
    // pattern
    bool nrAllocationExists = SlotAllocInfoExists(m_currentSlot);
    FinishSlotProcessing(s, nrAllocationExists);
}

void
NrUePhy::FinishSlotProcessing(const SfnSf& s, bool nrAllocationExists)
{
    NS_LOG_FUNCTION(this << s);
    if (nrAllocationExists)
    {
        m_currSlotAllocInfo = RetrieveSlotAllocInfo(m_currentSlot);
    }
    else
    {
        m_currSlotAllocInfo = SlotAllocInfo(m_currentSlot);
    }

    PushCtrlAllocations(m_currentSlot);
    NS_ASSERT(m_currSlotAllocInfo.m_sfnSf == m_currentSlot);

    NS_LOG_DEBUG("UE " << m_rnti << " start slot " << m_currSlotAllocInfo.m_sfnSf
                       << " composed by the following allocations, total "
                       << m_currSlotAllocInfo.m_varTtiAllocInfo.size());
    for (const auto& alloc : m_currSlotAllocInfo.m_varTtiAllocInfo)
    {
        std::string direction;
        std::string type;

        if (alloc.m_dci->m_format == DciInfoElementTdma::UL)
        {
            direction = "UL";
        }
        else
        {
            direction = "DL";
        }

        switch (alloc.m_dci->m_type)
        {
        case DciInfoElementTdma::VarTtiType::SRS:
            type = "SRS";
            NS_LOG_DEBUG("Allocation from sym "
                         << static_cast<uint32_t>(alloc.m_dci->m_symStart) << " to sym "
                         << static_cast<uint32_t>(alloc.m_dci->m_numSym + alloc.m_dci->m_symStart)
                         << " direction " << direction << " type " << type);
            break;
        case DciInfoElementTdma::VarTtiType::DATA:
            type = "DATA";
            NS_LOG_INFO("Allocation from sym "
                        << static_cast<uint32_t>(alloc.m_dci->m_symStart) << " to sym "
                        << static_cast<uint32_t>(alloc.m_dci->m_numSym + alloc.m_dci->m_symStart)
                        << " direction " << direction << " type " << type);
            break;
        case DciInfoElementTdma::VarTtiType::CTRL:
            type = "CTRL";
            NS_LOG_DEBUG("Allocation from sym "
                         << static_cast<uint32_t>(alloc.m_dci->m_symStart) << " to sym "
                         << static_cast<uint32_t>(alloc.m_dci->m_numSym + alloc.m_dci->m_symStart)
                         << " direction " << direction << " type " << type);
            break;
        case DciInfoElementTdma::VarTtiType::MSG3:
            type = "MSG3";
            NS_LOG_DEBUG("Allocation from sym "
                         << static_cast<uint32_t>(alloc.m_dci->m_symStart) << " to sym "
                         << static_cast<uint32_t>(alloc.m_dci->m_numSym + alloc.m_dci->m_symStart)
                         << " direction " << direction << " type " << type);
            break;
        default:
            NS_LOG_ERROR("Unknown type DciInfoElementTdma::VarTtiType " << alloc.m_dci->m_type);
        }
    }

    TryToPerformLbt();

    VarTtiAllocInfo allocation = m_currSlotAllocInfo.m_varTtiAllocInfo.front();
    m_currSlotAllocInfo.m_varTtiAllocInfo.pop_front();

    // Relative to the slot start: when the slot started late on the timing-advance grid the
    // first allocation may already be due (or past due, in which case it starts now).
    Time nextVarTtiStart =
        m_lastSlotStart + GetSymbolPeriod() * allocation.m_dci->m_symStart - Simulator::Now();
    if (nextVarTtiStart.IsNegative())
    {
        nextVarTtiStart = Time(0);
    }

    auto ctrlMsgs = PopCurrentSlotCtrlMsgs();
    if (m_netDevice)
    {
        DynamicCast<NrUeNetDevice>(m_netDevice)->RouteOutgoingCtrlMsgs(ctrlMsgs, GetBwpId());
    }
    else
    {
        // No netDevice (that could happen in tests) so just redirect them to us
        for (const auto& msg : ctrlMsgs)
        {
            EncodeCtrlMsg(msg);
        }
    }

    Simulator::Schedule(nextVarTtiStart, &NrUePhy::StartVarTti, this, allocation.m_dci);
}

Time
NrUePhy::DlCtrl(const std::shared_ptr<DciInfoElementTdma>& dci)
{
    NS_LOG_FUNCTION(this);

    Time varTtiDuration = GetSymbolPeriod() * dci->m_numSym;

    NS_LOG_DEBUG("UE" << m_rnti
                      << " RXing DL CTRL frame for"
                         " symbols "
                      << +dci->m_symStart << "-" << +(dci->m_symStart + dci->m_numSym - 1)
                      << "\t start " << Simulator::Now() << " end "
                      << (Simulator::Now() + varTtiDuration));
    if (!m_lastSlotStart.IsZero())
    {
        m_tryToPerformLbt = true;
    }

    m_spectrumPhy->AddExpectedDlCtrlEnd(Simulator::Now() + varTtiDuration);

    return varTtiDuration;
}

Time
NrUePhy::UlSrs(const std::shared_ptr<DciInfoElementTdma>& dci)
{
    NS_LOG_FUNCTION(this);

    if (m_nominalGrid)
    {
        const Time late =
            Simulator::Now() - (m_lastSlotStart + GetSymbolPeriod() * dci->m_symStart);
        if (late.IsStrictlyPositive())
        {
            // Started after its slot position on the timing-advance grid (the advance just
            // grew): a late SRS would reach the gNB outside its SRS window, so skip it.
            NS_LOG_WARN("UE" << m_rnti << " skipping SRS that is " << late.As(Time::US)
                             << " late on the timing-advance grid");
            return Max(Time(0), GetSymbolPeriod() * dci->m_numSym - late);
        }
    }

    std::vector<int> channelRbs(GetRbNum());
    std::iota(channelRbs.begin(), channelRbs.end(), 0);
    SetSubChannelsForTransmission(channelRbs, dci->m_numSym);

    std::list<Ptr<NrControlMessage>> srsMsg;
    Ptr<NrSrsMessage> srs = Create<NrSrsMessage>();
    srs->SetSourceBwpArfcn(DoGetArfcn());
    srsMsg.emplace_back(srs);
    Time varTtiDuration = GetSymbolPeriod() * dci->m_numSym;

    m_phyTxedCtrlMsgsTrace(m_currentSlot, GetCellId(), dci->m_rnti, GetBwpId(), *srsMsg.begin());
    m_spectrumPhy->StartTxUlControlFrames(srsMsg, varTtiDuration - NanoSeconds(1.0));

    NS_LOG_DEBUG("UE" << m_rnti << " TXing UL SRS frame for symbols " << +dci->m_symStart << "-"
                      << +(dci->m_symStart + dci->m_numSym - 1) << "\t start " << Simulator::Now()
                      << " end " << (Simulator::Now() + varTtiDuration - NanoSeconds(1.0)));

    ChannelAccessDenied(); // Reset the channel status
    return varTtiDuration;
}

Time
NrUePhy::UlCtrl(const std::shared_ptr<DciInfoElementTdma>& dci)
{
    NS_LOG_FUNCTION(this);

    Time varTtiDuration = GetSymbolPeriod() * dci->m_numSym;

    if (m_ctrlMsgs.empty())
    {
        NS_LOG_DEBUG("UE" << m_rnti << " reserved space for UL CTRL frame for symbols "
                          << +dci->m_symStart << "-" << +(dci->m_symStart + dci->m_numSym - 1)
                          << "\t start " << Simulator::Now() << " end "
                          << (Simulator::Now() + varTtiDuration - NanoSeconds(1.0))
                          << " but no data to transmit");
        m_cam->Cancel();
        return varTtiDuration;
    }
    if (m_nominalGrid)
    {
        const Time late =
            Simulator::Now() - (m_lastSlotStart + GetSymbolPeriod() * dci->m_symStart);
        if (late.IsStrictlyPositive())
        {
            // Started after its slot position on the timing-advance grid (the advance just
            // grew). The gNB requires every UL CTRL of a slot to start at the same instant with
            // the same duration, so hold the messages for the next UL CTRL occasion instead of
            // transmitting late.
            NS_LOG_WARN("UE" << m_rnti << " deferring " << m_ctrlMsgs.size()
                             << " UL CTRL messages: the occasion is " << late.As(Time::US)
                             << " late on the timing-advance grid");
            m_cam->Cancel();
            return Max(Time(0), varTtiDuration - late);
        }
    }
    if (m_channelStatus != GRANTED)
    {
        NS_LOG_INFO("UE" << m_rnti << " has to transmit CTRL but channel not granted");
        m_cam->Cancel();
        return varTtiDuration;
    }

    for (const auto& msg : m_ctrlMsgs)
    {
        m_phyTxedCtrlMsgsTrace(m_currentSlot, GetCellId(), dci->m_rnti, GetBwpId(), msg);

        if (msg->GetMessageType() == NrControlMessage::DL_HARQ)
        {
            Ptr<NrDlHarqFeedbackMessage> harqMsg = DynamicCast<NrDlHarqFeedbackMessage>(msg);
            uint8_t harqId = harqMsg->GetDlHarqFeedback().m_harqProcessId;

            auto it = m_harqIdToK1Map.find(harqId);
            if (it != m_harqIdToK1Map.end())
            {
                m_phyUeTxedHarqFeedbackTrace(m_currentSlot,
                                             GetCellId(),
                                             m_rnti,
                                             GetBwpId(),
                                             static_cast<uint32_t>(harqId),
                                             it->second);
            }
        }
    }

    std::vector<int> channelRbs(GetRbNum());
    std::iota(channelRbs.begin(), channelRbs.end(), 0);

    if (m_enableUplinkPowerControl)
    {
        m_txPower = m_powerControl->GetPucchTxPower(channelRbs.size());
    }
    SetSubChannelsForTransmission(channelRbs, dci->m_numSym);

    NS_LOG_DEBUG("UE" << m_rnti << " TXing UL CTRL frame for symbols " << +dci->m_symStart << "-"
                      << +(dci->m_symStart + dci->m_numSym - 1) << "\t start " << Simulator::Now()
                      << " end " << (Simulator::Now() + varTtiDuration - NanoSeconds(1.0)));

    SendCtrlChannels(varTtiDuration - NanoSeconds(1.0));

    ChannelAccessDenied(); // Reset the channel status
    return varTtiDuration;
}

Time
NrUePhy::DlData(const std::shared_ptr<DciInfoElementTdma>& dci)
{
    NS_LOG_FUNCTION(this);

    Time varTtiDuration = GetSymbolPeriod() * dci->m_numSym;

    if (GetRbNum() / GetNumRbPerRbg() != dci->m_rbgBitmask.size())
    {
        NS_LOG_DEBUG("Mismatching number of RBGs and RBG bitmask");
        return varTtiDuration;
    }

    if (dci->m_rnti != m_rnti)
    {
        NS_LOG_DEBUG("Transmission scheduled before the UE disconnected");
        return varTtiDuration;
    }

    m_receptionEnabled = true;
    NS_ASSERT(dci->m_rnti == m_rnti);
    ExpectedTb expectedTb{dci->m_ndi,
                          dci->m_tbSize,
                          dci->m_mcs,
                          dci->m_rank,
                          dci->m_rnti,
                          FromRBGBitmaskToRBAssignment(dci->m_rbgBitmask),
                          dci->m_harqProcess,
                          dci->m_rv,
                          true,
                          dci->m_symStart,
                          dci->m_numSym,
                          m_currentSlot};
    // PdcchErrorModel: this UE did not decode the assignment, so it does not receive the block
    expectedTb.m_pdcchMissed = dci->m_pdcchMissed;
    m_spectrumPhy->AddExpectedTb(expectedTb);
    m_reportDlTbSize(m_netDevice->GetObject<NrUeNetDevice>()->GetImsi(), dci->m_tbSize);
    NS_LOG_INFO("UE" << m_rnti << " RXing DL DATA frame for symbols " << +dci->m_symStart << "-"
                     << +(dci->m_symStart + dci->m_numSym - 1) << " num of rbg assigned: "
                     << FromRBGBitmaskToRBAssignment(dci->m_rbgBitmask).size()
                     << ". RX will take place for " << varTtiDuration);

    return varTtiDuration;
}

void
NrUePhy::StartDetachedDlData(const std::shared_ptr<DciInfoElementTdma>& dci)
{
    NS_LOG_FUNCTION(this);
    // The DCI has just been decoded from the DL CTRL of the gNB slot, whose messages all travel
    // in its first symbol however many symbols the PDCCH has (NrGnbPhy::DlCtrl()); the data of
    // the same gNB slot follows at its symbol offset, 1 ns after the symbol boundary, exactly as
    // it would follow the UE's own DL CTRL allocation when the two are aligned. Register the
    // transport block 1 ns before the data starts and consider the reception over 1 ns after
    // it ends, mirroring the aligned DlData()/EndVarTti() timeline. (It has to be registered
    // when its own symbol comes, not before: a UE may have two transport blocks in a slot, a
    // block of its semi-persistent configuration and a retransmission, and the spectrum PHY
    // keeps one expected transport block per UE.)
    const Time symbolPeriod = GetSymbolPeriod();
    Time start = Simulator::Now() + NanoSeconds(1.0);
    if (dci->m_symStart > 1)
    {
        start += symbolPeriod * (dci->m_symStart - 1);
    }
    const Time duration = symbolPeriod * dci->m_numSym;
    // Keep the reception open one symbol longer than the data nominally lasts: the data frame
    // leaves the gNB a symbol after the DL CTRL that carried its DCI, so with a moving UE its
    // propagation delay differs by the delay drift over that symbol and its end may fall a few
    // ns after the estimate; the CQI is only generated if the reception is still open then.
    // (the latest end, if this slot has two transport blocks for the UE: a block of its
    // semi-persistent configuration and a retransmission)
    m_detachedDlDataEnd = std::max(m_detachedDlDataEnd, start + duration + symbolPeriod);
    NS_LOG_INFO("UE" << m_rnti << " receiving DL DATA of slot " << GetDlArrivalSlot(m_currentSlot)
                     << " outside the slot machine, from " << start.As(Time::US) << " to "
                     << m_detachedDlDataEnd.As(Time::US));
    Simulator::Schedule(start - Simulator::Now(), [this, dci, symbolPeriod]() {
        m_currTbs = dci->m_tbSize;
        Time varTtiDuration = DlData(dci);
        Simulator::Schedule(varTtiDuration + symbolPeriod, &NrUePhy::EndDetachedDlData, this);
    });
}

void
NrUePhy::EndDetachedDlData()
{
    NS_LOG_FUNCTION(this);
    if (Simulator::Now() >= m_detachedDlDataEnd)
    {
        m_receptionEnabled = false;
    }
}

Time
NrUePhy::UlData(const std::shared_ptr<DciInfoElementTdma>& dci)
{
    NS_LOG_FUNCTION(this);
    Time varTtiDuration = GetSymbolPeriod() * dci->m_numSym;

    if (GetRbNum() / GetNumRbPerRbg() != dci->m_rbgBitmask.size())
    {
        return varTtiDuration;
    }
    if (m_enableUplinkPowerControl)
    {
        m_txPower = m_powerControl->GetPuschTxPower(
            (FromRBGBitmaskToRBAssignment(dci->m_rbgBitmask)).size());
    }
    SetSubChannelsForTransmission(FromRBGBitmaskToRBAssignment(dci->m_rbgBitmask), dci->m_numSym);
    std::list<Ptr<NrControlMessage>> ctrlMsg;
    Ptr<PacketBurst> pktBurst = GetPacketBurst(m_currentSlot, dci->m_symStart, dci->m_rnti);
    if (pktBurst && pktBurst->GetNPackets() > 0)
    {
        std::list<Ptr<Packet>> pkts = pktBurst->GetPackets();
        NrRadioBearerTag bearerTag;
        if (!pkts.front()->PeekPacketTag(bearerTag))
        {
            NS_FATAL_ERROR("No radio bearer tag");
        }
    }
    else
    {
        // put an error, as something is wrong. The UE should not be scheduled
        // if there is no data for him...
        if (dci->m_type == DciInfoElementTdma::MSG3)
        {
            NS_LOG_WARN("Not sending MSG3. Probably in RRC IDEAL mode.");
            return varTtiDuration;
        }
        else
        {
            NS_LOG_WARN("UE " << dci->m_rnti << " was scheduled but has nothing to transmit");
            return varTtiDuration;
        }
    }
    if (m_nominalGrid)
    {
        const Time late =
            Simulator::Now() - (m_lastSlotStart + GetSymbolPeriod() * dci->m_symStart);
        if (late.IsStrictlyPositive())
        {
            // Started after its slot position on the timing-advance grid (the advance just
            // grew): shorten the transmission so that it still ends where the gNB expects it,
            // or skip it when nothing of it is left.
            varTtiDuration = Max(Time(0), varTtiDuration - late);
            NS_LOG_WARN(
                "UE" << m_rnti << " UL DATA is " << late.As(Time::US)
                     << " late on the timing-advance grid, "
                     << (varTtiDuration > NanoSeconds(2.0) ? "shortened to " : "skipped (left ")
                     << varTtiDuration.As(Time::US) << ")");
            if (varTtiDuration <= NanoSeconds(2.0))
            {
                return varTtiDuration;
            }
        }
    }
    m_reportUlTbSize(m_netDevice->GetObject<NrUeNetDevice>()->GetImsi(), dci->m_tbSize);

    NS_LOG_DEBUG("UE" << m_rnti << " TXing UL DATA frame for"
                      << " symbols " << +dci->m_symStart << "-"
                      << +(dci->m_symStart + dci->m_numSym - 1) << "\t start " << Simulator::Now()
                      << " end " << (Simulator::Now() + varTtiDuration));

    Simulator::Schedule(NanoSeconds(1.0),
                        &NrUePhy::SendDataChannels,
                        this,
                        pktBurst,
                        ctrlMsg,
                        dci,
                        varTtiDuration - NanoSeconds(2.0));
    return varTtiDuration;
}

void
NrUePhy::StartVarTti(const std::shared_ptr<DciInfoElementTdma>& dci)
{
    NS_LOG_FUNCTION(this);
    Time varTtiDuration;

    m_currTbs = dci->m_tbSize;
    if (Simulator::Now() >= m_detachedDlDataEnd)
    {
        m_receptionEnabled = false;
    }

    if (dci->m_type == DciInfoElementTdma::CTRL && dci->m_format == DciInfoElementTdma::DL)
    {
        varTtiDuration = DlCtrl(dci);
    }
    else if (dci->m_type == DciInfoElementTdma::CTRL && dci->m_format == DciInfoElementTdma::UL)
    {
        varTtiDuration = UlCtrl(dci);
    }
    else if (dci->m_type == DciInfoElementTdma::SRS && dci->m_format == DciInfoElementTdma::UL)
    {
        varTtiDuration = UlSrs(dci);
    }
    else if (dci->m_type == DciInfoElementTdma::DATA && dci->m_format == DciInfoElementTdma::DL)
    {
        varTtiDuration = DlData(dci);
    }
    else if ((dci->m_type == DciInfoElementTdma::DATA || dci->m_type == DciInfoElementTdma::MSG3) &&
             dci->m_format == DciInfoElementTdma::UL)
    {
        varTtiDuration = UlData(dci);
    }

    if (m_nominalGrid)
    {
        // An allocation that started late must not outlive its slot: the next slot start is
        // fixed by the grid and the slot machine handles one slot at a time.
        varTtiDuration =
            Min(varTtiDuration, Max(Time(0), m_lastSlotStart + GetSlotPeriod() - Simulator::Now()));
    }

    Simulator::Schedule(varTtiDuration, &NrUePhy::EndVarTti, this, dci);
}

void
NrUePhy::EndVarTti(const std::shared_ptr<DciInfoElementTdma>& dci)
{
    NS_LOG_FUNCTION(this);
    NS_LOG_DEBUG("DCI started at symbol "
                 << static_cast<uint32_t>(dci->m_symStart) << " which lasted for "
                 << static_cast<uint32_t>(dci->m_numSym) << " symbols finished");

    if (m_tryToPerformLbt)
    {
        TryToPerformLbt();
        m_tryToPerformLbt = false;
    }

    if (m_currSlotAllocInfo.m_varTtiAllocInfo.empty())
    {
        // end of slot
        m_currentSlot.Add(1);
        if (!m_timingAdvanceCallback.IsNull())
        {
            SetTimingAdvance(m_timingAdvanceCallback());
        }

        // During an inter-frequency / inter-numerology handover the UE re-tunes
        // to a different BWP PHY. The slot period (which is numerology-dependent)
        // and the m_lastSlotStart reference belong to the abandoned timeline, so
        // the next-slot start can resolve to a time in the past. Clamp such a
        // stale boundary to the current instant so the slot machine keeps
        // running on the target BWP instead of asserting; StartSlot() detects
        // the numerology change and cleanly re-stamps the loop from there.
        // On the timing-advance grid the next start is the grid position of the
        // next slot, which also lies in the past when the advance just grew.
        Time delay = (m_nominalGrid ? GetNominalSlotStart(m_currentSlot)
                                    : m_lastSlotStart + GetSlotPeriod()) -
                     Simulator::Now();
        if (delay.IsNegative())
        {
            NS_LOG_WARN("Clamping next-slot start "
                        << delay << " in the past to now, due to a "
                        << (m_nominalGrid ? "timing advance change" : "BWP/numerology switch"));
            delay = Time(0);
        }

        m_slotMachineIdle = true;
        m_nextSlotEvent = Simulator::Schedule(delay, &NrUePhy::StartSlot, this, m_currentSlot);
    }
    else
    {
        VarTtiAllocInfo allocation = m_currSlotAllocInfo.m_varTtiAllocInfo.front();
        m_currSlotAllocInfo.m_varTtiAllocInfo.pop_front();

        Time nextVarTtiStart = GetSymbolPeriod() * allocation.m_dci->m_symStart;
        Time nextVarTtiTime = nextVarTtiStart + m_lastSlotStart;
        Time delay = nextVarTtiTime - Simulator::Now();

        // During an inter-frequency handover the UE re-tunes to a different BWP
        // PHY, whose m_lastSlotStart timeline is re-stamped by StartSlot(). A
        // VarTti that was in flight on the abandoned timeline can then resolve
        // to a start time slightly in the past, yielding a small negative delay.
        // Clamp such a stale allocation to the current instant so that it is
        // still processed (keeping the data plane alive across the handover)
        // without scheduling an event in the past.
        if (delay.IsNegative())
        {
            NS_LOG_WARN("Clamping VarTti scheduled "
                        << delay << " in the past to now, due to a BWP/numerology switch");
            delay = Time(0);
        }

        Simulator::Schedule(delay, &NrUePhy::StartVarTti, this, allocation.m_dci);
    }

    if (Simulator::Now() >= m_detachedDlDataEnd)
    {
        m_receptionEnabled = false;
    }
}

void
NrUePhy::PhyDataPacketReceived(const Ptr<Packet>& p)
{
    Simulator::ScheduleWithContext(m_netDevice->GetNode()->GetId(),
                                   GetTbDecodeLatency(),
                                   &NrUePhySapUser::ReceivePhyPdu,
                                   m_phySapUser,
                                   p);
    // m_phySapUser->ReceivePhyPdu (p);
}

void
NrUePhy::SendDataChannels(const Ptr<PacketBurst>& pb,
                          const std::list<Ptr<NrControlMessage>>& ctrlMsg,
                          const std::shared_ptr<DciInfoElementTdma>& dci,
                          const Time& duration)
{
    if (pb->GetNPackets() > 0)
    {
        NrRadioBearerTag tag;
        if (!pb->GetPackets().front()->PeekPacketTag(tag))
        {
            NS_FATAL_ERROR("No radio bearer tag");
        }
    }

    m_spectrumPhy->StartTxDataFrames(pb, ctrlMsg, dci, duration);
}

void
NrUePhy::SendCtrlChannels(Time duration)
{
    m_spectrumPhy->StartTxUlControlFrames(m_ctrlMsgs, duration);
    m_ctrlMsgs.clear();
}

Ptr<NrDlCqiMessage>
NrUePhy::CreateDlCqiFeedbackMessage(const SpectrumValue& sinr)
{
    NS_LOG_FUNCTION(this);
    // Create DL CQI CTRL message
    Ptr<NrDlCqiMessage> msg = Create<NrDlCqiMessage>();
    msg->SetSourceBwpArfcn(DoGetArfcn());
    DlCqiInfo dlcqi;

    dlcqi.m_rnti = m_rnti;
    dlcqi.m_cqiType = DlCqiInfo::WB;

    std::vector<int> cqi;
    dlcqi.m_wbCqi = m_amc->CreateCqiFeedbackSiso(sinr, dlcqi.m_mcs);
    msg->SetDlCqi(dlcqi);

    m_cqiFeedbackTrace(m_rnti, dlcqi.m_wbCqi, dlcqi.m_mcs, 1);
    return msg;
}

void
NrUePhy::GenerateDlCqiReport(const SpectrumValue& sinr)
{
    NS_LOG_FUNCTION(this);
    // Not totally sure what this is about. We have to check.
    if (m_ulConfigured && (m_rnti > 0) && m_receptionEnabled)
    {
        m_dlDataSinrTrace(GetCellId(), m_rnti, ComputeAvgSinr(sinr), GetBwpId());

        if (Simulator::Now() > m_wbCqiLast)
        {
            Ptr<NrDlCqiMessage> msg = CreateDlCqiFeedbackMessage(sinr);

            if (msg)
            {
                DoSendControlMessage(msg);
            }
        }
    }
}

void
NrUePhy::EnqueueDlHarqFeedback(const DlHarqInfo& m)
{
    NS_LOG_FUNCTION(this);
    // get the feedback from NrSpectrumPhy and send it through ideal PUCCH to gNB
    Ptr<NrDlHarqFeedbackMessage> msg = Create<NrDlHarqFeedbackMessage>();
    msg->SetSourceBwpArfcn(DoGetArfcn());
    msg->SetDlHarqFeedback(m);

    auto k1It = m_harqIdToK1Map.find(m.m_harqProcessId);

    NS_LOG_DEBUG("ReceiveNrDlHarqFeedback" << " Harq Process " << static_cast<uint32_t>(k1It->first)
                                           << " K1: " << k1It->second << " Frame "
                                           << m_currentSlot);

    Time event;
    if (m_timingAdvance.IsZero())
    {
        event = m_lastSlotStart + (GetSlotPeriod() * k1It->second);
    }
    else
    {
        // K1 counts from the gNB slot that carried the data, which (K0 = 0) is the slot of
        // its DCI, recorded when the DCI arrived: the DCI ends a symbol into the gNB slot,
        // whereas the data may end 1 ns before the slot boundary, where a timing advance that
        // is stale by a few ns would already put the arrival-based reference in the next
        // slot. The feedback goes out in the UL CTRL of our slot with that number plus K1,
        // whose start on our grid is one timing advance early, so that it reaches the gNB in
        // the slot it expects it.
        auto slotIt = m_harqIdToDlSlotMap.find(m.m_harqProcessId);
        SfnSf feedbackSlot = (slotIt != m_harqIdToDlSlotMap.end())
                                 ? slotIt->second
                                 : GetDlArrivalSlot(m_currentSlot);
        feedbackSlot.Add(k1It->second);
        event = GetNominalSlotStart(feedbackSlot);
        if (event > Simulator::Now())
        {
            // Hand it over when that slot starts, whenever a change of the timing advance
            // moves the start: an absolute time computed now could fall after the slot has
            // popped its control queue, which would delay the feedback by a slot.
            m_ctrlMsgsForSlot[feedbackSlot.Normalize()].push_back(msg);
            return;
        }
    }
    if (event <= Simulator::Now())
    {
        Simulator::ScheduleNow(&NrUePhy::DoSendControlMessageNow, this, msg);
    }
    else
    {
        Simulator::Schedule(event - Simulator::Now(), &NrUePhy::DoSendControlMessageNow, this, msg);
    }
}

void
NrUePhy::SetCam(const Ptr<NrChAccessManager>& cam)
{
    NS_LOG_FUNCTION(this);
    NS_ASSERT(cam != nullptr);
    m_cam = cam;
    m_cam->SetAccessGrantedCallback(
        std::bind(&NrUePhy::ChannelAccessGranted, this, std::placeholders::_1));
    m_cam->SetAccessDeniedCallback(std::bind(&NrUePhy::ChannelAccessDenied, this));
}

const SfnSf&
NrUePhy::GetCurrentSfnSf() const
{
    return m_currentSlot;
}

uint16_t
NrUePhy::GetRnti() const
{
    return m_rnti;
}

void
NrUePhy::DoReset()
{
    NS_LOG_FUNCTION(this);
    m_raPreambleId = 255; // value out of range
    m_isConnected = false;
    m_spsActiveConfig = {{-1, -1}};
    m_avgIntCovMat = {};
    PurgeStaleSlotAllocInfo();
}

void
NrUePhy::DoStartCellSearch(uint16_t arfcn)
{
    NS_LOG_FUNCTION(this << arfcn);
    InitializeMessageList();
    DoSetInitialBandwidth();
}

void
NrUePhy::DoSynchronizeWithGnb(uint16_t cellId, uint16_t arfcn)
{
    NS_LOG_FUNCTION(this << cellId << arfcn);
    DoSynchronizeWithGnb(cellId);
}

void
NrUePhy::DoSetPa(double pa)
{
    NS_LOG_FUNCTION(this << pa);
}

void
NrUePhy::DoSetRsrpFilterCoefficient(uint8_t rsrpFilterCoefficient)
{
    NS_LOG_FUNCTION(this << +rsrpFilterCoefficient);
}

void
NrUePhy::DoSynchronizeWithGnb(uint16_t cellId)
{
    NS_LOG_FUNCTION(this << cellId);
    DoSetCellId(cellId);
    DoSetInitialBandwidth();
}

BeamId
NrUePhy::GetBeamId([[maybe_unused]] uint16_t rnti) const
{
    NS_LOG_FUNCTION(this);
    // That's a bad specification: the UE PHY doesn't know anything about its beam id.
    NS_FATAL_ERROR("ERROR");
}

void
NrUePhy::ScheduleStartEventLoop(uint32_t nodeId, uint16_t frame, uint8_t subframe, uint16_t slot)
{
    NS_LOG_FUNCTION(this);
    Simulator::ScheduleWithContext(nodeId,
                                   MilliSeconds(0),
                                   &NrUePhy::StartEventLoop,
                                   this,
                                   frame,
                                   subframe,
                                   slot);
}

void
NrUePhy::ReportRsReceivedPower(const SpectrumValue& rsReceivedPower)
{
    NS_LOG_FUNCTION(this << rsReceivedPower);
    m_rsrp = 10 * log10(Integral(rsReceivedPower)) + 30;
    NS_LOG_DEBUG("RSRP value updated: " << m_rsrp << " dBm");

    if (m_enableUplinkPowerControl)
    {
        m_powerControl->SetLoggingInfo(GetCellId(), m_rnti);
        m_powerControl->SetRsrp(m_rsrp);
    }
}

void
NrUePhy::ReceivePss(uint16_t cellId, const Ptr<SpectrumValue>& p)
{
    NS_LOG_FUNCTION(this);

    double sum = 0.0;
    uint16_t nRB = 0;

    uint32_t subcarrierSpacing;
    subcarrierSpacing = 15000 * static_cast<uint32_t>(std::pow(2, GetNumerology()));

    Values::const_iterator itPi;
    for (itPi = p->ConstValuesBegin(); itPi != p->ConstValuesEnd(); itPi++)
    {
        // convert PSD [W/Hz] to linear power [W] for the single RE
        double powerTxW = (*itPi) * subcarrierSpacing;
        sum += powerTxW;
        nRB++;
    }

    // Instantaneous RSRP in linear mW per RE. A zero-power sample (e.g. a fully
    // nulled beamforming cross-link) carries no detectable PSS: skip it rather
    // than store it, since its dB value (-inf) would poison every average and
    // Layer-3 filter it enters downstream.
    double rsrp = 1000.0 * (sum / static_cast<double>(nRB));
    if (rsrp <= 0.0)
    {
        return;
    }

    NS_LOG_DEBUG("RSRP value updated: " << 10 * log10(rsrp) << " dBm"
                                        << " for Cell Id: " << cellId << " RNTI: " << m_rnti);

    if (m_pdcchErrorModel)
    {
        // For the cell search: the PDCCH block error rate at the SINR of this synchronisation
        // signal, i.e. its power in one resource element over the noise in one (the noise of
        // NrSpectrumValueHelper::CreateNoisePowerSpectralDensity; other cells are not counted)
        const double noiseMw =
            std::pow(10.0, (-174.0 + GetNoiseFigure()) / 10.0) * subcarrierSpacing;
        auto& bler = m_pssBler[cellId];
        double blerOut;
        double blerIn;
        RlmBler(10 * log10(rsrp / noiseMw), &blerOut, &blerIn);
        bler.first += blerIn;
        ++bler.second;
    }

    // store RSRP measurements
    auto itMeasMap = m_ueMeasurementsMap.find(cellId);
    if (itMeasMap == m_ueMeasurementsMap.end())
    {
        // insert new entry
        UeMeasurementsElement newEl;
        newEl.rsrpSum = rsrp;
        newEl.rsrpNum = 1;
        newEl.rsrqSum = 0;
        newEl.rsrqNum = 0;

        NS_LOG_DEBUG("New RSRP entry for Cell Id: " << cellId << " RNTI: " << m_rnti
                                                    << " RSRP: " << newEl.rsrpSum << " mW"
                                                    << " number of entries: " << +newEl.rsrpNum);

        m_ueMeasurementsMap.insert(std::pair<uint16_t, UeMeasurementsElement>(cellId, newEl));
    }
    else
    {
        (*itMeasMap).second.rsrpSum += rsrp;
        (*itMeasMap).second.rsrpNum++;

        NS_LOG_DEBUG("Update RSRP entry for Cell Id: "
                     << cellId << " RNTI: " << m_rnti
                     << " RSRP Sum: " << (*itMeasMap).second.rsrpSum << " mW"
                     << " number of entries: " << +((*itMeasMap).second.rsrpNum));
    }
}

void
NrUePhy::SetGenieRsrpCallback(Callback<std::map<uint16_t, double>> cb)
{
    NS_LOG_FUNCTION(this);
    m_genieRsrpCallback = cb;
}

void
NrUePhy::ReportUeMeasurements()
{
    NS_LOG_FUNCTION(this);

    if (!m_genieRsrpCallback.IsNull())
    {
        // Keep the PSS-measured serving cell entry intact (it reflects the
        // locked-beam signal that drives SINR / RLF), and replace neighbor
        // entries with genie best-beam estimates. The genie values are in
        // a different absolute reference than PSS-derived dBm (see
        // NrInitialAssociation::ComputeMaxRsrpClean), so anchor the scale
        // by computing an offset between PSS-serving and genie-serving and
        // shifting all reported neighbors by that offset. This preserves
        // the genie-computed relative deltas between cells while keeping
        // A3's serving anchor consistent with the real signal magnitude.
        const uint16_t servingCellId = GetCellId();
        auto genie = m_genieRsrpCallback();
        auto servingIt = m_ueMeasurementsMap.find(servingCellId);
        auto genieServingIt = genie.find(servingCellId);
        if (servingIt != m_ueMeasurementsMap.end() && genieServingIt != genie.end() &&
            servingIt->second.rsrpNum > 0)
        {
            const double pssServingRsrp =
                10 *
                log10(servingIt->second.rsrpSum / static_cast<double>(servingIt->second.rsrpNum));
            const double offset = pssServingRsrp - genieServingIt->second;
            for (auto it = m_ueMeasurementsMap.begin(); it != m_ueMeasurementsMap.end();)
            {
                if (it->first != servingCellId)
                {
                    it = m_ueMeasurementsMap.erase(it);
                }
                else
                {
                    ++it;
                }
            }
            for (const auto& kv : genie)
            {
                if (kv.first == servingCellId)
                {
                    continue;
                }
                UeMeasurementsElement el;
                el.rsrpSum = std::pow(10.0, (kv.second + offset) / 10.0); // dBm -> linear mW
                el.rsrpNum = 1;
                el.rsrqSum = 0;
                el.rsrqNum = 0;
                m_ueMeasurementsMap[kv.first] = el;
            }
        }
    }

    NrUeCphySapUser::UeMeasurementsParameters ret{};

    // Carrier RSSI (per resource element, linear W) used to derive a real RSRQ below:
    // the total received power = sum of every measured cell's RS power plus thermal noise.
    // RSRP measures one cell's signal; RSSI captures the inter-cell interference + noise, so
    // RSRQ = RSRP/RSSI is the interference-aware quality the RSRP-only measurement lacked.
    double rssiPerReLin = 0.0;
    const auto scsHz = static_cast<double>(GetSubcarrierSpacing());
    if (scsHz > 0.0)
    {
        // thermal noise per subcarrier: kB*T (=-174 dBm/Hz at 290 K) * SCS * noise figure
        constexpr double kBT = 1.38064852e-23 * 290.0; // W/Hz
        rssiPerReLin += kBT * scsHz * std::pow(10.0, GetNoiseFigure() / 10.0);
    }
    for (const auto& kv : m_ueMeasurementsMap)
    {
        if (kv.second.rsrpNum > 0)
        {
            // rsrpSum is linear mW; convert the average to W
            rssiPerReLin += kv.second.rsrpSum / static_cast<double>(kv.second.rsrpNum) / 1000.0;
        }
    }

    std::map<uint16_t, UeMeasurementsElement>::iterator it;
    for (it = m_ueMeasurementsMap.begin(); it != m_ueMeasurementsMap.end(); it++)
    {
        double avg_rsrp;
        double avg_rsrq = 0;
        if ((*it).second.rsrpNum != 0)
        {
            // Samples are accumulated in linear power so that occasional
            // deep-null sidelobe samples (PSS received while the gNB's analog
            // beam points at another UE) do not dominate the average the way
            // they would in a dB-domain mean.
            avg_rsrp = 10 * log10((*it).second.rsrpSum / static_cast<double>((*it).second.rsrpNum));
            // RSRQ = SUBCARRIERS_PER_RB * RSRP / RSSI (per RE): this cell's RS power relative
            // to the total received power (all cells + noise). Interference-aware -- a strong
            // cell in a crowded/interfered zone scores low. (Previously hardcoded to 0 dB.)
            if (rssiPerReLin > 0.0)
            {
                const double rsrpLin = std::pow(10.0, (avg_rsrp - 30.0) / 10.0);
                avg_rsrq = 10.0 * std::log10(rsrpLin / (NrSpectrumValueHelper::SUBCARRIERS_PER_RB *
                                                        rssiPerReLin));
            }
        }
        else
        {
            NS_LOG_WARN(" RSRP nSamples is zero!");
            avg_rsrp = 0;
        }

        NS_LOG_DEBUG(" Report UE Measurements for CellId "
                     << (*it).first << " Reporting UE " << m_rnti << " Av. RSRP " << avg_rsrp
                     << " (nSamples " << +((*it).second.rsrpNum) << ")"
                     << " BwpID " << GetBwpId());

        m_reportRsrpTrace(GetCellId(), m_imsi, m_rnti, avg_rsrp, GetBwpId());

        // PdcchErrorModel, cell search: without a connection the UE finds a cell only if it can
        // receive it, i.e. the mean PDCCH block error rate of its synchronisation signals of
        // this period was below 2 %, the in-sync level. The traces still show every cell.
        bool found = true;
        if (m_pdcchErrorModel && !m_isConnected)
        {
            const auto bler = m_pssBler.find((*it).first);
            found = bler != m_pssBler.end() && bler->second.second > 0 &&
                    bler->second.first / bler->second.second < 0.02;
            NS_LOG_INFO("Cell search of IMSI "
                        << m_imsi << ": cell " << (*it).first << (found ? " found" : " not found")
                        << ", mean PDCCH block error rate "
                        << (bler != m_pssBler.end() && bler->second.second > 0
                                ? bler->second.first / bler->second.second
                                : 1.0)
                        << " over " << (bler != m_pssBler.end() ? bler->second.second : 0)
                        << " synchronisation signals");
        }
        if (found)
        {
            NrUeCphySapUser::UeMeasurementsElement newEl;
            newEl.m_cellId = (*it).first;
            newEl.m_rsrp = avg_rsrp;
            newEl.m_rsrq = avg_rsrq; // interference-aware RSRQ (RSRP/RSSI), computed above
            ret.m_ueMeasurementsList.push_back(newEl);
        }
        ret.m_componentCarrierId = GetBwpId();

        m_reportUeMeasurements(m_rnti,
                               (*it).first,
                               avg_rsrp,
                               avg_rsrq,
                               (*it).first == GetCellId(),
                               ret.m_componentCarrierId);
    }

    // report to RRC
    m_ueCphySapUser->ReportUeMeasurements(ret);

    m_ueMeasurementsMap.clear();
    m_pssBler.clear();
    Simulator::Schedule(m_ueMeasurementsFilterPeriod, &NrUePhy::ReportUeMeasurements, this);
}

void
NrUePhy::SetCsiFeedbackType(uint8_t csiFeedbackType)
{
    m_csiFeedbackType = csiFeedbackType;
}

void
NrUePhy::ReportDlCtrlSinr(const SpectrumValue& sinr)
{
    NS_LOG_FUNCTION(this);
    uint32_t rbUsed = 0;
    double sinrSum = 0.0;

    for (uint32_t i = 0; i < sinr.GetValuesN(); i++)
    {
        double currentSinr = sinr.ValuesAt(i);
        if (currentSinr != 0)
        {
            rbUsed++;
            sinrSum += currentSinr;
        }
    }

    NS_ASSERT(rbUsed);
    m_ctrlSinrForRlf = sinr;
    m_dlCtrlSinrTrace(GetCellId(), m_rnti, sinrSum / rbUsed, GetBwpId());
    ReportPdcchSinr(10 * log10(ComputeAvgSinr(m_ctrlSinrForRlf)));

    // trigger RLF detection only when UE has an active RRC connection
    // and RLF detection attribute is set to true
    if (m_isConnected && m_enableRlfDetection)
    {
        RlfDetection(10 * log10(ComputeAvgSinr(m_ctrlSinrForRlf)));
    }
}

uint8_t
NrUePhy::ComputeCqi(const SpectrumValue& sinr)
{
    NS_LOG_FUNCTION(this);
    uint8_t mcs; // it is initialized by AMC in the following call
    uint8_t wbCqi = m_amc->CreateCqiFeedbackSiso(sinr, mcs);
    return wbCqi;
}

void
NrUePhy::StartEventLoop(uint16_t frame, uint8_t subframe, uint16_t slot)
{
    NS_LOG_FUNCTION(this);

    if (GetChannelBandwidth() == 0)
    {
        NS_LOG_INFO("Initial bandwidth not set, configuring the default one for Cell ID: "
                    << GetCellId() << ", RNTI: " << GetRnti() << ", BWP ID: " << GetBwpId());
        if (GetSubcarrierSpacing() == 0)
        {
            NS_LOG_INFO("No numerology was set, assuming numerology 0 for Cell ID: "
                        << GetCellId() << ", RNTI: " << GetRnti() << ", BWP ID: " << GetBwpId());
            SetNumerology(0);
        }
        DoSetInitialBandwidth();
    }

    NS_LOG_INFO("PHY starting. Configuration: "
                << std::endl
                << "\t TxPower: " << m_txPower << " dBm" << std::endl
                << "\t NoiseFigure: " << m_noiseFigure << std::endl
                << "\t TbDecodeLatency: " << GetTbDecodeLatency().GetMicroSeconds() << " us "
                << std::endl
                << "\t Numerology: " << GetNumerology() << std::endl
                << "\t SymbolsPerSlot: " << GetSymbolsPerSlot() << std::endl
                << "\t Pattern: " << NrPhy::GetPattern(m_tddPattern) << std::endl
                << "Attached to physical channel: " << std::endl
                << "\t Channel bandwidth: " << GetChannelBandwidth() << " Hz" << std::endl
                << "\t Channel central freq: " << GetCentralFrequency() << " Hz" << std::endl
                << "\t Num. RB: " << GetRbNum());
    SfnSf startSlot(frame, subframe, slot, GetNumerology());
    StartSlot(startSlot);
}

void
NrUePhy::DoSetInitialBandwidth()
{
    NS_LOG_FUNCTION(this);
    // configure initial bandwidth to 6 RBs, numerology 0
    double initialBandwidthHz =
        6 * GetSubcarrierSpacing() * NrSpectrumValueHelper::SUBCARRIERS_PER_RB;
    // divided by 100*1000 because the parameter should be in 100KHz
    uint16_t initialBandwidthIn100KHz = ceil(initialBandwidthHz / (100 * 1000));
    // account for overhead that will be reduced when determining real BW
    uint16_t initialBandwidthWithOverhead = initialBandwidthIn100KHz / (1 - GetRbOverhead());

    NS_ABORT_MSG_IF(initialBandwidthWithOverhead == 0,
                    " Initial bandwidth could not be set. Parameters provided are: "
                    "\n dlBandwidthInRBNum = "
                        << 6 << "\n m_subcarrierSpacing = " << GetSubcarrierSpacing()
                        << "\n NrSpectrumValueHelper::SUBCARRIERS_PER_RB  = "
                        << (unsigned)NrSpectrumValueHelper::SUBCARRIERS_PER_RB
                        << "\n m_rbOh = " << GetRbOverhead());

    DoSetDlBandwidth(initialBandwidthWithOverhead);
}

uint16_t
NrUePhy::DoGetCellId() const
{
    return GetCellId();
}

void
NrUePhy::DoSetDlBandwidth(uint16_t dlBandwidth)
{
    NS_LOG_FUNCTION(this << +dlBandwidth);

    SetChannelBandwidth(dlBandwidth);

    NS_LOG_DEBUG("PHY reconfiguring. Result: "
                 << std::endl
                 << "\t TxPower: " << m_txPower << " dBm" << std::endl
                 << "\t NoiseFigure: " << m_noiseFigure << std::endl
                 << "\t TbDecodeLatency: " << GetTbDecodeLatency().GetMicroSeconds() << " us "
                 << std::endl
                 << "\t Numerology: " << GetNumerology() << std::endl
                 << "\t SymbolsPerSlot: " << GetSymbolsPerSlot() << std::endl
                 << "\t Pattern: " << NrPhy::GetPattern(m_tddPattern) << std::endl
                 << "Attached to physical channel: " << std::endl
                 << "\t Channel bandwidth: " << GetChannelBandwidth() << " Hz" << std::endl
                 << "\t Channel central freq: " << GetCentralFrequency() << " Hz" << std::endl
                 << "\t Num. RB: " << GetRbNum());
}

void
NrUePhy::DoConfigureUplink(uint16_t arfcn, uint8_t ulBandwidth)
{
    NS_LOG_FUNCTION(this << arfcn << +ulBandwidth);
    // Ignore this; should be equal to dlBandwidth
    m_ulConfigured = true;
}

void
NrUePhy::DoConfigureReferenceSignalPower(int8_t referenceSignalPower)
{
    NS_LOG_FUNCTION(this << referenceSignalPower);
    m_powerControl->ConfigureReferenceSignalPower(referenceSignalPower);
}

void
NrUePhy::DoSetRnti(uint16_t rnti)
{
    NS_LOG_FUNCTION(this << rnti);
    GetSpectrumPhy()->SetRnti(rnti);
    m_rnti = rnti;
}

void
NrUePhy::DoSetTransmissionMode(uint8_t txMode)
{
    NS_LOG_FUNCTION(this << +txMode);
}

void
NrUePhy::DoSetSrsConfigurationIndex(uint16_t srcCi)
{
    NS_LOG_FUNCTION(this << srcCi);
}

void
NrUePhy::SetPhySapUser(NrUePhySapUser* ptr)
{
    m_phySapUser = ptr;
}

void
NrUePhy::NotifyConnectionSuccessful()
{
    m_isConnected = true;
    m_spsActiveConfig = {{-1, -1}}; // a new connection has no active configuration
    // Initialize the parameters for radio link failure detection
    InitializeRlfParams();
}

void
NrUePhy::DoResetPhyAfterRlf()
{
    NS_LOG_FUNCTION(this);
    // m_spectrumPhy->m_harqPhyModule->ClearDlHarqBuffer(m_rnti); // flush HARQ buffers
    ClearRntiSlotAllocInfo(m_rnti);
    DoSetCellId(0);
    DoReset();
}

void
NrUePhy::DoResetRlfParams()
{
    NS_LOG_FUNCTION(this);
    InitializeRlfParams();
}

void
NrUePhy::DoStartInSyncDetection()
{
    NS_LOG_FUNCTION(this);
    // indicates that the downlink radio link quality has to be monitored for in-sync indications
    m_downlinkInSync = false;
}

void
NrUePhy::InitializeRlfParams()
{
    NS_LOG_FUNCTION(this);
    m_numOfSubframes = 0;
    m_sinrDbFrame = 0;
    m_numOfFrames = 0;
    m_downlinkInSync = true;
    m_rlmFrame = -1;
    m_rlmSamples.clear();
}

// The PdcchErrorModel attribute.
//
// The module has no error model for the control channels: every DCI reaches its UE, whatever
// the SINR. A UE far below Qout therefore keeps receiving and sending data while its radio link
// monitoring reports it out of sync, declares a radio link failure every few seconds and is
// back a moment later. With this attribute the PDCCH has a block error rate, and three things
// follow from the same curve.
//
// The curve. Qout and Qin are by definition the levels at which a hypothetical PDCCH has a
// block error rate of 10 % and of 2 % (TS 38.133 8.1.1; the attributes Qout and Qin are these
// levels as SINR). The model takes these two points and a normal curve in dB through them:
// P(miss) = Q((SINR - s50) / sigma). With the defaults, Qout = -5 dB and Qin = -3.9 dB:
// sigma = 1.42 dB, 50 % at -6.8 dB, 99 % at -10.1 dB, 0.1 % at -2.4 dB. The SINR is the one of
// one control symbol, the mean over its resource blocks.
//
// 1. Scheduling. A downlink assignment or an uplink grant is missed with that probability, at
//    the SINR of the control symbol that carries it.
//      downlink assignment  the UE does not receive the transport block and keeps nothing of it
//                           for HARQ; the gNB gets no ACK and sends the next redundancy version
//                           (here the UE answers NACK, which is what the gNB makes of no answer)
//      uplink grant         the UE sends nothing; the gNB finds no transport block and grants
//                           the retransmission (here the UE does send and the gNB receiver
//                           discards the block: the same outcome, without touching the UE MAC)
// 2. Radio link monitoring, as TS 38.213 5 and TS 38.133 8.1 describe it, in place of the
//    counting of DL CTRL symbols (ten symbols a "frame", NumQoutEvalSf / 10 such frames in a row
//    below Qout for one indication; the gNB sends a DL CTRL symbol only in slots that carry a
//    control message, so these periods last longer the fewer UEs are active). Here the link
//    quality is assessed once per 10 ms frame:
//      out-of-sync  the mean PDCCH block error rate of the control symbols of the last
//                   NumQoutEvalSf ms (200) is above 10 %
//      in-sync      that of the last NumQinEvalSf ms (100) is below 2 %
//    The RRC counts as before: N310 out-of-sync indications in a row start T310, N311 in-sync
//    indications in a row stop it, and when it expires the radio link has failed. An in-sync
//    indication ends a row of out-of-sync indications and the other way round; a frame that
//    is neither leaves the count as it is. Nothing is assessed before a full period has passed
//    since the connection was set up.
// 3. Cell search. While the UE has no connection, it reports a cell to its RRC only if the
//    mean PDCCH block error rate of the synchronisation signals received from it during the
//    measurement period (UeMeasurementsFilterPeriod) was below 2 %, the in-sync level. So a UE
//    that lost its radio link attaches again when the cell can be received again and not
//    before; until then it has no service. A UE attached by hand (NrHelper::AttachToGnb) is not
//    asked.
//
// Not covered: MIB, SIB1, the random access response and the RRC messages, and everything in
// the uplink control channel (HARQ feedback, scheduling requests, CQI) always arrive.

double
NrUePhy::PdcchBlockErrorRate(double sinrDb, double qOutDb, double qInDb)
{
    NS_ABORT_MSG_UNLESS(qInDb > qOutDb, "NrUePhy::Qin must be above NrUePhy::Qout");
    // P(miss) = Q((sinr - s50) / sigma), with Q(1.2816) = 0.10 at Qout and Q(2.0537) = 0.02 at Qin
    const double z10 = 1.2815515655446004;
    const double z02 = 2.0537489106318225;
    const double sigma = (qInDb - qOutDb) / (z02 - z10);
    const double s50 = qOutDb - z10 * sigma;
    return 0.5 * std::erfc((sinrDb - s50) / (sigma * M_SQRT2));
}

void
NrUePhy::RlmBler(double sinrDb, double* blerOut, double* blerIn) const
{
    const Ptr<NrPdcch> pdcch = m_rlmFromPdcchTable ? NrPdcch::Find(GetCellId()) : nullptr;
    if (pdcch && pdcch->IsEnabled())
    {
        // TS 38.133 Tables 8.1.2.1-1 and -2: the hypothetical PDCCH of the out-of-sync
        // evaluation has aggregation level 8 and 4 dB more energy per resource element than the
        // reference signal, the one of the in-sync evaluation level 4 and the same energy
        *blerOut = pdcch->GetBler(8, sinrDb, 4.0);
        *blerIn = pdcch->GetBler(4, sinrDb, 0.0);
    }
    else
    {
        *blerOut = *blerIn = PdcchBlockErrorRate(sinrDb, m_qOut, m_qIn);
    }
}

void
NrUePhy::ReportPdcchSinr(double sinrDb)
{
    if (!m_isConnected || !m_ulConfigured || m_rnti == 0 || m_pdcchSinrReportPeriod.IsZero() ||
        Simulator::Now() < m_pdcchSinrReportNext)
    {
        return;
    }
    const Ptr<NrPdcch> pdcch = NrPdcch::Find(GetCellId());
    if (!pdcch || !pdcch->IsEnabled())
    {
        return;
    }
    m_pdcchSinrReportNext = Simulator::Now() + m_pdcchSinrReportPeriod;
    // An L1-SINR report: 7 bits, from -23 to 40 dB in steps of 0.5 dB (TS 38.214 5.2.1.4)
    DlCqiInfo report;
    report.m_rnti = m_rnti;
    report.m_sinrDb = std::clamp(std::floor(sinrDb * 2.0) / 2.0, -23.0, 40.0);
    report.m_sinrOnly = true;
    Ptr<NrDlCqiMessage> msg = Create<NrDlCqiMessage>();
    msg->SetSourceBwpArfcn(DoGetArfcn());
    msg->SetDlCqi(report);
    DoSendControlMessage(msg);
}

void
NrUePhy::MarkMissedDcis(const std::list<Ptr<NrControlMessage>>& msgs)
{
    if (m_rnti == 0)
    {
        return;
    }
    const Ptr<NrPdcch> found = NrPdcch::Find(GetCellId());
    const Ptr<NrPdcch> pdcch = found && found->IsEnabled() ? found : nullptr;
    const bool errors = m_pdcchErrorModel && m_ctrlSinrForRlf.GetValuesN() != 0;
    if (!pdcch && !errors)
    {
        return;
    }
    for (const auto& msg : msgs)
    {
        std::shared_ptr<DciInfoElementTdma> dci;
        bool uplinkGrant = false;
        if (msg->GetMessageType() == NrControlMessage::DL_DCI)
        {
            dci = DynamicCast<NrDlDciMessage>(msg)->GetDciInfoElement();
        }
        else if (msg->GetMessageType() == NrControlMessage::UL_DCI)
        {
            dci = DynamicCast<NrUlDciMessage>(msg)->GetDciInfoElement();
            uplinkGrant = true;
        }
        if (!dci || dci->m_rnti != m_rnti || dci->m_type != DciInfoElementTdma::DATA)
        {
            continue;
        }
        auto& activeConfig = m_spsActiveConfig[uplinkGrant ? 1 : 0];
        auto& activeSerial = m_spsActiveSerial[uplinkGrant ? 1 : 0];
        if (dci->m_sps == DciInfoElementTdma::SPS_OCCASION)
        {
            // A block of a semi-persistent configuration (downlink) or of a configured grant
            // (uplink): no PDCCH, so nothing to miss. But the UE knows of it only if it decoded
            // the DCI that activated the configuration, and the last one of them: an earlier
            // activation put the block elsewhere or gave it another MCS.
            if (activeConfig != dci->m_spsConfig || activeSerial != dci->m_spsSerial)
            {
                dci->m_pdcchMissed = true;
                if (pdcch)
                {
                    pdcch->NoteEvent(uplinkGrant ? NrPdcch::UL_CG_LOST_CONFIG
                                                 : NrPdcch::DL_SPS_LOST_CONFIG);
                }
            }
            continue;
        }
        if (errors)
        {
            if (!m_pdcchErrorRv)
            {
                // A stream of its own for each UE and BWP, so that turning the model on does not
                // move any other random variable of the simulation to another stream
                m_pdcchErrorRv = CreateObject<UniformRandomVariable>();
                m_pdcchErrorRv->SetStream(770000000 + static_cast<int64_t>(m_imsi) * 16 +
                                          GetBwpId());
            }
            const double sinrDb = 10 * log10(ComputeAvgSinr(m_ctrlSinrForRlf));
            // With the PDCCH model on: the block error rate of the aggregation level this DCI
            // was sent at. Without: the curve through Qout and Qin.
            const double bler = pdcch && dci->m_pdcchAl > 0
                                    ? pdcch->GetBler(dci->m_pdcchAl, sinrDb)
                                    : PdcchBlockErrorRate(sinrDb, m_qOut, m_qIn);
            dci->m_pdcchMissed = m_pdcchErrorRv->GetValue() < bler;
            m_pdcchReceptionTrace(m_rnti, sinrDb, uplinkGrant, dci->m_pdcchMissed);
        }
        if (pdcch && dci->m_pdcchAl > 0)
        {
            pdcch->NoteReception(dci->m_pdcchAl, dci->m_pdcchMissed);
        }
        if (!dci->m_pdcchMissed)
        {
            if (dci->m_sps == DciInfoElementTdma::SPS_ACTIVATION)
            {
                activeConfig = dci->m_spsConfig;
                activeSerial = dci->m_spsSerial;
            }
            else if (dci->m_sps == DciInfoElementTdma::SPS_RELEASE &&
                     activeConfig == dci->m_spsConfig)
            {
                activeConfig = -1;
            }
        }
    }
}

void
NrUePhy::RlmAssess(int64_t frameEndNs)
{
    NS_LOG_FUNCTION(this << frameEndNs);
    const int64_t outNs = static_cast<int64_t>(m_numOfQoutEvalSf) * 1000000;
    const int64_t inNs = static_cast<int64_t>(m_numOfQinEvalSf) * 1000000;
    double outSum = 0.0;
    double inSum = 0.0;
    uint32_t outN = 0;
    uint32_t inN = 0;
    for (auto it = m_rlmSamples.rbegin(); it != m_rlmSamples.rend(); ++it)
    {
        const int64_t age = frameEndNs - it->ns;
        if (age >= outNs && age >= inNs)
        {
            break; // this one and all before it are older than both periods
        }
        if (age < outNs)
        {
            outSum += it->blerOut;
            ++outN;
        }
        if (age < inNs)
        {
            inSum += it->blerIn;
            ++inN;
        }
    }
    // A period that has not passed in full since the samples started says nothing yet
    const int64_t collected = frameEndNs - m_rlmStartNs;
    const bool outOfSync = outN > 0 && collected >= outNs && outSum / outN > 0.10;
    const bool inSync = inN > 0 && collected >= inNs && inSum / inN < 0.02;
    if (m_downlinkInSync)
    {
        // N310 out-of-sync indications in a row start T310 and the in-sync detection
        if (outOfSync)
        {
            m_ueCphySapUser->NotifyOutOfSync();
        }
        else if (inSync)
        {
            m_ueCphySapUser->ResetSyncIndicationCounter();
        }
    }
    else
    {
        // T310 is running: N311 in-sync indications in a row stop it and reset everything
        if (inSync)
        {
            m_ueCphySapUser->NotifyInSync();
        }
        else if (outOfSync)
        {
            m_ueCphySapUser->ResetSyncIndicationCounter();
        }
    }
}

void
NrUePhy::RlfDetection(double sinrDb)
{
    NS_LOG_FUNCTION(this << sinrDb);
    if (m_pdcchErrorModel)
    {
        // Radio link monitoring by the PDCCH block error rate, once per 10 ms frame on the clock
        // (see PdcchErrorModel above). The control symbol at hand may be the first of a new
        // frame: then the frames that have ended since the last symbol are assessed first.
        const int64_t now = Simulator::Now().GetNanoSeconds();
        const int64_t frameNs = 10000000;
        const int64_t frame = now / frameNs;
        if (m_rlmFrame < 0)
        {
            m_rlmStartNs = now;
        }
        else
        {
            for (int64_t ended = m_rlmFrame; ended < frame && m_rlmFrame >= 0; ++ended)
            {
                RlmAssess((ended + 1) * frameNs); // may end in InitializeRlfParams()
            }
            if (m_rlmFrame < 0)
            {
                m_rlmStartNs = now;
            }
        }
        m_rlmFrame = frame;
        RlmSample sample;
        sample.ns = now;
        RlmBler(sinrDb, &sample.blerOut, &sample.blerIn);
        m_rlmSamples.push_back(sample);
        const int64_t keepNs =
            static_cast<int64_t>(std::max(m_numOfQoutEvalSf, m_numOfQinEvalSf)) * 1000000 + frameNs;
        while (now - m_rlmSamples.front().ns > keepNs)
        {
            m_rlmSamples.pop_front();
        }
        return;
    }
    m_sinrDbFrame += sinrDb;
    m_numOfSubframes++;
    NS_LOG_LOGIC("No of Subframes: " << m_numOfSubframes
                                     << " UE synchronized: " << m_downlinkInSync);
    // check for out_of_sync indications first when UE is both DL and UL synchronized
    // m_downlinkInSync=true indicates that the evaluation is for out-of-sync indications
    if (m_downlinkInSync && m_numOfSubframes == 10)
    {
        /**
         * For every frame, if the downlink radio link quality(avg SINR)
         * is less than the threshold Qout, then the frame cannot be decoded
         */
        if ((m_sinrDbFrame / m_numOfSubframes) < m_qOut)
        {
            m_numOfFrames++; // increment the counter if a frame cannot be decoded
            NS_LOG_LOGIC("No of Frames which cannot be decoded: " << m_numOfFrames);
        }
        else
        {
            /**
             * If the downlink radio link quality(avg SINR) is greater
             * than the threshold Qout, then the frame counter is reset
             * since only consecutive frames should be considered.
             */
            NS_LOG_INFO("Resetting frame counter at phy. Current value = " << m_numOfFrames);
            m_numOfFrames = 0;
            // Also reset the sync indicator counter at RRC
            m_ueCphySapUser->ResetSyncIndicationCounter();
        }
        m_numOfSubframes = 0;
        m_sinrDbFrame = 0;
    }
    /**
     * Once the number of consecutive frames which cannot be decoded equals
     * the Qout evaluation period (i.e 200ms), then an out-of-sync indication
     * is sent to the RRC layer
     */
    if (m_downlinkInSync && (m_numOfFrames * 10) == m_numOfQoutEvalSf)
    {
        NS_LOG_LOGIC("At " << Simulator::Now().As(Time::MS)
                           << " ms UE PHY sending out of sync indication to UE RRC layer");
        m_ueCphySapUser->NotifyOutOfSync();
        m_numOfFrames = 0;
    }
    // check for in_sync indications when T310 timer is started
    // m_downlinkInSync=false indicates that the evaluation is for in-sync indications
    if (!m_downlinkInSync && m_numOfSubframes == 10)
    {
        /**
         * For every frame, if the downlink radio link quality(avg SINR)
         * is greater than the threshold Qin, then the frame can be
         * successfully decoded.
         */
        if ((m_sinrDbFrame / m_numOfSubframes) > m_qIn)
        {
            m_numOfFrames++; // increment the counter if a frame can be decoded
            NS_LOG_LOGIC("No of Frames successfully decoded: " << m_numOfFrames);
        }
        else
        {
            /**
             * If the downlink radio link quality(avg SINR) is less
             * than the threshold Qin, then the frame counter is reset
             * since only consecutive frames should be considered
             */
            m_numOfFrames = 0;
            // Also reset the sync indicator counter at RRC
            m_ueCphySapUser->ResetSyncIndicationCounter();
        }
        m_numOfSubframes = 0;
        m_sinrDbFrame = 0;
    }
    /**
     * Once the number of consecutive frames which can be decoded equals the Qin evaluation period
     * (i.e 100ms), then an in-sync indication is sent to the RRC layer
     */
    if (!m_downlinkInSync && (m_numOfFrames * 10) == m_numOfQinEvalSf)
    {
        NS_LOG_LOGIC("At " << Simulator::Now().As(Time::MS)
                           << " ms UE PHY sending in sync indication to UE RRC layer");
        m_ueCphySapUser->NotifyInSync();
        m_numOfFrames = 0;
    }
}

void
NrUePhy::DoSetImsi(uint64_t imsi)
{
    NS_LOG_FUNCTION(this);
    m_imsi = imsi;
}

void
NrUePhy::GenerateDlCqiReportMimo(const NrMimoSignal& rxSignal,
                                 NrPmSearch::PmiUpdate pmiUpdateParams)
{
    NS_LOG_FUNCTION(this);
    // Adopted from NrUePhy::GenerateDlCqiReport: CQI feedback requires properly configured UE
    if (!m_ulConfigured || (m_rnti == 0))
    {
        return;
    }

    // Create DL CQI message for CQI, PMI, and RI. PMI values are updated only if specified by
    // pmiUpdateParams, otherwise assume same PMI values as during last CQI feedback
    auto cqi = m_pmSearch->CreateCqiFeedbackMimo(rxSignal, pmiUpdateParams);
    auto dlcqi = DlCqiInfo{
        .m_rnti = m_rnti,
        .m_ri = cqi.m_rank,
        .m_cqiType = cqi.m_cqiType,
        .m_wbCqi = cqi.m_wbCqi,
        .m_wbPmi = cqi.m_wbPmi,
        .m_sbCqis = cqi.m_sbCqis,
        .m_sbPmis = cqi.m_sbPmis,
        .m_mcs = cqi.m_mcs,
        .m_optPrecMat = cqi.m_optPrecMat,
    };

    m_cqiFeedbackTrace(m_rnti, cqi.m_wbCqi, cqi.m_mcs, cqi.m_rank);

    auto msg = Create<NrDlCqiMessage>();
    msg->SetSourceBwpArfcn(DoGetArfcn());
    msg->SetDlCqi(dlcqi);

    DoSendControlMessage(msg);
}

uint8_t
NrUePhy::GetCsiFeedbackType() const
{
    return m_csiFeedbackType;
}

void
NrUePhy::CsiRsReceived(const std::vector<MimoSignalChunk>& csiRsMimoSignal)
{
    NS_LOG_FUNCTION(this);
    NS_ASSERT(csiRsMimoSignal.size() == 1);
    m_csiRsMimoSignal = NrMimoSignal(csiRsMimoSignal);
    m_lastCsiRsMimoSignalTime = Simulator::Now();
}

void
NrUePhy::GenerateCsiRsCqi()
{
    NS_LOG_FUNCTION(this);

    if (!m_isConnected)
    {
        NS_LOG_DEBUG("UE is disconnected, so not transmitting any CSI feedback.");
        return;
    }
    NS_ASSERT(m_csiRsMimoSignal.m_chanMat.GetSize() != 0);
    NrMimoSignal csiFeedbackSignal = m_csiRsMimoSignal;
    // if there is some old interference information use it,
    // otherwise, just use the plain CSI-RS signal for the CQI feedback
    // (i.e., no interference information). This may happen before any
    // PDSCH for this UE is scheduled, and CSI-IM is disabled.
    if (m_avgIntCovMat.GetSize() != 0)
    {
        csiFeedbackSignal.m_covMat = m_avgIntCovMat;
    }
    TriggerDlCqiGeneration(csiFeedbackSignal, NrPmSearch::PmiUpdate(true, true));
}

void
NrUePhy::CsiImEnded(const std::vector<MimoSignalChunk>& csiImSignalChunks)
{
    NS_LOG_FUNCTION(this);

    if (!m_isConnected)
    {
        NS_LOG_DEBUG("UE is disconnected, so not transmitting any CSI feedback.");
        return;
    }

    // Combine multiple CSI-IM signal chunks into a single channel,
    // and interference covariance
    auto csiFeedbackSignal = NrMimoSignal(csiImSignalChunks);
    CalcAvgIntCovMat(&m_avgIntCovMat, csiFeedbackSignal.m_covMat);
    // CSI-IM does not have RX spectrum channel matrix, because it only contains the interference
    // hence the channel spectrum matrix to be used is from CSI-RS signal
    if (m_alphaCovMat != 1)
    {
        csiFeedbackSignal.m_covMat = m_csiRsMimoSignal.m_covMat;
    }
    csiFeedbackSignal.m_chanMat = m_csiRsMimoSignal.m_chanMat;
    TriggerDlCqiGeneration(csiFeedbackSignal, NrPmSearch::PmiUpdate(true, true));
}

void
NrUePhy::PdschMimoReceived(const std::vector<MimoSignalChunk>& pdschMimoChunks)
{
    NS_LOG_FUNCTION(this);

    if (!m_isConnected)
    {
        NS_LOG_DEBUG("UE is disconnected, so not transmitting any CSI feedback.");
        return;
    }

    // Combine multiple signal chunks into a single channel matrix and interference covariance
    auto csiFeedbackSignal = NrMimoSignal(pdschMimoChunks);
    // if alpha != 1, calculate the interference covariance moving average
    CalcAvgIntCovMat(&m_avgIntCovMat, csiFeedbackSignal.m_covMat);
    if (m_alphaCovMat != 1)
    {
        csiFeedbackSignal.m_covMat = m_avgIntCovMat;
    }
    // if CSI-RS enabled, use the spectrum channel matrix from CSI-RS signal
    if (m_csiFeedbackType & CQI_CSI_RS)
    {
        NS_ASSERT_MSG(m_csiRsMimoSignal.m_chanMat.GetSize(),
                      "CSI-RS based channel matrix not available");
        csiFeedbackSignal.m_chanMat = m_csiRsMimoSignal.m_chanMat;
    }

    // CSI-RS slot, or PDSCH only based CQI feedback
    // Determine if an update to wideband or subband PMI is needed and possible
    auto pmiUpdateParams = CheckUpdatePmi();
    TriggerDlCqiGeneration(csiFeedbackSignal, pmiUpdateParams);
}

void
NrUePhy::TriggerDlCqiGeneration(const NrMimoSignal& csiFeedbackSignal,
                                NrPmSearch::PmiUpdate pmiUpdateParams)
{
    NS_LOG_FUNCTION(this);
    if (m_pmSearch)
    {
        GenerateDlCqiReportMimo(csiFeedbackSignal, pmiUpdateParams);
    }
    else
    {
        // Interference whitening: normalize the signal such that interference + noise covariance
        // matrix is the identity matrix
        auto intfNormChanMat =
            csiFeedbackSignal.m_covMat.CalcIntfNormChannel(csiFeedbackSignal.m_chanMat);
        // Create a dummy precoding matrix
        ComplexMatrixArray precMat = ComplexMatrixArray(
            csiFeedbackSignal.m_chanMat.GetNumCols(),
            csiFeedbackSignal.m_chanMat.GetNumRows(),
            csiFeedbackSignal.m_chanMat.GetNumPages(),
            std::valarray<std::complex<double>>(std::complex<double>(1.0, 0.0),
                                                csiFeedbackSignal.m_chanMat.GetSize()));
        ;

        NrSinrMatrix sinrMatrix = intfNormChanMat.ComputeSinrForPrecoding(precMat);
        GenerateDlCqiReport(sinrMatrix.GetVectorizedSpecVal());
    }
}

void
NrUePhy::CalcAvgIntCovMat(NrCovMat* avgIntCovMat, const NrCovMat& newCovMat) const
{
    NS_LOG_FUNCTION(this);
    if (avgIntCovMat->GetSize() == 0)
    {
        *avgIntCovMat = ComplexMatrixArray(newCovMat.GetNumRows(),
                                           newCovMat.GetNumCols(),
                                           newCovMat.GetNumPages());
    }

    *avgIntCovMat = newCovMat * std::complex<double>{m_alphaCovMat, 0.0} +
                    *avgIntCovMat * std::complex<double>{1 - m_alphaCovMat, 0.0};
}

NrPmSearch::PmiUpdate
NrUePhy::CheckUpdatePmi()
{
    // This implementation only checks if sufficient time has passed since the last update.
    // TODO: Improve following logic that defines when to update wideband and/or
    // subband PMIs for two-stage codebooks. The algorithm must allow managing the computational
    // complexity of PMI updates, and take into account availability of PUCCH/PUSCH resources for
    // sending PMI.
    auto pmiUpdate = NrPmSearch::PmiUpdate{};
    auto now = Simulator::Now();
    if (now > m_wbPmiLastUpdate + m_wbPmiUpdateInterval)
    {
        pmiUpdate.updateWb = true;
        m_wbPmiLastUpdate = now;
    }
    if (now > m_sbPmiLastUpdate + m_sbPmiUpdateInterval)
    {
        pmiUpdate.updateSb = true;
        m_sbPmiLastUpdate = now;
    }
    return pmiUpdate;
}

void
NrUePhy::SetPmSearch(Ptr<NrPmSearch> pmSearch)
{
    m_pmSearch = pmSearch;
    NS_ASSERT(m_amc);
    m_pmSearch->SetAmc(m_amc);
}

Ptr<NrPmSearch>
NrUePhy::GetPmSearch() const
{
    return m_pmSearch;
}

} // namespace ns3
