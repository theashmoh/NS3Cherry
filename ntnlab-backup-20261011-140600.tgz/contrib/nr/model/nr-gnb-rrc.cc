// Copyright (c) 2011 Centre Tecnologic de Telecomunicacions de Catalunya (CTTC)
// Copyright (c) 2018 Fraunhofer ESK : RLF extensions
//
// SPDX-License-Identifier: GPL-2.0-only
//
// Authors:
//   Nicola Baldo <nbaldo@cttc.es>
//   Marco Miozzo <mmiozzo@cttc.es>
//   Manuel Requena <manuel.requena@cttc.es>
// Modified by:
//   Danilo Abrignani <danilo.abrignani@unibo.it> (Carrier Aggregation - GSoC 2015),
//   Biljana Bojovic <biljana.bojovic@cttc.es> (Carrier Aggregation)
//   Vignesh Babu <ns3-dev@esk.fraunhofer.de> (RLF extensions)

#include "nr-gnb-rrc.h"

#include "bandwidth-part-gnb.h"
#include "nr-common.h"
#include "nr-gnb-mac.h"
#include "nr-pdcp.h"
#include "nr-qos-flow-tag.h"
#include "nr-radio-bearer-info.h"
#include "nr-rlc-am.h"
#include "nr-rlc-tm.h"
#include "nr-rlc-um.h"
#include "nr-rlc.h"

#include "ns3/abort.h"
#include "ns3/fatal-error.h"
#include "ns3/log.h"
#include "ns3/object-factory.h"
#include "ns3/object-map.h"
#include "ns3/packet.h"
#include "ns3/pointer.h"
#include "ns3/simulator.h"

#include <optional>

namespace ns3
{

NS_LOG_COMPONENT_DEFINE("NrGnbRrc");

///////////////////////////////////////////
// CMAC SAP forwarder
///////////////////////////////////////////

/**
 * @brief Class for forwarding CMAC SAP User functions.
 */
class GnbRrcMemberNrGnbCmacSapUser : public NrGnbCmacSapUser
{
  public:
    /**
     * Constructor
     *
     * @param rrc gNB RRC
     * @param componentCarrierId
     */
    GnbRrcMemberNrGnbCmacSapUser(NrGnbRrc* rrc, uint8_t componentCarrierId);

    uint16_t AllocateTemporaryCellRnti() override;
    void NotifyLcConfigResult(uint16_t rnti, uint8_t lcid, bool success) override;
    void RrcConfigurationUpdateInd(UeConfig params) override;
    bool IsRandomAccessCompleted(uint16_t rnti) override;

  private:
    NrGnbRrc* m_rrc;              ///< the RRC
    uint8_t m_componentCarrierId; ///< Component carrier ID
};

GnbRrcMemberNrGnbCmacSapUser::GnbRrcMemberNrGnbCmacSapUser(NrGnbRrc* rrc,
                                                           uint8_t componentCarrierId)
    : m_rrc(rrc),
      m_componentCarrierId{componentCarrierId}
{
}

uint16_t
GnbRrcMemberNrGnbCmacSapUser::AllocateTemporaryCellRnti()
{
    return m_rrc->DoAllocateTemporaryCellRnti(m_componentCarrierId);
}

void
GnbRrcMemberNrGnbCmacSapUser::NotifyLcConfigResult(uint16_t rnti, uint8_t lcid, bool success)
{
    m_rrc->DoNotifyLcConfigResult(rnti, lcid, success);
}

void
GnbRrcMemberNrGnbCmacSapUser::RrcConfigurationUpdateInd(UeConfig params)
{
    m_rrc->DoRrcConfigurationUpdateInd(params);
}

bool
GnbRrcMemberNrGnbCmacSapUser::IsRandomAccessCompleted(uint16_t rnti)
{
    return m_rrc->IsRandomAccessCompleted(rnti);
}

///////////////////////////////////////////
// NrUeManager
///////////////////////////////////////////

/// Map each of UE Manager states to its string representation.
const std::string
ToString(NrUeManager::State state)
{
    switch (state)
    {
    case NrUeManager::INITIAL_RANDOM_ACCESS:
        return "INITIAL_RANDOM_ACCESS";
    case NrUeManager::CONNECTION_SETUP:
        return "CONNECTION_SETUP";
    case NrUeManager::CONNECTION_REJECTED:
        return "CONNECTION_REJECTED";
    case NrUeManager::ATTACH_REQUEST:
        return "ATTACH_REQUEST";
    case NrUeManager::CONNECTED_NORMALLY:
        return "CONNECTED_NORMALLY";
    case NrUeManager::CONNECTION_RECONFIGURATION:
        return "CONNECTION_RECONFIGURATION";
    case NrUeManager::CONNECTION_REESTABLISHMENT:
        return "CONNECTION_REESTABLISHMENT";
    case NrUeManager::HANDOVER_PREPARATION:
        return "HANDOVER_PREPARATION";
    case NrUeManager::HANDOVER_JOINING:
        return "HANDOVER_JOINING";
    case NrUeManager::HANDOVER_PATH_SWITCH:
        return "HANDOVER_PATH_SWITCH";
    case NrUeManager::HANDOVER_LEAVING:
        return "HANDOVER_LEAVING";
    default:
        return "UNKNOWN_STATE";
    }
}

std::ostream&
operator<<(std::ostream& os, NrUeManager::State state)
{
    os << ToString(state);
    return os;
}

NS_OBJECT_ENSURE_REGISTERED(NrUeManager);

NrUeManager::NrUeManager()
{
    NS_FATAL_ERROR("this constructor is not expected to be used");
}

NrUeManager::NrUeManager(Ptr<NrGnbRrc> rrc, uint16_t rnti, State s, uint8_t componentCarrierId)
    : m_lastAllocatedDrbid(2),
      m_rnti(rnti),
      m_imsi(0),
      m_componentCarrierId(componentCarrierId),
      m_primaryBwpId(componentCarrierId),
      m_lastRrcTransactionIdentifier(0),
      m_rrc(rrc),
      m_state(s),
      m_pendingRrcConnectionReconfiguration(false),
      m_sourceX2apId(0),
      m_sourceCellId(0),
      m_needPhyMacConfiguration(false),
      m_caSupportConfigured(false),
      m_pendingStartDataRadioBearers(false)
{
    NS_LOG_FUNCTION(this);
}

void
NrUeManager::Configure()
{
    NS_LOG_FUNCTION(this);
    ConfigureSap();
    ConfigureSrb0();
    ConfigureSrb1();
    ConfigureMacPhy();
}

void
NrUeManager::ConfigureSap()
{
    NS_LOG_FUNCTION(this);
    m_drbPdcpSapUser = new NrPdcpSpecificNrPdcpSapUser<NrUeManager>(this);

    m_physicalConfigDedicated.haveAntennaInfoDedicated = true;
    m_physicalConfigDedicated.antennaInfo.transmissionMode = m_rrc->m_defaultTransmissionMode;
    m_physicalConfigDedicated.haveSoundingRsUlConfigDedicated = true;
    m_physicalConfigDedicated.soundingRsUlConfigDedicated.srsConfigIndex =
        m_rrc->GetNewSrsConfigurationIndex();
    m_physicalConfigDedicated.soundingRsUlConfigDedicated.type =
        NrRrcSap::SoundingRsUlConfigDedicated::SETUP;
    m_physicalConfigDedicated.soundingRsUlConfigDedicated.srsBandwidth = 0;
    m_physicalConfigDedicated.havePdschConfigDedicated = true;
    m_physicalConfigDedicated.pdschConfigDedicated.pa = NrRrcSap::PdschConfigDedicated::dB0;

    for (uint16_t i = 0; i < m_rrc->m_numberOfComponentCarriers; i++)
    {
        m_rrc->m_cmacSapProvider.at(i)->AddUe(m_rnti);
        m_rrc->m_cphySapProvider.at(i)->AddUe(m_rnti);
    }
}

void
NrUeManager::ConfigureSrb0()
{
    NS_LOG_FUNCTION(this);
    // setup the gNB side of SRB0
    {
        uint8_t lcid = 0;

        Ptr<NrRlc> rlc = CreateObject<NrRlcTm>()->GetObject<NrRlc>();
        rlc->SetNrMacSapProvider(m_rrc->m_macSapProvider);
        rlc->SetRnti(m_rnti);
        rlc->SetLcId(lcid);

        m_srb0 = CreateObject<NrSignalingRadioBearerInfo>();
        m_srb0->m_rlc = rlc;
        m_srb0->m_srbIdentity = 0;
        // no need to store logicalChannelConfig as SRB0 is pre-configured

        NrGnbCmacSapProvider::LcInfo lcinfo;
        lcinfo.rnti = m_rnti;
        lcinfo.lcId = lcid;
        // Initialise the rest of lcinfo structure even if CCCH (LCID 0) is pre-configured, and only
        // m_rnti and lcid will be used from passed lcinfo structure. See FF LTE MAC Scheduler
        // Iinterface Specification v1.11, 4.3.4 logicalChannelConfigListElement
        lcinfo.lcGroup = 0;
        lcinfo.fiveQi = 5; // Arbitrary 5QI to route UE RRC UL messages through BWP manager
        lcinfo.resourceType = 0;
        lcinfo.mbrUl = 0;
        lcinfo.mbrDl = 0;
        lcinfo.gbrUl = 0;
        lcinfo.gbrDl = 0;

        // MacSapUserForRlc in the ComponentCarrierManager MacSapUser
        NrMacSapUser* nrMacSapUser =
            m_rrc->m_ccmRrcSapProvider->ConfigureSignalBearer(lcinfo, rlc->GetNrMacSapUser());
        // Install signal channel on all carriers.
        // Just avoiding issues when carrier is strictly downlink or uplink,
        // But messages still need to be routed properly to primary downlink and uplink carriers.
        for (uint16_t i = 0; i < m_rrc->m_numberOfComponentCarriers; i++)
        {
            m_rrc->m_cmacSapProvider.at(i)->AddLc(lcinfo, nrMacSapUser);
        }
        m_rrc->m_ccmRrcSapProvider->AddLc(lcinfo, nrMacSapUser);
    }
}

void
NrUeManager::ConfigureSrb1()
{
    NS_LOG_FUNCTION(this);
    // setup the gNB side of SRB1; the UE side will be set up upon RRC connection establishment
    {
        uint8_t lcid = 1;

        Ptr<NrRlc> rlc = CreateObject<NrRlcAm>()->GetObject<NrRlc>();
        rlc->SetNrMacSapProvider(m_rrc->m_macSapProvider);
        rlc->SetRnti(m_rnti);
        rlc->SetLcId(lcid);

        Ptr<NrPdcp> pdcp = CreateObject<NrPdcp>();
        pdcp->SetRnti(m_rnti);
        pdcp->SetLcId(lcid);
        pdcp->SetNrPdcpSapUser(m_drbPdcpSapUser);
        pdcp->SetNrRlcSapProvider(rlc->GetNrRlcSapProvider());
        rlc->SetNrRlcSapUser(pdcp->GetNrRlcSapUser());

        m_srb1 = CreateObject<NrSignalingRadioBearerInfo>();
        m_srb1->m_rlc = rlc;
        m_srb1->m_pdcp = pdcp;
        m_srb1->m_srbIdentity = 1;
        m_srb1->m_logicalChannelConfig.priority = 1;
        m_srb1->m_logicalChannelConfig.prioritizedBitRateKbps = 100;
        m_srb1->m_logicalChannelConfig.bucketSizeDurationMs = 100;
        m_srb1->m_logicalChannelConfig.logicalChannelGroup = 0;
        m_srb1->m_logicalChannelConfig.fiveQi = NrQosFlow::GBR_CONV_VOICE;

        NrGnbCmacSapProvider::LcInfo lcinfo;
        lcinfo.rnti = m_rnti;
        lcinfo.lcId = lcid;
        lcinfo.lcGroup = 0; // all SRBs always mapped to LCG 0
        lcinfo.fiveQi =
            NrQosFlow::GBR_CONV_VOICE; // not sure why the FF API requires a CQI even for SRBs...
        lcinfo.resourceType = 1;       // GBR resource type
        lcinfo.mbrUl = 1e6;
        lcinfo.mbrDl = 1e6;
        lcinfo.gbrUl = 1e4;
        lcinfo.gbrDl = 1e4;
        // MacSapUserForRlc in the ComponentCarrierManager MacSapUser
        NrMacSapUser* MacSapUserForRlc =
            m_rrc->m_ccmRrcSapProvider->ConfigureSignalBearer(lcinfo, rlc->GetNrMacSapUser());
        // Signal Channel are only on Primary Carrier
        for (uint16_t i = 0; i < m_rrc->m_numberOfComponentCarriers; i++)
        {
            m_rrc->m_cmacSapProvider.at(i)->AddLc(lcinfo, MacSapUserForRlc);
        }
        m_rrc->m_ccmRrcSapProvider->AddLc(lcinfo, MacSapUserForRlc);
    }

    NrGnbRrcSapUser::SetupUeParameters ueParams;
    ueParams.srb0SapProvider = m_srb0->m_rlc->GetNrRlcSapProvider();
    ueParams.srb1SapProvider = m_srb1->m_pdcp->GetNrPdcpSapProvider();
    m_rrc->m_rrcSapUser->SetupUe(m_rnti, ueParams);
}

void
NrUeManager::ConfigureMacPhy()
{
    NS_LOG_FUNCTION(this);
    // configure MAC (and scheduler)
    NrGnbCmacSapProvider::UeConfig req;
    req.m_rnti = m_rnti;
    req.m_transmissionMode = m_physicalConfigDedicated.antennaInfo.transmissionMode;

    // configure PHY
    for (uint16_t i = 0; i < m_rrc->m_numberOfComponentCarriers; i++)
    {
        m_rrc->m_cmacSapProvider.at(i)->UeUpdateConfigurationReq(req);
        m_rrc->m_cphySapProvider.at(i)->SetTransmissionMode(
            m_rnti,
            m_physicalConfigDedicated.antennaInfo.transmissionMode);
        m_rrc->m_cphySapProvider.at(i)->SetSrsConfigurationIndex(
            m_rnti,
            m_physicalConfigDedicated.soundingRsUlConfigDedicated.srsConfigIndex);
    }
    // schedule this NrUeManager instance to be deleted if the UE does not give any sign of life
    // within a reasonable time
    Time maxConnectionDelay;
    switch (m_state)
    {
    case INITIAL_RANDOM_ACCESS:
        m_connectionRequestTimeout = Simulator::Schedule(m_rrc->m_connectionRequestTimeoutDuration,
                                                         &NrGnbRrc::ConnectionRequestTimeout,
                                                         m_rrc,
                                                         m_rnti);
        break;

    case HANDOVER_JOINING:
        break;

    default:
        NS_FATAL_ERROR("unexpected state " << ToString(m_state));
        break;
    }
    m_caSupportConfigured = false;
}

NrUeManager::~NrUeManager()
{
}

void
NrUeManager::DoDispose()
{
    delete m_drbPdcpSapUser;
    // delete eventual X2-U TEIDs
    for (auto it = m_drbMap.begin(); it != m_drbMap.end(); ++it)
    {
        m_rrc->m_x2uTeidInfoMap.erase(it->second->m_gtpTeid);
    }
}

TypeId
NrUeManager::GetTypeId()
{
    static TypeId tid =
        TypeId("ns3::NrUeManager")
            .SetParent<Object>()
            .AddConstructor<NrUeManager>()
            .AddAttribute("DataRadioBearerMap",
                          "List of UE DataRadioBearerInfo by DRBID.",
                          ObjectMapValue(),
                          MakeObjectMapAccessor(&NrUeManager::m_drbMap),
                          MakeObjectMapChecker<NrDataRadioBearerInfo>())
            .AddAttribute("Srb0",
                          "SignalingRadioBearerInfo for SRB0",
                          PointerValue(),
                          MakePointerAccessor(&NrUeManager::m_srb0),
                          MakePointerChecker<NrSignalingRadioBearerInfo>())
            .AddAttribute("Srb1",
                          "SignalingRadioBearerInfo for SRB1",
                          PointerValue(),
                          MakePointerAccessor(&NrUeManager::m_srb1),
                          MakePointerChecker<NrSignalingRadioBearerInfo>())
            .AddAttribute("C-RNTI",
                          "Cell Radio Network Temporary Identifier",
                          TypeId::ATTR_GET, // read-only attribute
                          UintegerValue(0), // unused, read-only attribute
                          MakeUintegerAccessor(&NrUeManager::m_rnti),
                          MakeUintegerChecker<uint16_t>())
            .AddTraceSource("StateTransition",
                            "fired upon every UE state transition seen by the "
                            "NrUeManager at the gNB RRC",
                            MakeTraceSourceAccessor(&NrUeManager::m_stateTransitionTrace),
                            "ns3::NrUeManager::StateTracedCallback")
            .AddTraceSource("DrbCreated",
                            "trace fired after DRB is created",
                            MakeTraceSourceAccessor(&NrUeManager::m_drbCreatedTrace),
                            "ns3::NrUeManager::ImsiCidRntiLcIdTracedCallback");
    return tid;
}

void
NrUeManager::SetSource(uint16_t sourceCellId, uint16_t sourceX2apId)
{
    m_sourceX2apId = sourceX2apId;
    m_sourceCellId = sourceCellId;
}

uint16_t
NrUeManager::GetSourceCellId() const
{
    return m_sourceCellId;
}

void
NrUeManager::SetImsi(uint64_t imsi)
{
    m_imsi = imsi;
}

void
NrUeManager::InitialContextSetupRequest()
{
    NS_LOG_FUNCTION(this << m_rnti);

    if (m_state == ATTACH_REQUEST)
    {
        SwitchToState(CONNECTED_NORMALLY);
    }
    else
    {
        NS_FATAL_ERROR("method unexpected in state " << ToString(m_state));
    }
}

void
NrUeManager::SetupDataRadioBearer(NrQosFlow flow,
                                  uint8_t qfi,
                                  uint32_t gtpTeid,
                                  Ipv4Address transportLayerAddress)
{
    NS_LOG_FUNCTION(this << (uint32_t)m_rnti);

    Ptr<NrDataRadioBearerInfo> drbInfo = CreateObject<NrDataRadioBearerInfo>();
    uint8_t drbid = AddDataRadioBearerInfo(drbInfo);
    uint8_t lcid = nr::Drbid2Lcid(drbid);
    uint8_t qosFlowId = nr::Drbid2Qfi(drbid);
    NS_ASSERT_MSG(qfi == 0 || qosFlowId == qfi,
                  "QFI mismatch (" << (uint32_t)qosFlowId << " != " << (uint32_t)qfi
                                   << ", the assumption that ID are allocated in the same "
                                      "way by MME and RRC is not valid any more");
    drbInfo->m_qosFlow = flow;
    drbInfo->m_qosFlowIdentity = qfi;
    drbInfo->m_drbIdentity = drbid;
    drbInfo->m_logicalChannelIdentity = lcid;
    drbInfo->m_gtpTeid = gtpTeid;
    drbInfo->m_transportLayerAddress = transportLayerAddress;

    if (m_state == HANDOVER_JOINING)
    {
        // setup TEIDs for receiving data eventually forwarded over X2-U
        NrGnbRrc::X2uTeidInfo x2uTeidInfo;
        x2uTeidInfo.rnti = m_rnti;
        x2uTeidInfo.drbid = drbid;
        auto ret = m_rrc->m_x2uTeidInfoMap.insert(
            std::pair<uint32_t, NrGnbRrc::X2uTeidInfo>(gtpTeid, x2uTeidInfo));
        NS_ASSERT_MSG(ret.second == true, "overwriting a pre-existing entry in m_x2uTeidInfoMap");
    }

    TypeId rlcTypeId = m_rrc->GetRlcType(flow);

    ObjectFactory rlcObjectFactory;
    rlcObjectFactory.SetTypeId(rlcTypeId);
    Ptr<NrRlc> rlc = rlcObjectFactory.Create()->GetObject<NrRlc>();
    rlc->SetNrMacSapProvider(m_rrc->m_macSapProvider);
    rlc->SetRnti(m_rnti);
    rlc->SetPacketDelayBudgetMs(flow.GetPacketDelayBudgetMs());
    if (rlcTypeId == NrRlcSm::GetTypeId())
    {
        // Starts the chain of calls:
        // DoReportBufferStatus->DoNotifyTxOpp->DoReportBufferStatus...
        Simulator::ScheduleNow(&NrRlcSm::Initialize, rlc);
    }

    drbInfo->m_rlc = rlc;

    rlc->SetLcId(lcid);

    // we need PDCP only for real RLC, i.e., RLC/UM or RLC/AM
    // if we are using RLC/SM we don't care of anything above RLC
    if (rlcTypeId != NrRlcSm::GetTypeId())
    {
        Ptr<NrPdcp> pdcp = CreateObject<NrPdcp>();
        pdcp->SetRnti(m_rnti);
        pdcp->SetLcId(lcid);
        pdcp->SetNrPdcpSapUser(m_drbPdcpSapUser);
        pdcp->SetNrRlcSapProvider(rlc->GetNrRlcSapProvider());
        rlc->SetNrRlcSapUser(pdcp->GetNrRlcSapUser());
        drbInfo->m_pdcp = pdcp;
    }

    m_drbCreatedTrace(m_imsi, m_rrc->ComponentCarrierToCellId(m_componentCarrierId), m_rnti, lcid);

    std::vector<NrCcmRrcSapProvider::LcsConfig> lcOnCcMapping =
        m_rrc->m_ccmRrcSapProvider->SetupDataRadioBearer(flow,
                                                         qfi,
                                                         m_rnti,
                                                         lcid,
                                                         m_rrc->GetLogicalChannelGroup(flow),
                                                         rlc->GetNrMacSapUser());
    // NrGnbCmacSapProvider::LcInfo lcinfo;
    // lcinfo.rnti = m_rnti;
    // lcinfo.lcId = lcid;
    // lcinfo.lcGroup = m_rrc->GetLogicalChannelGroup (flow);
    // lcinfo.fiveQi = bearer.fiveQi;
    // lcinfo.resourceType = flow.GetResourceType();
    // lcinfo.mbrUl = flow.gbrQosInfo.mbrUl;
    // lcinfo.mbrDl = flow.gbrQosInfo.mbrDl;
    // lcinfo.gbrUl = flow.gbrQosInfo.gbrUl;
    // lcinfo.gbrDl = flow.gbrQosInfo.gbrDl;
    // use a for cycle to send the AddLc to the appropriate Mac Sap
    // if the sap is not initialized the appropriated method has to be called
    auto itLcOnCcMapping = lcOnCcMapping.begin();
    NS_ASSERT_MSG(itLcOnCcMapping != lcOnCcMapping.end(), "Problem");
    for (itLcOnCcMapping = lcOnCcMapping.begin(); itLcOnCcMapping != lcOnCcMapping.end();
         ++itLcOnCcMapping)
    {
        NS_LOG_DEBUG(this << " RNTI " << itLcOnCcMapping->lc.rnti << "Lcid "
                          << (uint16_t)itLcOnCcMapping->lc.lcId << " lcGroup "
                          << (uint16_t)itLcOnCcMapping->lc.lcGroup << " ComponentCarrierId "
                          << itLcOnCcMapping->componentCarrierId);
        uint8_t index = itLcOnCcMapping->componentCarrierId;
        NrGnbCmacSapProvider::LcInfo lcinfo = itLcOnCcMapping->lc;
        NrMacSapUser* msu = itLcOnCcMapping->msu;
        m_rrc->m_cmacSapProvider.at(index)->AddLc(lcinfo, msu);
        m_rrc->m_ccmRrcSapProvider->AddLc(lcinfo, msu);
    }

    if (rlcTypeId == NrRlcAm::GetTypeId())
    {
        drbInfo->m_rlcConfig.choice = NrRrcSap::RlcConfig::AM;
    }
    else
    {
        drbInfo->m_rlcConfig.choice = NrRrcSap::RlcConfig::UM_BI_DIRECTIONAL;
    }

    drbInfo->m_logicalChannelIdentity = lcid;
    drbInfo->m_logicalChannelConfig.priority = m_rrc->GetLogicalChannelPriority(flow);
    drbInfo->m_logicalChannelConfig.fiveQi = m_rrc->GetLogicalChannelFiveQi(flow);
    drbInfo->m_logicalChannelConfig.logicalChannelGroup = m_rrc->GetLogicalChannelGroup(flow);
    if (flow.GetResourceType() > 0) // 1, 2 for GBR and DC-GBR
    {
        drbInfo->m_logicalChannelConfig.prioritizedBitRateKbps = flow.gbrQosInfo.gbrUl;
    }
    else
    {
        drbInfo->m_logicalChannelConfig.prioritizedBitRateKbps = 0;
    }
    drbInfo->m_logicalChannelConfig.bucketSizeDurationMs = 1000;

    ScheduleRrcConnectionReconfiguration();
}

void
NrUeManager::RecordDataRadioBearersToBeStarted()
{
    NS_LOG_FUNCTION(this << (uint32_t)m_rnti);
    for (auto it = m_drbMap.begin(); it != m_drbMap.end(); ++it)
    {
        m_drbsToBeStarted.push_back(it->first);
    }
}

void
NrUeManager::StartDataRadioBearers()
{
    NS_LOG_FUNCTION(this << (uint32_t)m_rnti);
    for (auto drbIdIt = m_drbsToBeStarted.begin(); drbIdIt != m_drbsToBeStarted.end(); ++drbIdIt)
    {
        auto drbIt = m_drbMap.find(*drbIdIt);
        NS_ASSERT(drbIt != m_drbMap.end());
        drbIt->second->Initialize();
    }
    m_drbsToBeStarted.clear();
}

void
NrUeManager::ReleaseDataRadioBearer(uint8_t drbid)
{
    NS_LOG_FUNCTION(this << (uint32_t)m_rnti << (uint32_t)drbid);
    uint8_t lcid = nr::Drbid2Lcid(drbid);
    auto it = m_drbMap.find(drbid);
    NS_ASSERT_MSG(it != m_drbMap.end(),
                  "request to remove radio bearer with unknown drbid " << drbid);

    // first delete eventual X2-U TEIDs
    m_rrc->m_x2uTeidInfoMap.erase(it->second->m_gtpTeid);

    m_drbMap.erase(it);
    std::vector<uint8_t> ccToRelease =
        m_rrc->m_ccmRrcSapProvider->ReleaseDataRadioBearer(m_rnti, lcid);

    auto itCcToRelease = ccToRelease.begin();
    NS_ASSERT_MSG(itCcToRelease != ccToRelease.end(),
                  "request to remove radio bearer with unknown drbid (ComponentCarrierManager)");
    for (itCcToRelease = ccToRelease.begin(); itCcToRelease != ccToRelease.end(); ++itCcToRelease)
    {
        m_rrc->m_cmacSapProvider.at(*itCcToRelease)->ReleaseLc(m_rnti, lcid);
    }
    NrRrcSap::RadioResourceConfigDedicated rrcd;
    rrcd.havePhysicalConfigDedicated = false;
    rrcd.drbToReleaseList.push_back(drbid);
    // populating RadioResourceConfigDedicated information element as per 3GPP TS 36.331
    // version 9.2.0
    rrcd.havePhysicalConfigDedicated = true;
    rrcd.physicalConfigDedicated = m_physicalConfigDedicated;

    // populating RRCConnectionReconfiguration message as per 3GPP TS 36.331 version 9.2.0 Release 9
    NrRrcSap::RrcConnectionReconfiguration msg{};
    msg.haveMeasConfig = false;
    msg.haveMobilityControlInfo = false;
    msg.radioResourceConfigDedicated = rrcd;
    msg.haveRadioResourceConfigDedicated = true;
    // ToDo: Resend in any case this configuration
    // needs to be initialized
    msg.haveNonCriticalExtension = false;
    // RRC Connection Reconfiguration towards UE
    m_rrc->m_rrcSapUser->SendRrcConnectionReconfiguration(m_rnti, msg);
}

void
NrGnbRrc::DoSendReleaseQosFlow(uint64_t imsi, uint16_t rnti, uint8_t qfi)
{
    NS_LOG_FUNCTION(this << imsi << rnti << qfi);

    // check if the RNTI to be removed is not stale
    if (HasUeManager(rnti))
    {
        Ptr<NrUeManager> ueManager = GetUeManager(rnti);
        // Convert QFI to DRBID: bearerId is passed as QFI, but ReleaseDataRadioBearer expects DRBID
        // DRBID = QFI + 2
        uint8_t drbid = nr::Qfi2Drbid(qfi);
        // Bearer de-activation towards UE
        ueManager->ReleaseDataRadioBearer(drbid);
        // Bearer de-activation indication towards epc-gNB application
        m_s1SapProvider->DoSendReleaseIndication(imsi, rnti, qfi);
    }
}

void
NrUeManager::RecvIdealUeContextRemoveRequest(uint16_t rnti)
{
    NS_LOG_FUNCTION(this << m_rnti);

    // release the bearer info for the UE at SGW/PGW
    if (m_rrc->m_s1SapProvider != nullptr) // if EPC is enabled
    {
        for (const auto& it : m_drbMap)
        {
            NS_LOG_DEBUG("Sending release of bearer id : "
                         << (uint16_t)(it.first)
                         << "LCID : " << (uint16_t)(it.second->m_logicalChannelIdentity));
            // Bearer de-activation indication towards epc-gnb application
            m_rrc->m_s1SapProvider->DoSendReleaseIndication(GetImsi(), rnti, it.first);
        }
    }
}

void
NrUeManager::ScheduleRrcConnectionReconfiguration()
{
    NS_LOG_FUNCTION(this);
    switch (m_state)
    {
    case INITIAL_RANDOM_ACCESS:
    case CONNECTION_SETUP:
    case ATTACH_REQUEST:
    case CONNECTION_RECONFIGURATION:
    case CONNECTION_REESTABLISHMENT:
    case HANDOVER_PREPARATION:
    case HANDOVER_JOINING:
    case HANDOVER_LEAVING:
        // a previous reconfiguration still ongoing, we need to wait for it to be finished
        m_pendingRrcConnectionReconfiguration = true;
        break;

    case CONNECTED_NORMALLY: {
        m_pendingRrcConnectionReconfiguration = false;
        NrRrcSap::RrcConnectionReconfiguration msg = BuildRrcConnectionReconfiguration();
        m_rrc->m_rrcSapUser->SendRrcConnectionReconfiguration(m_rnti, msg);
        RecordDataRadioBearersToBeStarted();
        SwitchToState(CONNECTION_RECONFIGURATION);
    }
    break;

    default:
        NS_FATAL_ERROR("method unexpected in state " << ToString(m_state));
        break;
    }
}

void
NrUeManager::PrepareHandover(uint16_t cellId)
{
    NS_LOG_FUNCTION(this << cellId);
    switch (m_state)
    {
    case CONNECTED_NORMALLY: {
        m_targetCellId = cellId;

        auto sourceComponentCarrier = DynamicCast<BandwidthPartGnb>(
            m_rrc->m_componentCarrierPhyConf.at(m_componentCarrierId));
        NS_ASSERT(m_targetCellId != sourceComponentCarrier->GetCellId());

        // Inter-gNB aka X2 handover
        NS_LOG_DEBUG("Inter-gNB handover (i.e., X2) for cellId " << cellId);
        NrEpcX2SapProvider::HandoverRequestParams params;
        params.oldGnbUeX2apId = m_rnti;
        params.cause = NrEpcX2SapProvider::HandoverDesirableForRadioReason;
        params.sourceCellId = m_rrc->ComponentCarrierToCellId(m_componentCarrierId);
        params.targetCellId = cellId;
        params.mmeUeS1apId = m_imsi;
        params.ueAggregateMaxBitRateDownlink = 200 * 1000;
        params.ueAggregateMaxBitRateUplink = 100 * 1000;
        params.bearers = GetErabList();

        NrRrcSap::HandoverPreparationInfo hpi;
        hpi.asConfig.sourceUeIdentity = m_rnti;
        hpi.asConfig.sourceDlCarrierFreq = sourceComponentCarrier->GetArfcn();
        hpi.asConfig.sourceMeasConfig = m_rrc->m_ueMeasConfig;
        hpi.asConfig.sourceRadioResourceConfig = GetRadioResourceConfigForHandoverPreparationInfo();
        hpi.asConfig.sourceMasterInformationBlock.numerology =
            sourceComponentCarrier->GetPhy()->GetNumerology();
        hpi.asConfig.sourceMasterInformationBlock.dlBandwidth =
            sourceComponentCarrier->GetDlBandwidth();
        hpi.asConfig.sourceMasterInformationBlock.systemFrameNumber = 0;
        hpi.asConfig.sourceSystemInformationBlockType1.cellAccessRelatedInfo.plmnIdentityInfo
            .plmnIdentity = m_rrc->m_sib1.at(m_componentCarrierId)
                                .cellAccessRelatedInfo.plmnIdentityInfo.plmnIdentity;
        hpi.asConfig.sourceSystemInformationBlockType1.cellAccessRelatedInfo.cellIdentity =
            m_rrc->ComponentCarrierToCellId(m_componentCarrierId);
        hpi.asConfig.sourceSystemInformationBlockType1.cellAccessRelatedInfo.csgIndication =
            m_rrc->m_sib1.at(m_componentCarrierId).cellAccessRelatedInfo.csgIndication;
        hpi.asConfig.sourceSystemInformationBlockType1.cellAccessRelatedInfo.csgIdentity =
            m_rrc->m_sib1.at(m_componentCarrierId).cellAccessRelatedInfo.csgIdentity;
        NrGnbCmacSapProvider::RachConfig rc =
            m_rrc->m_cmacSapProvider.at(m_componentCarrierId)->GetRachConfig();
        hpi.asConfig.sourceSystemInformationBlockType2.radioResourceConfigCommon.rachConfigCommon
            .preambleInfo.numberOfRaPreambles = rc.numberOfRaPreambles;
        hpi.asConfig.sourceSystemInformationBlockType2.radioResourceConfigCommon.rachConfigCommon
            .raSupervisionInfo.preambleTransMax = rc.preambleTransMax;
        hpi.asConfig.sourceSystemInformationBlockType2.radioResourceConfigCommon.rachConfigCommon
            .raSupervisionInfo.raResponseWindowSize = rc.raResponseWindowSize;
        hpi.asConfig.sourceSystemInformationBlockType2.radioResourceConfigCommon.rachConfigCommon
            .txFailParam.connEstFailCount = rc.connEstFailCount;
        hpi.asConfig.sourceSystemInformationBlockType2.freqInfo.ulCarrierFreq =
            sourceComponentCarrier->GetArfcn();
        hpi.asConfig.sourceSystemInformationBlockType2.freqInfo.ulBandwidth =
            sourceComponentCarrier->GetUlBandwidth();
        params.rrcContext = m_rrc->m_rrcSapUser->EncodeHandoverPreparationInformation(hpi);

        NS_LOG_LOGIC("oldGnbUeX2apId = " << params.oldGnbUeX2apId);
        NS_LOG_LOGIC("sourceCellId = " << params.sourceCellId);
        NS_LOG_LOGIC("targetCellId = " << params.targetCellId);
        NS_LOG_LOGIC("mmeUeS1apId = " << params.mmeUeS1apId);
        NS_LOG_LOGIC("rrcContext   = " << params.rrcContext);

        m_rrc->m_x2SapProvider->SendHandoverRequest(params);
        SwitchToState(HANDOVER_PREPARATION);
    }
    break;
    case CONNECTION_SETUP:
        // The UE has not yet sent RrcConnectionSetupComplete; it will
        // transition to CONNECTED_NORMALLY shortly. Store the request
        // and let RecvRrcConnectionSetupCompleted() dispatch it.
        if (m_pendingHandoverTargetCellId != 0)
        {
            NS_LOG_WARN("NrUeManager::PrepareHandover: RNTI="
                        << m_rnti << " already has a pending HO to cell="
                        << m_pendingHandoverTargetCellId << "; overwriting with cell=" << cellId);
        }
        NS_LOG_INFO("NrUeManager::PrepareHandover: RNTI="
                    << m_rnti << " is in CONNECTION_SETUP; deferring HO to cell=" << cellId
                    << " until CONNECTED_NORMALLY");
        m_pendingHandoverTargetCellId = cellId;
        return; // do NOT fall through; no X2 message yet

    case HANDOVER_PATH_SWITCH: // already handed-over UE
    case HANDOVER_LEAVING:     // concurrent HO in progress
    case HANDOVER_JOINING:
        NS_LOG_WARN("NrUeManager::PrepareHandover: RNTI="
                    << m_rnti << " ignoring HO request to cell=" << cellId
                    << " — already in handover state " << ToString(m_state));
        return; // silently drop, retrying here would corrupt state

    default:
        NS_FATAL_ERROR("method unexpected in state " << ToString(m_state));
        break;
    }
}

void
NrUeManager::RecvHandoverRequestAck(NrEpcX2SapUser::HandoverRequestAckParams params)
{
    NS_LOG_FUNCTION(this);

    NS_ASSERT_MSG(params.notAdmittedBearers.empty(),
                  "not admission of some bearers upon handover is not supported");
    NS_ASSERT_MSG(params.admittedBearers.size() == m_drbMap.size(),
                  "not enough bearers in admittedBearers");

    // note: the Handover command from the target gNB to the source gNB
    // is expected to be sent transparently to the UE; however, here we
    // decode the message and eventually re-encode it. This way we can
    // support both a real RRC protocol implementation and an ideal one
    // without actual RRC protocol encoding.

    Ptr<Packet> encodedHandoverCommand = params.rrcContext;
    NrRrcSap::RrcConnectionReconfiguration handoverCommand =
        m_rrc->m_rrcSapUser->DecodeHandoverCommand(encodedHandoverCommand);
    if (handoverCommand.haveNonCriticalExtension)
    {
        // Total number of component carriers =
        // handoverCommand.nonCriticalExtension.sCellToAddModList.size() + 1 (Primary carrier)
        if (handoverCommand.nonCriticalExtension.sCellToAddModList.size() + 1 !=
            m_rrc->m_numberOfComponentCarriers)
        {
            // Currently handover is only possible if source and target gNBs have equal number of
            // component carriers
            NS_FATAL_ERROR("The source and target gNBs have unequal number of component carriers. "
                           "Target gNB CCs = "
                           << handoverCommand.nonCriticalExtension.sCellToAddModList.size() + 1
                           << " Source gNB CCs = " << m_rrc->m_numberOfComponentCarriers);
        }
    }
    m_rrc->m_rrcSapUser->SendRrcConnectionReconfiguration(m_rnti, handoverCommand);
    SwitchToState(HANDOVER_LEAVING);
    NS_ASSERT(handoverCommand.haveMobilityControlInfo);
    m_rrc->m_handoverStartTrace(m_imsi,
                                m_rrc->ComponentCarrierToCellId(m_componentCarrierId),
                                m_rnti,
                                handoverCommand.mobilityControlInfo.targetPhysCellId);

    // Set the target cell ID and the RNTI so that handover cancel message can be sent if required
    m_targetX2apId = params.newGnbUeX2apId;
    m_targetCellId = params.targetCellId;

    NrEpcX2SapProvider::SnStatusTransferParams sst;
    sst.oldGnbUeX2apId = params.oldGnbUeX2apId;
    sst.newGnbUeX2apId = params.newGnbUeX2apId;
    sst.sourceCellId = params.sourceCellId;
    sst.targetCellId = params.targetCellId;
    for (auto drbIt = m_drbMap.begin(); drbIt != m_drbMap.end(); ++drbIt)
    {
        // SN status transfer is only for AM RLC
        if (drbIt->second->m_rlc->GetObject<NrRlcAm>())
        {
            NrPdcp::Status status = drbIt->second->m_pdcp->GetStatus();
            NrEpcX2Sap::ErabsSubjectToStatusTransferItem i;
            i.erabId = drbIt->second->m_qosFlowIdentity;
            i.dlPdcpSn = status.txSn;
            i.ulPdcpSn = status.rxSn;
            sst.erabsSubjectToStatusTransferList.push_back(i);
        }
    }
    m_rrc->m_x2SapProvider->SendSnStatusTransfer(sst);
    m_handoverLeavingTimeout = Simulator::Schedule(m_rrc->m_handoverLeavingTimeoutDuration,
                                                   &NrGnbRrc::HandoverLeavingTimeout,
                                                   m_rrc,
                                                   m_rnti);
}

NrRrcSap::RadioResourceConfigDedicated
NrUeManager::GetRadioResourceConfigForHandoverPreparationInfo()
{
    NS_LOG_FUNCTION(this);
    return BuildRadioResourceConfigDedicated();
}

NrRrcSap::RrcConnectionReconfiguration
NrUeManager::GetRrcConnectionReconfigurationForHandover(uint8_t componentCarrierId)
{
    NS_LOG_FUNCTION(this);

    NrRrcSap::RrcConnectionReconfiguration result = BuildRrcConnectionReconfiguration();

    auto targetComponentCarrier = m_rrc->m_componentCarrierPhyConf.at(componentCarrierId);
    // An FDD cell receives uplink on a dedicated UL-only carrier rather than on
    // the (DL) primary one, and the UE has no other way to learn it: it never
    // read this cell's system information. Point the UL parts of the handover
    // command at that carrier, if there is one.
    auto ulComponentCarrier = targetComponentCarrier;
    for (auto& it : m_rrc->m_componentCarrierPhyConf)
    {
        if (!it.second->GetPhy()->HasDlSlot())
        {
            ulComponentCarrier = it.second;
            break;
        }
    }
    result.haveMobilityControlInfo = true;
    result.mobilityControlInfo.targetPhysCellId = targetComponentCarrier->GetCellId();
    result.mobilityControlInfo.haveCarrierFreq = true;
    result.mobilityControlInfo.carrierFreq.dlCarrierFreq = targetComponentCarrier->GetArfcn();
    result.mobilityControlInfo.carrierFreq.ulCarrierFreq = ulComponentCarrier->GetArfcn();
    result.mobilityControlInfo.haveCarrierBandwidth = true;
    result.mobilityControlInfo.carrierBandwidth.dlBandwidth =
        targetComponentCarrier->GetDlBandwidth();
    result.mobilityControlInfo.carrierBandwidth.ulBandwidth = ulComponentCarrier->GetUlBandwidth();

    // Carry the target cell's broadcast PHY configuration in the handover
    // command so the UE re-tunes its target BWP to the *target* numerology,
    // TDD pattern and control-symbol layout. Without this the UE would fall
    // back to the (stale) serving-cell SIB1 it last decoded on the source
    // cell, which breaks inter-numerology handover: the target BWP would keep
    // the source numerology, so DL data reception (and hence the DL-CQI
    // feedback that lets the target gNB schedule downlink) never recovers.
    result.mobilityControlInfo.haveServingCellConfigCommon = true;
    result.mobilityControlInfo.servingCellConfigCommon.numerology =
        targetComponentCarrier->GetPhy()->GetNumerology();
    result.mobilityControlInfo.servingCellConfigCommon.ulNumerology =
        ulComponentCarrier->GetPhy()->GetNumerology();
    result.mobilityControlInfo.servingCellConfigCommon.ulCarrierFreq =
        ulComponentCarrier->GetArfcn();
    result.mobilityControlInfo.servingCellConfigCommon.symbolsPerSlot =
        targetComponentCarrier->GetPhy()->GetSymbolsPerSlot();
    result.mobilityControlInfo.servingCellConfigCommon.dlCtrlSymsNum =
        targetComponentCarrier->GetMac()->GetDlCtrlSyms();
    result.mobilityControlInfo.servingCellConfigCommon.ulCtrlSymsNum =
        targetComponentCarrier->GetMac()->GetUlCtrlSyms();
    result.mobilityControlInfo.servingCellConfigCommon.tddPattern =
        targetComponentCarrier->GetPhy()->GetPattern();
    result.mobilityControlInfo.servingCellConfigCommon.rbgSize =
        targetComponentCarrier->GetPhy()->GetNumRbPerRbg();

    if (m_caSupportConfigured && m_rrc->m_numberOfComponentCarriers > 1)
    {
        // Release sCells
        result.haveNonCriticalExtension = true;

        for (auto& it : m_rrc->m_componentCarrierPhyConf)
        {
            uint8_t ccId = it.first;

            if (ccId == m_componentCarrierId)
            {
                // Skip primary CC.
                continue;
            }
            else if (ccId < m_componentCarrierId)
            {
                // Shift all IDs below PCC forward so PCC can use CC ID 1.
                result.nonCriticalExtension.sCellToReleaseList.push_back(ccId + 1);
            }
        }
    }
    else
    {
        result.haveNonCriticalExtension = false;
    }

    return result;
}

void
NrUeManager::SendPacket(uint8_t qfi, Ptr<Packet> p)
{
    NS_LOG_FUNCTION(this << p << qfi);
    NrPdcpSapProvider::TransmitPdcpSduParameters params;
    params.pdcpSdu = p;
    params.rnti = m_rnti;
    params.lcid = nr::Qfi2Lcid(qfi);
    uint8_t drbid = nr::Qfi2Drbid(qfi);
    // Transmit PDCP sdu only if DRB ID found in drbMap
    auto it = m_drbMap.find(drbid);
    if (it != m_drbMap.end())
    {
        Ptr<NrDataRadioBearerInfo> bearerInfo = GetDataRadioBearerInfo(drbid);
        if (bearerInfo)
        {
            NS_LOG_INFO("Send packet to PDCP layer");
            NrPdcpSapProvider* pdcpSapProvider = bearerInfo->m_pdcp->GetNrPdcpSapProvider();
            pdcpSapProvider->TransmitPdcpSdu(params);
        }
    }
}

void
NrUeManager::SendData(uint8_t qfi, Ptr<Packet> p)
{
    NS_LOG_FUNCTION(this << p << qfi);
    switch (m_state)
    {
    case INITIAL_RANDOM_ACCESS:
    case CONNECTION_SETUP:
        NS_LOG_WARN("not connected, discarding packet");
        return;

    case CONNECTED_NORMALLY:
    case CONNECTION_RECONFIGURATION:
    case CONNECTION_REESTABLISHMENT:
    case HANDOVER_PREPARATION:
    case HANDOVER_PATH_SWITCH: {
        NS_LOG_INFO("queueing data on PDCP for transmission over the air");
        SendPacket(qfi, p);
    }
    break;

    case HANDOVER_JOINING: {
        // Buffer data until RRC Connection Reconfiguration Complete message is received
        NS_LOG_INFO("buffering data for QFI " << +qfi);
        m_packetBuffer.emplace_back(qfi, p);
    }
    break;

    case HANDOVER_LEAVING: {
        NS_LOG_INFO("forwarding data to target gNB over X2-U");
        uint8_t drbid = nr::Qfi2Drbid(qfi);
        NrEpcX2Sap::UeDataParams params;
        params.sourceCellId = m_rrc->ComponentCarrierToCellId(m_componentCarrierId);
        params.targetCellId = m_targetCellId;
        params.gtpTeid = GetDataRadioBearerInfo(drbid)->m_gtpTeid;
        params.ueData = p;
        m_rrc->m_x2SapProvider->SendUeData(params);
    }
    break;

    default:
        NS_FATAL_ERROR("method unexpected in state " << ToString(m_state));
        break;
    }
}

std::vector<NrEpcX2Sap::ErabToBeSetupItem>
NrUeManager::GetErabList()
{
    NS_LOG_FUNCTION(this);
    std::vector<NrEpcX2Sap::ErabToBeSetupItem> ret;
    for (auto it = m_drbMap.begin(); it != m_drbMap.end(); ++it)
    {
        NrEpcX2Sap::ErabToBeSetupItem etbsi;
        etbsi.erabId = it->second->m_qosFlowIdentity;
        etbsi.erabLevelQosParameters = it->second->m_qosFlow;
        etbsi.dlForwarding = false;
        etbsi.transportLayerAddress = it->second->m_transportLayerAddress;
        etbsi.gtpTeid = it->second->m_gtpTeid;
        ret.push_back(etbsi);
    }
    return ret;
}

void
NrUeManager::SendUeContextRelease()
{
    NS_LOG_FUNCTION(this);
    switch (m_state)
    {
    case HANDOVER_PATH_SWITCH:
        NS_LOG_INFO("Send UE CONTEXT RELEASE from target gNB to source gNB");
        NrEpcX2SapProvider::UeContextReleaseParams ueCtxReleaseParams;
        ueCtxReleaseParams.oldGnbUeX2apId = m_sourceX2apId;
        ueCtxReleaseParams.newGnbUeX2apId = m_rnti;
        ueCtxReleaseParams.sourceCellId = m_sourceCellId;
        ueCtxReleaseParams.targetCellId = m_targetCellId;
        if (!m_rrc->HasCellId(m_sourceCellId))
        {
            m_rrc->m_x2SapProvider->SendUeContextRelease(ueCtxReleaseParams);
        }
        else
        {
            NS_LOG_INFO("Not sending UE CONTEXT RELEASE because handover is internal");
            m_rrc->DoRecvUeContextRelease(ueCtxReleaseParams);
        }
        SwitchToState(CONNECTED_NORMALLY);
        m_rrc->m_handoverEndOkTrace(m_imsi,
                                    m_rrc->ComponentCarrierToCellId(m_componentCarrierId),
                                    m_rnti);
        break;

    default:
        NS_FATAL_ERROR("method unexpected in state " << ToString(m_state));
        break;
    }
}

void
NrUeManager::RecvHandoverPreparationFailure(uint16_t cellId)
{
    NS_LOG_FUNCTION(this << cellId);
    switch (m_state)
    {
    case HANDOVER_PREPARATION:
        NS_ASSERT(cellId == m_targetCellId);
        NS_LOG_INFO("target gNB sent HO preparation failure, aborting HO");
        SwitchToState(CONNECTED_NORMALLY);
        break;
    case HANDOVER_LEAVING: // case added to tackle HO leaving timer expiration
        NS_ASSERT(cellId == m_targetCellId);
        NS_LOG_INFO("target gNB sent HO preparation failure, aborting HO");
        m_handoverLeavingTimeout.Cancel();
        // SendRrcConnectionRelease(); // todo: not sure if we should remove or keep this
        break;

    default:
        NS_FATAL_ERROR("method unexpected in state " << ToString(m_state));
        break;
    }
}

void
NrUeManager::RecvSnStatusTransfer(NrEpcX2SapUser::SnStatusTransferParams params)
{
    NS_LOG_FUNCTION(this);
    for (auto erabIt = params.erabsSubjectToStatusTransferList.begin();
         erabIt != params.erabsSubjectToStatusTransferList.end();
         ++erabIt)
    {
        NrPdcp::Status status;
        status.txSn = erabIt->dlPdcpSn;
        status.rxSn = erabIt->ulPdcpSn;
        uint8_t drbId = nr::Qfi2Drbid(erabIt->erabId);
        auto drbIt = m_drbMap.find(drbId);
        NS_ASSERT_MSG(drbIt != m_drbMap.end(), "could not find DRBID " << (uint32_t)drbId);
        drbIt->second->m_pdcp->SetStatus(status);
    }
}

void
NrUeManager::RecvUeContextRelease(NrEpcX2SapUser::UeContextReleaseParams params)
{
    NS_LOG_FUNCTION(this);
    NS_ASSERT_MSG(m_state == HANDOVER_LEAVING, "method unexpected in state " << ToString(m_state));
    m_handoverLeavingTimeout.Cancel();

    // Source-side handover completion: the target released the UE context back to us.
    // Report the total handover time measured from the A3 trigger, if recorded.
    auto triggerIt = m_rrc->m_handoverTriggerTime.find(m_imsi);
    if (triggerIt != m_rrc->m_handoverTriggerTime.end())
    {
        m_rrc->m_handoverTotalTimeTrace(m_imsi,
                                        params.sourceCellId,
                                        params.targetCellId,
                                        Simulator::Now() - triggerIt->second);
        m_rrc->m_handoverTriggerTime.erase(triggerIt);
    }
}

void
NrUeManager::RecvHandoverCancel(NrEpcX2SapUser::HandoverCancelParams params)
{
    NS_LOG_FUNCTION(this);
    NS_ASSERT_MSG(m_state == HANDOVER_JOINING, "method unexpected in state " << ToString(m_state));
    m_handoverJoiningTimeout.Cancel();
}

void
NrUeManager::SendRrcConnectionRelease()
{
    // TODO implement in the 3gpp way, see Section 5.3.8 of 3GPP TS 36.331.
    NS_LOG_FUNCTION(this << (uint32_t)m_rnti);
    // De-activation towards UE, it will deactivate all bearers
    NrRrcSap::RrcConnectionRelease msg;
    msg.rrcTransactionIdentifier = this->GetNewRrcTransactionIdentifier();
    m_rrc->m_rrcSapUser->SendRrcConnectionRelease(m_rnti, msg);

    /**
     * Bearer de-activation indication towards epc-gnb application
     * and removal of UE context at the gNB
     *
     */
    m_rrc->DoRecvIdealUeContextRemoveRequest(m_rnti);
}

// methods forwarded from RRC SAP

void
NrUeManager::CompleteSetupUe(NrGnbRrcSapProvider::CompleteSetupUeParameters params)
{
    NS_LOG_FUNCTION(this);
    m_srb0->m_rlc->SetNrRlcSapUser(params.srb0SapUser);
    m_srb1->m_pdcp->SetNrPdcpSapUser(params.srb1SapUser);
}

void
NrUeManager::RecvRrcConnectionRequest(NrRrcSap::RrcConnectionRequest msg)
{
    NS_LOG_FUNCTION(this);
    switch (m_state)
    {
    case CONNECTED_NORMALLY: {
        // UE context exists but UE attempts new connection (e.g., after RLF or
        // handover failure). Reset context and treat as fresh connection.
        NS_LOG_INFO("Resetting UE context from CONNECTED_NORMALLY for new RRC Connection Request");
        m_state = NrUeManager::INITIAL_RANDOM_ACCESS;
        // Fall through to handle as fresh connection
    }
    case HANDOVER_LEAVING: {
        // Handover is in progress but UE attempts to reconnect to the source gNB.
        // This can happen if the handover to the target gNB fails. Clean up the
        // stale context and treat as a fresh connection.
        NS_LOG_INFO("Cleaning up stale UE context in HANDOVER_LEAVING state for RNTI "
                    << m_rnti << " — treating as fresh connection");
        m_handoverLeavingTimeout.Cancel();
        m_state = NrUeManager::INITIAL_RANDOM_ACCESS;
        // Fall through to handle as fresh connection
    }
    case HANDOVER_JOINING:
        // The target gNB is awaiting the incoming handover to complete, but the UE
        // instead sends a fresh RRC Connection Request -- this happens when the UE
        // declared RLF instead of joining (e.g. the TR 36.839 too-late handover
        // model) and re-selected this cell during re-establishment. Re-attaching
        // here would re-run the full S1 InitialContextSetup for an already-attached
        // UE and drift the MME/RRC bearer (QFI) allocation. Instead ignore the
        // request and let the already-scheduled handover-joining timeout perform the
        // canonical failure cleanup (fire HO_FAIL_JOINING, notify the source over X2,
        // release the UE context); the UE falls back to IDLE and re-attaches cleanly.
        NS_LOG_INFO("Ignoring RRC Connection Request in HANDOVER_JOINING for RNTI "
                    << m_rnti << "; handover join will be failed by its timeout");
        break;

    case INITIAL_RANDOM_ACCESS: {
        m_connectionRequestTimeout.Cancel();

        if (m_rrc->m_admitRrcConnectionRequest)
        {
            m_imsi = msg.ueIdentity;

            // send RRC CONNECTION SETUP to UE
            NrRrcSap::RrcConnectionSetup msg2;
            msg2.rrcTransactionIdentifier = GetNewRrcTransactionIdentifier();
            msg2.radioResourceConfigDedicated = BuildRadioResourceConfigDedicated();
            // The setup message rides SRB0 (RLC-TM), which cannot segment and
            // whose grant would not fit the BWP configuration: it is sent in
            // the RRC connection reconfiguration (SRB1, RLC-AM) instead
            msg2.radioResourceConfigDedicated.bwpConfigList.clear();
            msg2.radioResourceConfigDedicated.qosFlowToBwpList.clear();
            m_rrc->m_rrcSapUser->SendRrcConnectionSetup(m_rnti, msg2);

            RecordDataRadioBearersToBeStarted();
            m_connectionSetupTimeout = Simulator::Schedule(m_rrc->m_connectionSetupTimeoutDuration,
                                                           &NrGnbRrc::ConnectionSetupTimeout,
                                                           m_rrc,
                                                           m_rnti);
            SwitchToState(CONNECTION_SETUP);
        }
        else
        {
            NS_LOG_INFO("rejecting connection request for RNTI " << m_rnti);

            // send RRC CONNECTION REJECT to UE
            NrRrcSap::RrcConnectionReject rejectMsg;
            rejectMsg.waitTime = 3;
            m_rrc->m_rrcSapUser->SendRrcConnectionReject(m_rnti, rejectMsg);

            m_connectionRejectedTimeout =
                Simulator::Schedule(m_rrc->m_connectionRejectedTimeoutDuration,
                                    &NrGnbRrc::ConnectionRejectedTimeout,
                                    m_rrc,
                                    m_rnti);
            SwitchToState(CONNECTION_REJECTED);
        }
    }
    break;

    case CONNECTION_SETUP:
        // Duplicate RRC Connection Request: the gNB has already received msg3,
        // sent msg4 (RRC Connection Setup) and is awaiting Setup Complete. A
        // second copy of the same Connection Request can be delivered when msg3
        // HARQ (re)transmissions are combined/decoded more than once. It is a
        // lower-layer artefact, so ignore it rather than restarting setup.
        NS_LOG_INFO("Ignoring duplicate RRC Connection Request in CONNECTION_SETUP for RNTI "
                    << m_rnti);
        break;

    default:
        // Any other (already-active) state receiving a fresh RRC Connection Request
        // means an RLF'd UE re-selected this cell and re-attached before the gNB
        // released its context -- e.g. mid-reconfiguration (CONNECTION_RECONFIGURATION)
        // or during a handover path switch (HANDOVER_PATH_SWITCH), typically via the
        // TR 36.839 too-late-handover RLF. As in HANDOVER_JOINING, ignore it:
        // re-admitting would re-run S1 InitialContextSetup for an already-known UE and
        // drift the bearer (QFI) allocation. The state's own timeout / RLF cleanup
        // releases this context and the UE re-attaches cleanly.
        NS_LOG_INFO("Ignoring RRC Connection Request in state " << ToString(m_state) << " for RNTI "
                                                                << m_rnti);
        break;
    }
}

void
NrUeManager::RecvRrcConnectionSetupCompleted(NrRrcSap::RrcConnectionSetupCompleted msg)
{
    NS_LOG_FUNCTION(this);
    switch (m_state)
    {
    case CONNECTION_SETUP:
        m_connectionSetupTimeout.Cancel();
        if (!m_caSupportConfigured && m_rrc->m_numberOfComponentCarriers > 1)
        {
            m_pendingRrcConnectionReconfiguration = true; // Force Reconfiguration
            m_pendingStartDataRadioBearers = true;
        }

        if (m_rrc->m_s1SapProvider != nullptr)
        {
            m_rrc->m_s1SapProvider->InitialUeMessage(m_imsi, m_rnti);
            SwitchToState(ATTACH_REQUEST);
        }
        else
        {
            SwitchToState(CONNECTED_NORMALLY);
            // Fire a deferred handover request if one arrived during CONNECTION_SETUP.
            // ScheduleNow avoids re-entrancy: PrepareHandover() sends X2 messages and
            // modifies m_state, which must not happen inside this callback's stack.
            if (m_pendingHandoverTargetCellId != 0)
            {
                uint16_t targetCell = m_pendingHandoverTargetCellId;
                m_pendingHandoverTargetCellId = 0; // clear before scheduling
                NS_LOG_INFO("NrUeManager: executing deferred HO to cell="
                            << targetCell << " for RNTI=" << m_rnti);
                Simulator::ScheduleNow(&NrUeManager::PrepareHandover, this, targetCell);
            }
        }
        m_rrc->m_connectionEstablishedTrace(m_imsi,
                                            m_rrc->ComponentCarrierToCellId(m_componentCarrierId),
                                            m_rnti);
        break;

    default:
        NS_FATAL_ERROR("method unexpected in state " << ToString(m_state));
        break;
    }
}

void
NrUeManager::RecvRrcConnectionReconfigurationCompleted(
    NrRrcSap::RrcConnectionReconfigurationCompleted msg)
{
    NS_LOG_FUNCTION(this);
    switch (m_state)
    {
    case CONNECTION_RECONFIGURATION:
        StartDataRadioBearers();
        if (m_needPhyMacConfiguration)
        {
            // configure MAC (and scheduler)
            NrGnbCmacSapProvider::UeConfig req;
            req.m_rnti = m_rnti;
            req.m_transmissionMode = m_physicalConfigDedicated.antennaInfo.transmissionMode;
            for (uint16_t i = 0; i < m_rrc->m_numberOfComponentCarriers; i++)
            {
                m_rrc->m_cmacSapProvider.at(i)->UeUpdateConfigurationReq(req);

                // configure PHY
                m_rrc->m_cphySapProvider.at(i)->SetTransmissionMode(req.m_rnti,
                                                                    req.m_transmissionMode);
                double paDouble = NrRrcSap::ConvertPdschConfigDedicated2Double(
                    m_physicalConfigDedicated.pdschConfigDedicated);
                m_rrc->m_cphySapProvider.at(i)->SetPa(m_rnti, paDouble);
            }

            m_needPhyMacConfiguration = false;
        }
        SwitchToState(CONNECTED_NORMALLY);
        m_rrc->m_connectionReconfigurationTrace(
            m_imsi,
            m_rrc->ComponentCarrierToCellId(m_componentCarrierId),
            m_rnti);
        break;

    // This case is added to NS-3 in order to handle bearer de-activation scenario for CONNECTED
    // state UE
    case CONNECTED_NORMALLY:
    case HANDOVER_LEAVING:
        NS_LOG_INFO("ignoring RecvRrcConnectionReconfigurationCompleted in state "
                    << ToString(m_state));
        break;

    case HANDOVER_JOINING: {
        m_handoverJoiningTimeout.Cancel();

        while (!m_packetBuffer.empty())
        {
            NS_LOG_LOGIC("dequeueing data from buffer");
            std::pair<uint8_t, Ptr<Packet>> qfiPacketPair = m_packetBuffer.front();
            uint8_t qfi = qfiPacketPair.first;
            Ptr<Packet> p = qfiPacketPair.second;

            NS_LOG_LOGIC("queueing data on PDCP for QFI " << +qfi);
            SendPacket(qfi, p);

            m_packetBuffer.pop_front();
        }

        NS_LOG_INFO("Send PATH SWITCH REQUEST to the MME");
        NrEpcGnbS1SapProvider::PathSwitchRequestParameters params;
        params.rnti = m_rnti;
        params.cellId = m_rrc->ComponentCarrierToCellId(m_componentCarrierId);
        params.mmeUeS1Id = m_imsi;
        SwitchToState(HANDOVER_PATH_SWITCH);
        for (auto it = m_drbMap.begin(); it != m_drbMap.end(); ++it)
        {
            NrEpcGnbS1SapProvider::FlowToBeSwitched b;
            b.qfi = it->second->m_qosFlowIdentity;
            b.teid = it->second->m_gtpTeid;
            params.flowsToBeSwitched.push_back(b);
        }
        m_rrc->m_s1SapProvider->PathSwitchRequest(params);
    }
    break;
    case INITIAL_RANDOM_ACCESS:
        // Stale RrcConnectionReconfigurationCompleted from a previous failed
        // handover attempt whose UE context was not yet fully cleaned up.
        // The RNTI was recycled for a fresh attach; safely ignore the message.
        NS_LOG_WARN("NrUeManager: ignoring stale "
                    "RecvRrcConnectionReconfigurationCompleted in state "
                    << ToString(m_state) << " (RNTI " << m_rnti << ")");
        break;
    default:
        NS_FATAL_ERROR("method unexpected in state " << ToString(m_state));
        break;
    }
}

void
NrUeManager::RecvRrcConnectionReestablishmentRequest(
    NrRrcSap::RrcConnectionReestablishmentRequest msg)
{
    NS_LOG_FUNCTION(this);
    switch (m_state)
    {
    case CONNECTED_NORMALLY:
        break;

    case HANDOVER_LEAVING:
        m_handoverLeavingTimeout.Cancel();
        break;

    default:
        NS_FATAL_ERROR("method unexpected in state " << ToString(m_state));
        break;
    }

    if (m_rrc->m_useRrcReestablishment)
    {
        NS_LOG_INFO("Accepting RRC connection reestablishment request for RNTI " << m_rnti);
        NrRrcSap::RrcConnectionReestablishment msg2;
        msg2.rrcTransactionIdentifier = GetNewRrcTransactionIdentifier();
        msg2.radioResourceConfigDedicated = BuildRadioResourceConfigDedicated();
        m_rrc->m_rrcSapUser->SendRrcConnectionReestablishment(m_rnti, msg2);
        SwitchToState(CONNECTION_REESTABLISHMENT);
    }
    else
    {
        NS_LOG_INFO("RRC reestablishment disabled. Rejecting reestablishment request for RNTI "
                    << m_rnti);
        m_rrc->DoRecvIdealUeContextRemoveRequest(m_rnti);
    }
}

void
NrUeManager::RecvRrcConnectionReestablishmentComplete(
    NrRrcSap::RrcConnectionReestablishmentComplete msg)
{
    NS_LOG_FUNCTION(this);
    SwitchToState(CONNECTED_NORMALLY);
}

void
NrUeManager::RecvMeasurementReport(NrRrcSap::MeasurementReport msg)
{
    uint8_t measId = msg.measResults.measId;
    auto cellId = m_rrc->ComponentCarrierToCellId(m_componentCarrierId);
    NS_LOG_FUNCTION(this << (uint16_t)measId);
    NS_LOG_LOGIC(
        "measId " << (uint16_t)measId << " haveMeasResultNeighCells "
                  << msg.measResults.haveMeasResultNeighCells << " measResultListEutra "
                  << msg.measResults.measResultListEutra.size() << " haveMeasResultServFreqList "
                  << msg.measResults.haveMeasResultServFreqList << " measResultServFreqList "
                  << msg.measResults.measResultServFreqList.size());
    NS_LOG_LOGIC("serving cellId "
                 << cellId << " RSRP " << (uint16_t)msg.measResults.measResultPCell.rsrpResult
                 << " RSRQ " << (uint16_t)msg.measResults.measResultPCell.rsrqResult);

    for (auto it = msg.measResults.measResultListEutra.begin();
         it != msg.measResults.measResultListEutra.end();
         ++it)
    {
        NS_LOG_LOGIC("neighbour cellId " << it->physCellId << " RSRP "
                                         << (it->haveRsrpResult ? (uint16_t)it->rsrpResult : 255)
                                         << " RSRQ "
                                         << (it->haveRsrqResult ? (uint16_t)it->rsrqResult : 255));
    }

    if ((m_rrc->m_handoverManagementSapProvider != nullptr) &&
        (m_rrc->m_handoverMeasIds.find(measId) != m_rrc->m_handoverMeasIds.end()))
    {
        // this measurement was requested by the handover algorithm
        m_rrc->m_handoverManagementSapProvider->ReportUeMeas(m_rnti, msg.measResults);
    }

    if ((m_rrc->m_ccmRrcSapProvider != nullptr) &&
        (m_rrc->m_componentCarrierMeasIds.find(measId) != m_rrc->m_componentCarrierMeasIds.end()))
    {
        // this measurement was requested by the handover algorithm
        m_rrc->m_ccmRrcSapProvider->ReportUeMeas(m_rnti, msg.measResults);
    }

    if ((m_rrc->m_anrSapProvider != nullptr) &&
        (m_rrc->m_anrMeasIds.find(measId) != m_rrc->m_anrMeasIds.end()))
    {
        // this measurement was requested by the ANR function
        m_rrc->m_anrSapProvider->ReportUeMeas(msg.measResults);
    }

    /// Report any measurements to ComponentCarrierManager, so it can react to any change or
    /// activate the SCC
    m_rrc->m_ccmRrcSapProvider->ReportUeMeas(m_rnti, msg.measResults);
    // fire a trace source
    m_rrc->m_recvMeasurementReportTrace(m_imsi,
                                        m_rrc->ComponentCarrierToCellId(m_componentCarrierId),
                                        m_rnti,
                                        msg);

} // end of NrUeManager::RecvMeasurementReport

// methods forwarded from CMAC SAP

void
NrUeManager::CmacUeConfigUpdateInd(NrGnbCmacSapUser::UeConfig cmacParams)
{
    NS_LOG_FUNCTION(this << m_rnti);
    // at this stage used only by the scheduler for updating txMode

    m_physicalConfigDedicated.antennaInfo.transmissionMode = cmacParams.m_transmissionMode;

    m_needPhyMacConfiguration = true;

    // reconfigure the UE RRC
    ScheduleRrcConnectionReconfiguration();
}

// methods forwarded from PDCP SAP

void
NrUeManager::DoReceivePdcpSdu(NrPdcpSapUser::ReceivePdcpSduParameters params)
{
    NS_LOG_FUNCTION(this);
    if (params.lcid > 2)
    {
        // data radio bearer
        NrQosFlowTag tag;
        tag.SetRnti(params.rnti);
        tag.SetQfi(nr::Lcid2Qfi(params.lcid));
        params.pdcpSdu->AddPacketTag(tag);
        NS_LOG_DEBUG("Adding packet tag for RNTI " << params.rnti << " LCID " << +params.lcid
                                                   << " QFI " << +nr::Lcid2Qfi(params.lcid));
        m_rrc->m_forwardUpCallback(params.pdcpSdu);
    }
}

uint16_t
NrUeManager::GetRnti() const
{
    return m_rnti;
}

uint64_t
NrUeManager::GetImsi() const
{
    return m_imsi;
}

uint8_t
NrUeManager::GetComponentCarrierId() const
{
    return m_componentCarrierId;
}

void
NrUeManager::SetPrimaryBwp(uint8_t bwpId)
{
    NS_LOG_FUNCTION(this << m_rnti << +bwpId);
    m_primaryBwpId = bwpId;
    // Re-point this UE's downlink scheduling to the new BWP so DL data follows
    // the UE's same-cell primary-BWP switch. The component carrier manager
    // (e.g. BwpManagerGnb) records the per-UE override; subsequent BSR-driven
    // DL scheduling for this UE is then placed on the new BWP.
    if (m_rrc->m_ccmRrcSapProvider != nullptr)
    {
        m_rrc->m_ccmRrcSapProvider->SetUePrimaryBwp(m_rnti, bwpId);
    }
}

uint8_t
NrUeManager::GetPrimaryBwp() const
{
    return m_primaryBwpId;
}

uint16_t
NrUeManager::GetSrsConfigurationIndex() const
{
    return m_physicalConfigDedicated.soundingRsUlConfigDedicated.srsConfigIndex;
}

Ptr<NrSignalingRadioBearerInfo>
NrUeManager::GetSrb0() const
{
    return m_srb0;
}

void
NrUeManager::SetSrsConfigurationIndex(uint16_t srsConfIndex)
{
    NS_LOG_FUNCTION(this);
    m_physicalConfigDedicated.soundingRsUlConfigDedicated.srsConfigIndex = srsConfIndex;
    for (uint16_t i = 0; i < m_rrc->m_numberOfComponentCarriers; i++)
    {
        m_rrc->m_cphySapProvider.at(i)->SetSrsConfigurationIndex(m_rnti, srsConfIndex);
    }
    switch (m_state)
    {
    case INITIAL_RANDOM_ACCESS:
        // do nothing, srs conf index will be correctly enforced upon
        // RRC connection establishment
        break;

    default:
        ScheduleRrcConnectionReconfiguration();
        break;
    }
}

NrUeManager::State
NrUeManager::GetState() const
{
    return m_state;
}

Time
NrUeManager::GetConnectedNormallyAt() const
{
    return m_connectedNormallyAt;
}

ns3::TracedCallback<uint64_t, uint16_t, uint16_t, NrUeManager::State, NrUeManager::State>
NrUeManager::GetStateTransitionTrace() const
{
    return m_stateTransitionTrace;
}

void
NrUeManager::SetPdschConfigDedicated(NrRrcSap::PdschConfigDedicated pdschConfigDedicated)
{
    NS_LOG_FUNCTION(this);
    m_physicalConfigDedicated.pdschConfigDedicated = pdschConfigDedicated;

    m_needPhyMacConfiguration = true;

    // reconfigure the UE RRC
    ScheduleRrcConnectionReconfiguration();
}

void
NrUeManager::CancelPendingEvents()
{
    NS_LOG_FUNCTION(this);
    m_connectionRequestTimeout.Cancel();
    m_connectionRejectedTimeout.Cancel();
    m_connectionSetupTimeout.Cancel();
    m_handoverJoiningTimeout.Cancel();
    m_handoverLeavingTimeout.Cancel();
}

NrEpcX2Sap::HandoverPreparationFailureParams
NrUeManager::BuildHoPrepFailMsg()
{
    NS_LOG_FUNCTION(this);
    NrEpcX2Sap::HandoverPreparationFailureParams res;
    res.oldGnbUeX2apId = m_sourceX2apId;
    res.sourceCellId = m_sourceCellId;
    res.targetCellId = m_rrc->ComponentCarrierToCellId(m_componentCarrierId);
    res.cause = 0;
    res.criticalityDiagnostics = 0;

    return res;
}

NrEpcX2Sap::HandoverCancelParams
NrUeManager::BuildHoCancelMsg()
{
    NS_LOG_FUNCTION(this);
    NrEpcX2Sap::HandoverCancelParams res;
    res.oldGnbUeX2apId = m_rnti; // source cell rnti
    res.newGnbUeX2apId = m_targetX2apId;
    res.sourceCellId = m_rrc->ComponentCarrierToCellId(m_componentCarrierId);
    res.targetCellId = m_targetCellId;
    res.cause = 0;

    return res;
}

uint8_t
NrUeManager::AddDataRadioBearerInfo(Ptr<NrDataRadioBearerInfo> drbInfo)
{
    NS_LOG_FUNCTION(this);
    const uint8_t MAX_DRB_ID = 32;
    for (int drbid = (m_lastAllocatedDrbid + 1) % MAX_DRB_ID; drbid != m_lastAllocatedDrbid;
         drbid = (drbid + 1) % MAX_DRB_ID)
    {
        // Skip DRBID 0 (not allowed), 1-2 (reserved), 4 (reserved for sidelink)
        if (drbid != 0 && drbid != 1 && drbid != 2 && drbid != 4)
        {
            if (m_drbMap.find(drbid) == m_drbMap.end())
            {
                m_drbMap.insert(std::pair<uint8_t, Ptr<NrDataRadioBearerInfo>>(drbid, drbInfo));
                drbInfo->m_drbIdentity = drbid;
                m_lastAllocatedDrbid = drbid;
                NS_LOG_DEBUG("Allocated DRBID " << (uint32_t)drbid << " (LCID " << (uint32_t)drbid
                                                << ") for RNTI " << m_rnti);
                return drbid;
            }
        }
    }
    NS_FATAL_ERROR("no more data radio bearer ids available");
    return 0;
}

Ptr<NrDataRadioBearerInfo>
NrUeManager::GetDataRadioBearerInfo(uint8_t drbid)
{
    NS_LOG_FUNCTION(this << (uint32_t)drbid);
    NS_ASSERT(0 != drbid);
    auto it = m_drbMap.find(drbid);
    NS_ABORT_IF(it == m_drbMap.end());
    return it->second;
}

void
NrUeManager::RemoveDataRadioBearerInfo(uint8_t drbid)
{
    NS_LOG_FUNCTION(this << (uint32_t)drbid);
    auto it = m_drbMap.find(drbid);
    NS_ASSERT_MSG(it != m_drbMap.end(),
                  "request to remove radio bearer with unknown drbid " << drbid);
    m_drbMap.erase(it);
}

NrRrcSap::RrcConnectionReconfiguration
NrUeManager::BuildRrcConnectionReconfiguration()
{
    NS_LOG_FUNCTION(this);
    NrRrcSap::RrcConnectionReconfiguration msg{};
    msg.rrcTransactionIdentifier = GetNewRrcTransactionIdentifier();
    msg.haveRadioResourceConfigDedicated = true;
    msg.radioResourceConfigDedicated = BuildRadioResourceConfigDedicated();
    msg.haveMobilityControlInfo = false;
    msg.haveMeasConfig = true;
    msg.measConfig = m_rrc->m_ueMeasConfig;
    if (!m_caSupportConfigured && m_rrc->m_numberOfComponentCarriers > 1)
    {
        m_caSupportConfigured = true;
        NS_LOG_FUNCTION(this << "CA not configured. Configure now!");
        msg.haveNonCriticalExtension = true;
        msg.nonCriticalExtension = BuildNonCriticalExtensionConfigurationCa();
        NS_LOG_FUNCTION(this << " haveNonCriticalExtension " << msg.haveNonCriticalExtension);
    }
    else
    {
        msg.haveNonCriticalExtension = false;
    }

    return msg;
}

/**
 * @brief Build the ServingCellConfigCommon describing a carrier
 * @param cc the carrier
 * @param fddUlCarrier the cell's dedicated UL-only carrier, if any
 * @return the ServingCellConfigCommon of the carrier
 *
 * A DL-only carrier (FDD) points its UL fields at the cell's dedicated UL-only
 * carrier; any UL-capable carrier points at itself.
 */
static NrRrcSap::ServingCellConfigCommon
BuildServingCellConfigCommon(const Ptr<BandwidthPartGnb>& cc,
                             const Ptr<BandwidthPartGnb>& fddUlCarrier)
{
    NrRrcSap::ServingCellConfigCommon scc;
    scc.numerology = cc->GetPhy()->GetNumerology();
    if (!cc->GetPhy()->HasUlSlot() && fddUlCarrier)
    {
        scc.ulNumerology = fddUlCarrier->GetPhy()->GetNumerology();
        scc.ulCarrierFreq = fddUlCarrier->GetArfcn();
    }
    else
    {
        scc.ulNumerology = cc->GetPhy()->GetNumerology();
        scc.ulCarrierFreq = cc->GetArfcn();
    }
    scc.symbolsPerSlot = cc->GetPhy()->GetSymbolsPerSlot();
    scc.dlCtrlSymsNum = cc->GetMac()->GetDlCtrlSyms();
    scc.ulCtrlSymsNum = cc->GetMac()->GetUlCtrlSyms();
    scc.tddPattern = cc->GetPhy()->GetPattern();
    scc.rbgSize = cc->GetPhy()->GetNumRbPerRbg();
    return scc;
}

NrRrcSap::RadioResourceConfigDedicated
NrUeManager::BuildRadioResourceConfigDedicated()
{
    NS_LOG_FUNCTION(this);
    NrRrcSap::RadioResourceConfigDedicated rrcd{};

    if (m_srb1)
    {
        NrRrcSap::SrbToAddMod stam{};
        stam.srbIdentity = m_srb1->m_srbIdentity;
        stam.logicalChannelConfig = m_srb1->m_logicalChannelConfig;
        rrcd.srbToAddModList.push_back(stam);
    }

    for (auto it = m_drbMap.begin(); it != m_drbMap.end(); ++it)
    {
        NrRrcSap::DrbToAddMod dtam{};
        dtam.qosFlowIdentity = it->second->m_qosFlowIdentity;
        dtam.drbIdentity = it->second->m_drbIdentity;
        dtam.rlcConfig = it->second->m_rlcConfig;
        dtam.logicalChannelIdentity = it->second->m_logicalChannelIdentity;
        dtam.logicalChannelConfig = it->second->m_logicalChannelConfig;
        rrcd.drbToAddModList.push_back(dtam);
    }

    rrcd.havePhysicalConfigDedicated = true;
    rrcd.physicalConfigDedicated = m_physicalConfigDedicated;

    // Describe every BWP/carrier of the cell, so the UE configures its extra
    // BWPs and derives the UL pairing of DL-only (FDD) carriers from dedicated
    // signaling instead of manual UE-side configuration
    Ptr<BandwidthPartGnb> fddUlCarrier;
    for (const auto& it : m_rrc->m_componentCarrierPhyConf)
    {
        if (!it.second->GetPhy()->HasDlSlot())
        {
            fddUlCarrier = it.second;
            break;
        }
    }
    for (const auto& it : m_rrc->m_componentCarrierPhyConf)
    {
        NrRrcSap::BwpConfig bwpConfig;
        bwpConfig.arfcn = it.second->GetArfcn();
        bwpConfig.config = BuildServingCellConfigCommon(it.second, fddUlCarrier);
        // A DL-only carrier paired explicitly (e.g. a secondary FDD pair in a
        // mixed TDD/FDD carrier aggregation setup) points at its own UL
        // carrier rather than the cell's default one
        auto pairIt = m_rrc->m_ulCarrierPairing.find(bwpConfig.arfcn);
        if (!it.second->GetPhy()->HasUlSlot() && pairIt != m_rrc->m_ulCarrierPairing.end())
        {
            bwpConfig.config.ulCarrierFreq = pairIt->second;
            for (const auto& cc : m_rrc->m_componentCarrierPhyConf)
            {
                if (cc.second->GetArfcn() == pairIt->second)
                {
                    bwpConfig.config.ulNumerology = cc.second->GetPhy()->GetNumerology();
                    break;
                }
            }
        }
        rrcd.bwpConfigList.push_back(bwpConfig);
    }
    // Mirror the gNB's QoS flow to BWP mapping, so the UE routes its uplink
    // flows the way the network schedules them
    for (const auto& [fiveQi, arfcn] : m_rrc->m_qosFlowToBwpArfcn)
    {
        rrcd.qosFlowToBwpList.push_back({fiveQi, arfcn});
    }
    return rrcd;
}

uint8_t
NrUeManager::GetNewRrcTransactionIdentifier()
{
    NS_LOG_FUNCTION(this);
    ++m_lastRrcTransactionIdentifier;
    m_lastRrcTransactionIdentifier %= 4;
    return m_lastRrcTransactionIdentifier;
}

void
NrUeManager::SwitchToState(State newState)
{
    NS_LOG_FUNCTION(this << ToString(newState));
    State oldState = m_state;
    m_state = newState;
    NS_LOG_INFO(this << " IMSI " << m_imsi << " RNTI " << m_rnti << " NrUeManager "
                     << ToString(oldState) << " --> " << ToString(newState));
    m_stateTransitionTrace(m_imsi,
                           m_rrc->ComponentCarrierToCellId(m_componentCarrierId),
                           m_rnti,
                           oldState,
                           newState);

    switch (newState)
    {
    case INITIAL_RANDOM_ACCESS:
    case HANDOVER_JOINING:
        NS_FATAL_ERROR("cannot switch to an initial state");
        break;

    case CONNECTION_SETUP:
    case ATTACH_REQUEST:
        break;

    case CONNECTED_NORMALLY: {
        // Record when the UE became actively served by this cell (initial connection
        // or handover completion). Used by the minimum-time-of-stay handover guard to
        // suppress ping-pong (a UE handed in then immediately handed back out).
        m_connectedNormallyAt = Simulator::Now();
        if (m_pendingRrcConnectionReconfiguration)
        {
            ScheduleRrcConnectionReconfiguration();
        }
        if (m_pendingStartDataRadioBearers && m_caSupportConfigured)
        {
            StartDataRadioBearers();
        }
    }
    break;

    case CONNECTION_RECONFIGURATION:
    case CONNECTION_REESTABLISHMENT:
    case HANDOVER_LEAVING:
    default:
        break;
    }
}

void
NrUeManager::StartHandoverJoiningTimer()
{
    NS_ASSERT_MSG(m_state == HANDOVER_JOINING, "unexpected state " << ToString(m_state));
    m_handoverJoiningTimeout = Simulator::Schedule(m_rrc->m_handoverJoiningTimeoutDuration,
                                                   &NrGnbRrc::HandoverJoiningTimeout,
                                                   m_rrc,
                                                   m_rnti);
}

NrRrcSap::NonCriticalExtensionConfiguration
NrUeManager::BuildNonCriticalExtensionConfigurationCa()
{
    NS_LOG_FUNCTION(this);
    NrRrcSap::NonCriticalExtensionConfiguration ncec;

    for (auto& it : m_rrc->m_componentCarrierPhyConf)
    {
        uint8_t ccId = it.first;

        if (ccId == m_componentCarrierId)
        {
            // Skip primary CC.
            continue;
        }
        else if (ccId < m_componentCarrierId)
        {
            // Shift all IDs below PCC forward so PCC can use CC ID 1.
            ccId++;
        }

        Ptr<BandwidthPartGnb> gnbCcm = it.second;
        NrRrcSap::SCellToAddMod component;
        component.sCellIndex = ccId;
        component.cellIdentification.physCellId = gnbCcm->GetCellId();
        component.cellIdentification.dlCarrierFreq = gnbCcm->GetArfcn();
        component.radioResourceConfigCommonSCell.haveNonUlConfiguration = true;
        component.radioResourceConfigCommonSCell.nonUlConfiguration.dlBandwidth =
            gnbCcm->GetDlBandwidth();
        component.radioResourceConfigCommonSCell.nonUlConfiguration.antennaInfoCommon
            .antennaPortsCount = 0;
        component.radioResourceConfigCommonSCell.nonUlConfiguration.pdschConfigCommon
            .referenceSignalPower = m_rrc->m_cphySapProvider.at(0)->GetReferenceSignalPower();
        component.radioResourceConfigCommonSCell.nonUlConfiguration.pdschConfigCommon.pb = 0;
        component.radioResourceConfigCommonSCell.haveUlConfiguration = true;
        component.radioResourceConfigCommonSCell.ulConfiguration.ulFreqInfo.ulCarrierFreq =
            gnbCcm->GetArfcn();
        component.radioResourceConfigCommonSCell.ulConfiguration.ulFreqInfo.ulBandwidth =
            gnbCcm->GetUlBandwidth();
        component.radioResourceConfigCommonSCell.ulConfiguration.ulPowerControlCommonSCell.alpha =
            0;
        // component.radioResourceConfigCommonSCell.ulConfiguration.soundingRsUlConfigCommon.type =
        // NrRrcSap::SoundingRsUlConfigDedicated::SETUP;
        component.radioResourceConfigCommonSCell.ulConfiguration.soundingRsUlConfigCommon
            .srsBandwidthConfig = 0;
        component.radioResourceConfigCommonSCell.ulConfiguration.soundingRsUlConfigCommon
            .srsSubframeConfig = 0;
        component.radioResourceConfigCommonSCell.ulConfiguration.prachConfigSCell.index = 0;

        component.haveRadioResourceConfigDedicatedSCell = true;
        component.radioResourceConfigDedicatedSCell.physicalConfigDedicatedSCell
            .haveNonUlConfiguration = true;
        component.radioResourceConfigDedicatedSCell.physicalConfigDedicatedSCell
            .haveAntennaInfoDedicated = true;
        component.radioResourceConfigDedicatedSCell.physicalConfigDedicatedSCell.antennaInfo
            .transmissionMode = m_rrc->m_defaultTransmissionMode;
        component.radioResourceConfigDedicatedSCell.physicalConfigDedicatedSCell
            .crossCarrierSchedulingConfig = false;
        component.radioResourceConfigDedicatedSCell.physicalConfigDedicatedSCell
            .havePdschConfigDedicated = true;
        component.radioResourceConfigDedicatedSCell.physicalConfigDedicatedSCell
            .pdschConfigDedicated.pa = NrRrcSap::PdschConfigDedicated::dB0;
        component.radioResourceConfigDedicatedSCell.physicalConfigDedicatedSCell
            .haveUlConfiguration = true;
        component.radioResourceConfigDedicatedSCell.physicalConfigDedicatedSCell
            .haveAntennaInfoUlDedicated = true;
        component.radioResourceConfigDedicatedSCell.physicalConfigDedicatedSCell.antennaInfoUl
            .transmissionMode = m_rrc->m_defaultTransmissionMode;
        component.radioResourceConfigDedicatedSCell.physicalConfigDedicatedSCell
            .pushConfigDedicatedSCell.nPuschIdentity = 0;
        component.radioResourceConfigDedicatedSCell.physicalConfigDedicatedSCell
            .ulPowerControlDedicatedSCell.pSrsOffset = 0;
        component.radioResourceConfigDedicatedSCell.physicalConfigDedicatedSCell
            .haveSoundingRsUlConfigDedicated = true;
        component.radioResourceConfigDedicatedSCell.physicalConfigDedicatedSCell
            .soundingRsUlConfigDedicated.srsConfigIndex = GetSrsConfigurationIndex();
        component.radioResourceConfigDedicatedSCell.physicalConfigDedicatedSCell
            .soundingRsUlConfigDedicated.type = NrRrcSap::SoundingRsUlConfigDedicated::SETUP;
        component.radioResourceConfigDedicatedSCell.physicalConfigDedicatedSCell
            .soundingRsUlConfigDedicated.srsBandwidth = 0;

        ncec.sCellToAddModList.push_back(component);
    }

    return ncec;
}

///////////////////////////////////////////
// gNB RRC methods
///////////////////////////////////////////

NS_OBJECT_ENSURE_REGISTERED(NrGnbRrc);

NrGnbRrc::NrGnbRrc()
    : m_x2SapProvider(nullptr),
      m_cmacSapProvider(0),
      m_handoverManagementSapProvider(nullptr),
      m_ccmRrcSapProvider(nullptr),
      m_anrSapProvider(nullptr),
      m_rrcSapUser(nullptr),
      m_macSapProvider(nullptr),
      m_s1SapProvider(nullptr),
      m_cphySapProvider(0),
      m_configured(false),
      m_lastAllocatedRnti(0),
      m_lastAllocatedConfigurationIndex(0),
      m_reconfigureUes(false),
      m_numberOfComponentCarriers(0),
      m_carriersConfigured(false),
      m_handoverDecisionDelay(Seconds(0)),
      m_handoverTriggeringDelay(Seconds(0))
{
    NS_LOG_FUNCTION(this);
    m_cmacSapUser.push_back(new GnbRrcMemberNrGnbCmacSapUser(this, 0));
    m_handoverManagementSapUser = new MemberNrHandoverManagementSapUser<NrGnbRrc>(this);
    m_anrSapUser = new MemberNrAnrSapUser<NrGnbRrc>(this);
    m_rrcSapProvider = new MemberNrGnbRrcSapProvider<NrGnbRrc>(this);
    m_x2SapUser = new NrEpcX2SpecificEpcX2SapUser<NrGnbRrc>(this);
    m_s1SapUser = new NrMemberEpcGnbS1SapUser<NrGnbRrc>(this);
    m_cphySapUser.push_back(new MemberNrGnbCphySapUser<NrGnbRrc>(this));
    m_ccmRrcSapUser = new MemberNrCcmRrcSapUser<NrGnbRrc>(this);
}

void
NrGnbRrc::ConfigureCarriers(std::map<uint8_t, Ptr<BandwidthPartGnb>> ccPhyConf)
{
    NS_ASSERT_MSG(!m_carriersConfigured, "Secondary carriers can be configured only once.");
    m_componentCarrierPhyConf = ccPhyConf;
    NS_ABORT_MSG_IF(m_numberOfComponentCarriers != m_componentCarrierPhyConf.size(),
                    " Number of component carriers "
                    "are not equal to the number of he component carrier configuration provided");

    for (uint16_t i = 1; i < m_numberOfComponentCarriers; i++)
    {
        m_cphySapUser.push_back(new MemberNrGnbCphySapUser<NrGnbRrc>(this));
        m_cmacSapUser.push_back(new GnbRrcMemberNrGnbCmacSapUser(this, i));
    }
    m_carriersConfigured = true;
    Object::DoInitialize();
}

NrGnbRrc::~NrGnbRrc()
{
    NS_LOG_FUNCTION(this);
}

void
NrGnbRrc::DoDispose()
{
    NS_LOG_FUNCTION(this);
    for (auto cphySapUser : m_cphySapUser)
    {
        delete cphySapUser;
    }
    m_cphySapUser.clear();
    for (auto cmacSapUser : m_cmacSapUser)
    {
        delete cmacSapUser;
    }
    m_cmacSapUser.clear();
    m_ueMap.clear();
    delete m_handoverManagementSapUser;
    delete m_ccmRrcSapUser;
    delete m_anrSapUser;
    delete m_rrcSapProvider;
    delete m_x2SapUser;
    delete m_s1SapUser;
}

TypeId
NrGnbRrc::GetTypeId()
{
    static TypeId tid =
        TypeId("ns3::NrGnbRrc")
            .SetParent<Object>()
            .SetGroupName("Nr")
            .AddConstructor<NrGnbRrc>()
            .AddTraceSource(
                "RxRrcConnectionReconfigurationCompleted",
                "Trace fired when the gNB RRC receives an RRC Connection "
                "Reconfiguration Complete message for the given UE.",
                MakeTraceSourceAccessor(&NrGnbRrc::m_rxRrcConnectionReconfigurationCompletedTrace),
                "uint16_t")
            .AddAttribute("UeMap",
                          "List of NrUeManager by C-RNTI.",
                          ObjectMapValue(),
                          MakeObjectMapAccessor(&NrGnbRrc::m_ueMap),
                          MakeObjectMapChecker<NrUeManager>())
            .AddAttribute("DefaultTransmissionMode",
                          "The default UEs' transmission mode (0: SISO)",
                          UintegerValue(0), // default tx-mode
                          MakeUintegerAccessor(&NrGnbRrc::m_defaultTransmissionMode),
                          MakeUintegerChecker<uint8_t>())
            .AddAttribute(
                "QosFlowToRlcMapping",
                "Specify which type of RLC will be used for each type of QoS flow.",
                EnumValue(RLC_SM_ALWAYS),
                MakeEnumAccessor<NrQosFlowToRlcMapping_t>(&NrGnbRrc::m_qosFlowToRlcMapping),
                MakeEnumChecker(RLC_SM_ALWAYS,
                                "RlcSmAlways",
                                RLC_UM_ALWAYS,
                                "RlcUmAlways",
                                RLC_AM_ALWAYS,
                                "RlcAmAlways",
                                PER_BASED,
                                "PacketErrorRateBased"))
            .AddAttribute("SystemInformationPeriodicity",
                          "The interval for sending system information (Time value)",
                          TimeValue(MilliSeconds(80)),
                          MakeTimeAccessor(&NrGnbRrc::m_systemInformationPeriodicity),
                          MakeTimeChecker())

            // Timeout related attributes
            .AddAttribute("ConnectionRequestTimeoutDuration",
                          "After a RA attempt, if no RRC CONNECTION REQUEST is "
                          "received before this time, the UE context is destroyed. "
                          "Must account for reception of RAR and transmission of "
                          "RRC CONNECTION REQUEST over UL GRANT. The value of this"
                          "timer should not be greater than T300 timer at UE RRC. "
                          "With a cell-specific NTN offset the Msg3 grant is delayed "
                          "by NrGnbPhy::CellSpecificKoffset, so the upper bound "
                          "matches the maximum T300 value.",
                          TimeValue(MilliSeconds(15)),
                          MakeTimeAccessor(&NrGnbRrc::m_connectionRequestTimeoutDuration),
                          MakeTimeChecker(MilliSeconds(1), MilliSeconds(2000)))
            .AddAttribute("ConnectionSetupTimeoutDuration",
                          "After accepting connection request, if no RRC CONNECTION "
                          "SETUP COMPLETE is received before this time, the UE "
                          "context is destroyed. Must account for the UE's reception "
                          "of RRC CONNECTION SETUP and transmission of RRC CONNECTION "
                          "SETUP COMPLETE.",
                          TimeValue(MilliSeconds(150)),
                          MakeTimeAccessor(&NrGnbRrc::m_connectionSetupTimeoutDuration),
                          MakeTimeChecker())
            .AddAttribute("ConnectionRejectedTimeoutDuration",
                          "Time to wait between sending a RRC CONNECTION REJECT and "
                          "destroying the UE context",
                          TimeValue(MilliSeconds(30)),
                          MakeTimeAccessor(&NrGnbRrc::m_connectionRejectedTimeoutDuration),
                          MakeTimeChecker())
            .AddAttribute("HandoverJoiningTimeoutDuration",
                          "After accepting a handover request, if no RRC CONNECTION "
                          "RECONFIGURATION COMPLETE is received before this time, the "
                          "UE context is destroyed. Must account for reception of "
                          "X2 HO REQ ACK by source eNB, transmission of the Handover "
                          "Command, non-contention-based random access and reception "
                          "of the RRC CONNECTION RECONFIGURATION COMPLETE message.",
                          TimeValue(MilliSeconds(200)),
                          MakeTimeAccessor(&NrGnbRrc::m_handoverJoiningTimeoutDuration),
                          MakeTimeChecker())
            .AddAttribute("HandoverMinTimeOfStay",
                          "Reversal-only ping-pong handover guard: a handover is suppressed "
                          "only if it would send the UE BACK to the cell it just came from "
                          "(the source of the handover that brought it here) less than this "
                          "long after arriving. This breaks A->B->A oscillation -- which the "
                          "A3 algorithm alone does not prevent when the net A3 margin is near "
                          "zero -- without stranding a UE that genuinely needs to move forward "
                          "(A->B->C is still allowed). 0 (the default) disables the guard.",
                          TimeValue(MilliSeconds(0)),
                          MakeTimeAccessor(&NrGnbRrc::m_handoverMinTimeOfStay),
                          MakeTimeChecker())
            .AddAttribute("HandoverLeavingTimeoutDuration",
                          "After issuing a Handover Command, if neither RRC "
                          "CONNECTION RE-ESTABLISHMENT nor X2 UE Context Release has "
                          "been previously received, the UE context is destroyed.",
                          TimeValue(MilliSeconds(500)),
                          MakeTimeAccessor(&NrGnbRrc::m_handoverLeavingTimeoutDuration),
                          MakeTimeChecker())

            // Cell selection related attribute
            .AddAttribute("QRxLevMin",
                          "One of information transmitted within the SIB1 message, "
                          "indicating the required minimum RSRP level that any UE must "
                          "receive from this cell before it is allowed to camp to this "
                          "cell. The default value -70 corresponds to -140 dBm and is "
                          "the lowest possible value as defined by Section 6.3.4 of "
                          "3GPP TS 36.133. This restriction, however, only applies to "
                          "initial cell selection and EPC-enabled simulation.",
                          TypeId::ATTR_GET | TypeId::ATTR_CONSTRUCT,
                          IntegerValue(-70),
                          MakeIntegerAccessor(&NrGnbRrc::m_qRxLevMin),
                          MakeIntegerChecker<int8_t>(-70, -22))
            .AddAttribute("NumberOfComponentCarriers",
                          "Number of Component Carriers",
                          UintegerValue(1),
                          MakeIntegerAccessor(&NrGnbRrc::m_numberOfComponentCarriers),
                          MakeIntegerChecker<int16_t>(nr::MIN_NO_CC, nr::MAX_NO_CC))

            // Handover related attributes
            .AddAttribute("AdmitHandoverRequest",
                          "Whether to admit an X2 handover request from another eNB",
                          BooleanValue(true),
                          MakeBooleanAccessor(&NrGnbRrc::m_admitHandoverRequest),
                          MakeBooleanChecker())
            .AddAttribute("AdmitRrcConnectionRequest",
                          "Whether to admit a connection request from a UE",
                          BooleanValue(true),
                          MakeBooleanAccessor(&NrGnbRrc::m_admitRrcConnectionRequest),
                          MakeBooleanChecker())
            .AddAttribute(
                "UseRrcReestablishment",
                "Whether to accept RRC connection reestablishment requests from UEs. "
                "When disabled, the gNB rejects reestablishment requests and clears UE context.",
                BooleanValue(true),
                MakeBooleanAccessor(&NrGnbRrc::m_useRrcReestablishment),
                MakeBooleanChecker())
            .AddAttribute("HandoverDecisionDelay",
                          "Time delay between receiving a measurement report and "
                          "forwarding it to the handover algorithm for decision making.",
                          TimeValue(MilliSeconds(0)), // 50 ms in TR 36.839
                          MakeTimeAccessor(&NrGnbRrc::m_handoverDecisionDelay),
                          MakeTimeChecker())
            .AddAttribute("HandoverTriggeringDelay",
                          "Time delay between the handover algorithm deciding to handover "
                          "and the gNB RRC actually triggering the handover procedure.",
                          TimeValue(MilliSeconds(0)), // 40 ms in TR 36.839
                          MakeTimeAccessor(&NrGnbRrc::m_handoverTriggeringDelay),
                          MakeTimeChecker())

            // UE measurements related attributes
            .AddAttribute("RsrpFilterCoefficient",
                          "Determines the strength of smoothing effect induced by "
                          "layer 3 filtering of RSRP in all attached UE; "
                          "if set to 0, no layer 3 filtering is applicable",
                          // i.e. the variable k in 3GPP TS 36.331 section 5.5.3.2
                          UintegerValue(4),
                          MakeUintegerAccessor(&NrGnbRrc::m_rsrpFilterCoefficient),
                          MakeUintegerChecker<uint8_t>(0))
            .AddAttribute("RsrqFilterCoefficient",
                          "Determines the strength of smoothing effect induced by "
                          "layer 3 filtering of RSRQ in all attached UE; "
                          "if set to 0, no layer 3 filtering is applicable",
                          // i.e. the variable k in 3GPP TS 36.331 section 5.5.3.2
                          UintegerValue(4),
                          MakeUintegerAccessor(&NrGnbRrc::m_rsrqFilterCoefficient),
                          MakeUintegerChecker<uint8_t>(0))

            // Trace sources
            .AddTraceSource("NewUeContext",
                            "Fired upon creation of a new UE context.",
                            MakeTraceSourceAccessor(&NrGnbRrc::m_newUeContextTrace),
                            "ns3::NrGnbRrc::NewUeContextTracedCallback")
            .AddTraceSource("ConnectionEstablished",
                            "Fired upon successful RRC connection establishment.",
                            MakeTraceSourceAccessor(&NrGnbRrc::m_connectionEstablishedTrace),
                            "ns3::NrGnbRrc::ConnectionHandoverTracedCallback")
            .AddTraceSource("ConnectionReconfiguration",
                            "trace fired upon RRC connection reconfiguration",
                            MakeTraceSourceAccessor(&NrGnbRrc::m_connectionReconfigurationTrace),
                            "ns3::NrGnbRrc::ConnectionHandoverTracedCallback")
            .AddTraceSource("HandoverStart",
                            "trace fired upon start of a handover procedure",
                            MakeTraceSourceAccessor(&NrGnbRrc::m_handoverStartTrace),
                            "ns3::NrGnbRrc::HandoverStartTracedCallback")
            .AddTraceSource("HandoverEndOk",
                            "trace fired upon successful termination of a handover procedure",
                            MakeTraceSourceAccessor(&NrGnbRrc::m_handoverEndOkTrace),
                            "ns3::NrGnbRrc::ConnectionHandoverTracedCallback")
            .AddTraceSource("HandoverTotalTime",
                            "total time from the A3 handover trigger (condition met at the "
                            "source gNB) to handover completion, fired at the source gNB "
                            "on successful handover",
                            MakeTraceSourceAccessor(&NrGnbRrc::m_handoverTotalTimeTrace),
                            "ns3::NrGnbRrc::HandoverTotalTimeTracedCallback")
            .AddTraceSource("RecvMeasurementReport",
                            "trace fired when measurement report is received",
                            MakeTraceSourceAccessor(&NrGnbRrc::m_recvMeasurementReportTrace),
                            "ns3::NrGnbRrc::ReceiveReportTracedCallback")
            .AddTraceSource("NotifyConnectionRelease",
                            "trace fired when an UE is released",
                            MakeTraceSourceAccessor(&NrGnbRrc::m_connectionReleaseTrace),
                            "ns3::NrGnbRrc::ConnectionHandoverTracedCallback")
            .AddTraceSource("RrcTimeout",
                            "trace fired when a timer expires",
                            MakeTraceSourceAccessor(&NrGnbRrc::m_rrcTimeoutTrace),
                            "ns3::NrGnbRrc::TimerExpiryTracedCallback")
            .AddTraceSource(
                "HandoverFailureNoPreamble",
                "trace fired upon handover failure due to non-allocation of non-contention based "
                "preamble at gNB for UE to handover due to max count reached",
                MakeTraceSourceAccessor(&NrGnbRrc::m_handoverFailureNoPreambleTrace),
                "ns3::NrGnbRrc::HandoverFailureTracedCallback")
            .AddTraceSource(
                "HandoverFailureMaxRach",
                "trace fired upon handover failure due to max RACH attempts from UE to target eNB",
                MakeTraceSourceAccessor(&NrGnbRrc::m_handoverFailureMaxRachTrace),
                "ns3::NrGnbRrc::HandoverFailureTracedCallback")
            .AddTraceSource(
                "HandoverFailureLeaving",
                "trace fired upon handover failure due to handover leaving timeout at source eNB",
                MakeTraceSourceAccessor(&NrGnbRrc::m_handoverFailureLeavingTrace),
                "ns3::NrGnbRrc::HandoverFailureTracedCallback")
            .AddTraceSource(
                "HandoverFailureJoining",
                "trace fired upon handover failure due to handover joining timeout at target eNB",
                MakeTraceSourceAccessor(&NrGnbRrc::m_handoverFailureJoiningTrace),
                "ns3::NrGnbRrc::HandoverFailureTracedCallback")
            .AddTraceSource(
                "X2DataForwardingDrop",
                "trace fired when a UE-data packet forwarded over X2-U is dropped because no "
                "matching X2-U TEID mapping exists (the packet arrived outside the handover "
                "data-forwarding window)",
                MakeTraceSourceAccessor(&NrGnbRrc::m_x2DataForwardingDropTrace),
                "ns3::NrGnbRrc::X2DataForwardingDropTracedCallback");
    return tid;
}

void
NrGnbRrc::SetEpcX2SapProvider(NrEpcX2SapProvider* s)
{
    NS_LOG_FUNCTION(this << s);
    m_x2SapProvider = s;
}

NrEpcX2SapUser*
NrGnbRrc::GetEpcX2SapUser()
{
    NS_LOG_FUNCTION(this);
    return m_x2SapUser;
}

void
NrGnbRrc::SetNrGnbCmacSapProvider(NrGnbCmacSapProvider* s)
{
    NS_LOG_FUNCTION(this << s);
    m_cmacSapProvider.at(0) = s;
}

void
NrGnbRrc::SetNrGnbCmacSapProvider(NrGnbCmacSapProvider* s, uint8_t pos)
{
    NS_LOG_FUNCTION(this << s);
    if (m_cmacSapProvider.size() > pos)
    {
        m_cmacSapProvider.at(pos) = s;
    }
    else
    {
        m_cmacSapProvider.push_back(s);
        NS_ABORT_IF(m_cmacSapProvider.size() - 1 != pos);
    }
}

NrGnbCmacSapUser*
NrGnbRrc::GetNrGnbCmacSapUser()
{
    NS_LOG_FUNCTION(this);
    return m_cmacSapUser.at(0);
}

NrGnbCmacSapUser*
NrGnbRrc::GetNrGnbCmacSapUser(uint8_t pos)
{
    NS_LOG_FUNCTION(this);
    return m_cmacSapUser.at(pos);
}

void
NrGnbRrc::SetNrHandoverManagementSapProvider(NrHandoverManagementSapProvider* s)
{
    NS_LOG_FUNCTION(this << s);
    m_handoverManagementSapProvider = s;
}

NrHandoverManagementSapUser*
NrGnbRrc::GetNrHandoverManagementSapUser()
{
    NS_LOG_FUNCTION(this);
    return m_handoverManagementSapUser;
}

void
NrGnbRrc::SetNrCcmRrcSapProvider(NrCcmRrcSapProvider* s)
{
    NS_LOG_FUNCTION(this << s);
    m_ccmRrcSapProvider = s;
}

NrCcmRrcSapUser*
NrGnbRrc::GetNrCcmRrcSapUser()
{
    NS_LOG_FUNCTION(this);
    return m_ccmRrcSapUser;
}

void
NrGnbRrc::SetNrAnrSapProvider(NrAnrSapProvider* s)
{
    NS_LOG_FUNCTION(this << s);
    m_anrSapProvider = s;
}

NrAnrSapUser*
NrGnbRrc::GetNrAnrSapUser()
{
    NS_LOG_FUNCTION(this);
    return m_anrSapUser;
}

void
NrGnbRrc::SetNrGnbRrcSapUser(NrGnbRrcSapUser* s)
{
    NS_LOG_FUNCTION(this << s);
    m_rrcSapUser = s;
}

NrGnbRrcSapProvider*
NrGnbRrc::GetNrGnbRrcSapProvider()
{
    NS_LOG_FUNCTION(this);
    return m_rrcSapProvider;
}

NrGnbRrcSapUser*
NrGnbRrc::GetNrGnbRrcSapUser()
{
    NS_LOG_FUNCTION(this);
    return m_rrcSapUser;
}

ns3::TracedCallback<uint16_t>
NrGnbRrc::GetRxRrcConnectionReconfigurationCompletedTrace() const
{
    NS_LOG_FUNCTION(this);
    return m_rxRrcConnectionReconfigurationCompletedTrace;
}

void
NrGnbRrc::SetNrMacSapProvider(NrMacSapProvider* s)
{
    NS_LOG_FUNCTION(this);
    m_macSapProvider = s;
}

void
NrGnbRrc::SetS1SapProvider(NrEpcGnbS1SapProvider* s)
{
    m_s1SapProvider = s;
}

NrEpcGnbS1SapUser*
NrGnbRrc::GetS1SapUser()
{
    return m_s1SapUser;
}

void
NrGnbRrc::SetNrGnbCphySapProvider(NrGnbCphySapProvider* s)
{
    NS_LOG_FUNCTION(this << s);
    if (!m_cphySapProvider.empty())
    {
        m_cphySapProvider.at(0) = s;
    }
    else
    {
        m_cphySapProvider.push_back(s);
    }
}

NrGnbCphySapUser*
NrGnbRrc::GetNrGnbCphySapUser()
{
    NS_LOG_FUNCTION(this);
    return m_cphySapUser.at(0);
}

void
NrGnbRrc::SetNrGnbCphySapProvider(NrGnbCphySapProvider* s, uint8_t pos)
{
    NS_LOG_FUNCTION(this << s);
    if (m_cphySapProvider.size() > pos)
    {
        m_cphySapProvider.at(pos) = s;
    }
    else
    {
        m_cphySapProvider.push_back(s);
        NS_ABORT_IF(m_cphySapProvider.size() - 1 != pos);
    }
}

NrGnbCphySapUser*
NrGnbRrc::GetNrGnbCphySapUser(uint8_t pos)
{
    NS_LOG_FUNCTION(this);
    return m_cphySapUser.at(pos);
}

bool
NrGnbRrc::HasUeManager(uint16_t rnti) const
{
    NS_LOG_FUNCTION(this << (uint32_t)rnti);
    auto it = m_ueMap.find(rnti);
    return (it != m_ueMap.end());
}

Ptr<NrUeManager>
NrGnbRrc::GetUeManager(uint16_t rnti)
{
    NS_LOG_FUNCTION(this << (uint32_t)rnti);
    NS_ASSERT(0 != rnti);
    auto it = m_ueMap.find(rnti);
    if (it == m_ueMap.end())
    {
        NS_LOG_WARN("UE manager for RNTI " << rnti << " not found");
        return nullptr;
    }
    return it->second;
}

std::map<uint16_t, Ptr<NrUeManager>>
NrGnbRrc::GetUeMap() const
{
    NS_LOG_FUNCTION(this);
    return m_ueMap;
}

std::vector<uint8_t>
NrGnbRrc::AddUeMeasReportConfig(NrRrcSap::ReportConfigEutra config)
{
    NS_LOG_FUNCTION(this);

    // SANITY CHECK
    // Each reporting configuration is linked to the gNB's own carriers
    // (m_numberOfComponentCarriers objects) plus every registered inter-frequency
    // neighbour measurement object (those with measObjectId beyond the own-carrier
    // range). The number of measurement identities must therefore equal the number
    // of reporting configurations times the number of linked measurement objects.

    std::size_t neighbourMeasObjects = 0;
    for (const auto& measObject : m_ueMeasConfig.measObjectToAddModList)
    {
        if (measObject.measObjectId > m_numberOfComponentCarriers)
        {
            neighbourMeasObjects++;
        }
    }
    NS_ASSERT_MSG(
        m_ueMeasConfig.measIdToAddModList.size() ==
            m_ueMeasConfig.reportConfigToAddModList.size() *
                (m_numberOfComponentCarriers + neighbourMeasObjects),
        "Measurement identities and reporting configuration should not have different quantity");

    if (Simulator::Now() != Seconds(0))
    {
        NS_FATAL_ERROR("AddUeMeasReportConfig may not be called after the simulation has run");
    }

    // INPUT VALIDATION

    switch (config.triggerQuantity)
    {
    case NrRrcSap::ReportConfigEutra::RSRP:
        if ((config.eventId == NrRrcSap::ReportConfigEutra::EVENT_A5) &&
            (config.threshold2.choice != NrRrcSap::ThresholdEutra::THRESHOLD_RSRP))
        {
            NS_FATAL_ERROR(
                "The given triggerQuantity (RSRP) does not match with the given threshold2.choice");
        }

        if (((config.eventId == NrRrcSap::ReportConfigEutra::EVENT_A1) ||
             (config.eventId == NrRrcSap::ReportConfigEutra::EVENT_A2) ||
             (config.eventId == NrRrcSap::ReportConfigEutra::EVENT_A4) ||
             (config.eventId == NrRrcSap::ReportConfigEutra::EVENT_A5)) &&
            (config.threshold1.choice != NrRrcSap::ThresholdEutra::THRESHOLD_RSRP))
        {
            NS_FATAL_ERROR(
                "The given triggerQuantity (RSRP) does not match with the given threshold1.choice");
        }
        break;

    case NrRrcSap::ReportConfigEutra::RSRQ:
        if ((config.eventId == NrRrcSap::ReportConfigEutra::EVENT_A5) &&
            (config.threshold2.choice != NrRrcSap::ThresholdEutra::THRESHOLD_RSRQ))
        {
            NS_FATAL_ERROR(
                "The given triggerQuantity (RSRQ) does not match with the given threshold2.choice");
        }

        if (((config.eventId == NrRrcSap::ReportConfigEutra::EVENT_A1) ||
             (config.eventId == NrRrcSap::ReportConfigEutra::EVENT_A2) ||
             (config.eventId == NrRrcSap::ReportConfigEutra::EVENT_A4) ||
             (config.eventId == NrRrcSap::ReportConfigEutra::EVENT_A5)) &&
            (config.threshold1.choice != NrRrcSap::ThresholdEutra::THRESHOLD_RSRQ))
        {
            NS_FATAL_ERROR(
                "The given triggerQuantity (RSRQ) does not match with the given threshold1.choice");
        }
        break;

    default:
        NS_FATAL_ERROR("unsupported triggerQuantity");
        break;
    }

    if (config.purpose != NrRrcSap::ReportConfigEutra::REPORT_STRONGEST_CELLS)
    {
        NS_FATAL_ERROR("Only REPORT_STRONGEST_CELLS purpose is supported");
    }

    if (config.reportQuantity != NrRrcSap::ReportConfigEutra::BOTH)
    {
        NS_LOG_WARN("reportQuantity = BOTH will be used instead of the given reportQuantity");
    }

    uint8_t nextId = m_ueMeasConfig.reportConfigToAddModList.size() + 1;

    // create the reporting configuration
    NrRrcSap::ReportConfigToAddMod reportConfig;
    reportConfig.reportConfigId = nextId;
    reportConfig.reportConfigEutra = config;

    // add reporting configuration to UE measurement configuration
    m_ueMeasConfig.reportConfigToAddModList.push_back(reportConfig);

    std::vector<uint8_t> measIds;

    // Create measurement identities, linking the reporting configuration to the
    // gNB's own carrier measurement objects (one per component carrier, with
    // predictable measObjectId 1..m_numberOfComponentCarriers). These objects
    // are created in ConfigureCell(), which may run after this method, so the
    // component carrier count is used rather than the current object list size.
    for (uint16_t componentCarrier = 0; componentCarrier < m_numberOfComponentCarriers;
         componentCarrier++)
    {
        NrRrcSap::MeasIdToAddMod measIdToAddMod;

        uint8_t measId = m_ueMeasConfig.measIdToAddModList.size() + 1;

        measIdToAddMod.measId = measId;
        measIdToAddMod.measObjectId = componentCarrier + 1;
        measIdToAddMod.reportConfigId = nextId;

        m_ueMeasConfig.measIdToAddModList.push_back(measIdToAddMod);
        measIds.push_back(measId);
    }

    // Additionally link the reporting configuration to every inter-frequency
    // neighbour measurement object registered via AddNeighbourMeasFrequency().
    // This lets a single report configuration (e.g. the A3 handover report)
    // evaluate neighbours on other carrier frequencies, enabling inter-frequency
    // handover. The returned measIds therefore cover both own and neighbour
    // frequencies, so the requesting algorithm recognises cross-frequency
    // measurement reports.
    for (const auto& measObject : m_ueMeasConfig.measObjectToAddModList)
    {
        if (measObject.measObjectId <= m_numberOfComponentCarriers)
        {
            continue; // own-carrier object, already linked above
        }

        NrRrcSap::MeasIdToAddMod measIdToAddMod;
        uint8_t measId = m_ueMeasConfig.measIdToAddModList.size() + 1;

        measIdToAddMod.measId = measId;
        measIdToAddMod.measObjectId = measObject.measObjectId;
        measIdToAddMod.reportConfigId = nextId;

        m_ueMeasConfig.measIdToAddModList.push_back(measIdToAddMod);
        measIds.push_back(measId);
    }

    return measIds;
}

void
NrGnbRrc::AddNeighbourMeasFrequency(uint32_t arfcn, uint8_t dlBandwidth)
{
    NS_LOG_FUNCTION(this << arfcn << +dlBandwidth);
    NS_ASSERT_MSG(!m_configured, "AddNeighbourMeasFrequency must be called before ConfigureCell()");

    // Ignore duplicates (a neighbour frequency may be registered more than once).
    if (m_neighbourMeasFreqs.find(arfcn) != m_neighbourMeasFreqs.end())
    {
        return;
    }
    m_neighbourMeasFreqs[arfcn] = dlBandwidth;

    // Create the inter-frequency measurement object immediately, with a
    // measObjectId placed after the gNB's own carrier objects (which use ids
    // 1..m_numberOfComponentCarriers, assigned in ConfigureCell). Doing this
    // before the handover algorithm registers its reporting configuration lets
    // AddUeMeasReportConfig() link the report configs to this neighbour object
    // as well, so cross-frequency neighbours are measured and reported.
    NrRrcSap::MeasObjectToAddMod measObject;
    measObject.measObjectId = m_numberOfComponentCarriers + m_neighbourMeasFreqs.size();
    measObject.measObjectEutra.carrierFreq = arfcn;
    measObject.measObjectEutra.allowedMeasBandwidth = dlBandwidth;
    measObject.measObjectEutra.presenceAntennaPort1 = false;
    measObject.measObjectEutra.neighCellConfig = 0;
    measObject.measObjectEutra.offsetFreq = 0;
    measObject.measObjectEutra.haveCellForWhichToReportCGI = false;
    m_ueMeasConfig.measObjectToAddModList.push_back(measObject);
}

void
NrGnbRrc::ConfigureCell(const std::map<uint8_t, Ptr<BandwidthPartGnb>>& ccPhyConf)
{
    {
        auto it = ccPhyConf.begin();
        NS_ASSERT(it != ccPhyConf.end());
        m_ulBandwidth = it->second->GetUlBandwidth();
        m_dlBandwidth = it->second->GetDlBandwidth();
        auto arfcn = it->second->GetArfcn();

        NS_LOG_FUNCTION(this << m_ulBandwidth << m_dlBandwidth << arfcn);
        NS_ASSERT_MSG(!m_configured, "NrGnbRrc::ConfigureCell called more than once");
    }
    for (const auto& it : ccPhyConf)
    {
        m_cphySapProvider.at(it.first)->SetBandwidth(it.second->GetUlBandwidth(),
                                                     it.second->GetDlBandwidth());
        m_cphySapProvider.at(it.first)->SetArfcn(it.second->GetArfcn());
        m_cphySapProvider.at(it.first)->SetCellId(it.second->GetCellId());
        m_cmacSapProvider.at(it.first)->ConfigureMac(it.second->GetUlBandwidth(),
                                                     it.second->GetDlBandwidth());
    }

    /*
     * Initializing the list of measurement objects.
     * One intra-frequency measurement object is created for each of this gNB's
     * own carrier frequencies (measObjectId 1..m_numberOfComponentCarriers).
     * Inter-frequency neighbour measurement objects, if any, were already added
     * to m_ueMeasConfig by AddNeighbourMeasFrequency() before this call, using
     * measObjectIds beyond the own-carrier range. Together they enable both
     * intra-frequency and inter-frequency (and, by extension, inter-numerology)
     * measurements and handover.
     */
    for (const auto& it : ccPhyConf)
    {
        NrRrcSap::MeasObjectToAddMod measObject;
        measObject.measObjectId = it.first + 1;
        measObject.measObjectEutra.carrierFreq = it.second->GetArfcn();
        measObject.measObjectEutra.allowedMeasBandwidth = it.second->GetDlBandwidth();
        measObject.measObjectEutra.presenceAntennaPort1 = false;
        measObject.measObjectEutra.neighCellConfig = 0;
        measObject.measObjectEutra.offsetFreq = 0;
        measObject.measObjectEutra.haveCellForWhichToReportCGI = false;

        m_ueMeasConfig.measObjectToAddModList.push_back(measObject);
    }

    m_ueMeasConfig.haveQuantityConfig = true;
    m_ueMeasConfig.quantityConfig.filterCoefficientRSRP = m_rsrpFilterCoefficient;
    m_ueMeasConfig.quantityConfig.filterCoefficientRSRQ = m_rsrqFilterCoefficient;
    // The NR PHY model measures all configured BWPs simultaneously, so no
    // measurement gaps are required for inter-frequency measurements. The flag
    // is kept false even when neighbour frequencies are registered.
    m_ueMeasConfig.haveMeasGapConfig = false;
    NS_LOG_INFO(this << " configured " << m_ueMeasConfig.measObjectToAddModList.size()
                     << " measurement objects (inter-frequency neighbours: "
                     << m_neighbourMeasFreqs.size() << ")");
    m_ueMeasConfig.haveSmeasure = false;
    m_ueMeasConfig.haveSpeedStatePars = false;

    // The UL carrier advertised in SIB1: a DL-only carrier points at the cell's
    // dedicated UL-only carrier (FDD); any UL-capable carrier points at itself
    Ptr<BandwidthPartGnb> fddUlCarrier;
    for (const auto& it : ccPhyConf)
    {
        if (!it.second->GetPhy()->HasDlSlot())
        {
            fddUlCarrier = it.second;
            break;
        }
    }

    m_sib1.clear();
    m_sib1.reserve(ccPhyConf.size());
    for (const auto& it : ccPhyConf)
    {
        // Enabling MIB transmission
        NrRrcSap::MasterInformationBlock mib;
        mib.numerology = it.second->GetPhy()->GetNumerology();
        mib.dlBandwidth = it.second->GetDlBandwidth();
        mib.systemFrameNumber = 0;
        m_cphySapProvider.at(it.first)->SetMasterInformationBlock(mib);

        // Enabling SIB1 transmission with default values
        NrRrcSap::SystemInformationBlockType1 sib1;
        sib1.cellAccessRelatedInfo.cellIdentity = it.second->GetCellId();
        sib1.cellAccessRelatedInfo.csgIndication = false;
        sib1.cellAccessRelatedInfo.csgIdentity = 0;
        sib1.cellAccessRelatedInfo.plmnIdentityInfo.plmnIdentity = 0; // not used
        sib1.cellSelectionInfo.qQualMin = -34;          // not used, set as minimum value
        sib1.cellSelectionInfo.qRxLevMin = m_qRxLevMin; // set as minimum value
        sib1.servingCellConfigCommon = BuildServingCellConfigCommon(it.second, fddUlCarrier);
        m_sib1.push_back(sib1);
        m_cphySapProvider.at(it.first)->SetSystemInformationBlockType1(sib1);
    }
    /*
     * Enabling transmission of other SIB. The first time System Information is
     * transmitted is arbitrarily assumed to be at +0.016s, and then it will be
     * regularly transmitted every 80 ms by default (set the
     * SystemInformationPeriodicity attribute to configure this).
     */
    Simulator::Schedule(MilliSeconds(16), &NrGnbRrc::SendSystemInformation, this);

    m_configured = true;
}

void
NrGnbRrc::SetCellId(uint16_t cellId)
{
    // update SIB1
    m_sib1.at(0).cellAccessRelatedInfo.cellIdentity = cellId;
    m_cphySapProvider.at(0)->SetSystemInformationBlockType1(m_sib1.at(0));
}

void
NrGnbRrc::SetCellId(uint16_t cellId, uint8_t ccIndex)
{
    // update SIB1
    m_sib1.at(ccIndex).cellAccessRelatedInfo.cellIdentity = cellId;
    m_cphySapProvider.at(ccIndex)->SetSystemInformationBlockType1(m_sib1.at(ccIndex));
}

uint8_t
NrGnbRrc::CellToComponentCarrierId(uint16_t cellId)
{
    NS_LOG_FUNCTION(this << cellId);
    for (auto& it : m_componentCarrierPhyConf)
    {
        if (it.second->GetCellId() == cellId)
        {
            return it.first;
        }
    }
    NS_FATAL_ERROR("Cell " << cellId << " not found in CC map");
}

uint16_t
NrGnbRrc::ComponentCarrierToCellId(uint8_t componentCarrierId)
{
    NS_LOG_FUNCTION(this << +componentCarrierId);
    return m_componentCarrierPhyConf.at(componentCarrierId)->GetCellId();
}

bool
NrGnbRrc::HasCellId(uint16_t cellId) const
{
    for (auto& it : m_componentCarrierPhyConf)
    {
        if (it.second->GetCellId() == cellId)
        {
            return true;
        }
    }
    return false;
}

bool
NrGnbRrc::HasBwpId(uint16_t bwpId) const
{
    for (auto& it : m_componentCarrierPhyConf)
    {
        if (it.second->GetBwpId() == bwpId)
        {
            return true;
        }
    }
    return false;
}

bool
NrGnbRrc::SendData(Ptr<Packet> packet)
{
    NS_LOG_FUNCTION(this << packet);
    NrQosFlowTag tag;
    bool found = packet->RemovePacketTag(tag);
    NS_ASSERT_MSG(found, "no NrQosFlowTag found in packet to be sent");
    Ptr<NrUeManager> ueManager = GetUeManager(tag.GetRnti());

    NS_LOG_INFO("Sending a packet of " << packet->GetSize() << " bytes to IMSI "
                                       << ueManager->GetImsi() << ", RNTI " << ueManager->GetRnti()
                                       << ", QFI " << (uint16_t)tag.GetQfi());
    ueManager->SendData(tag.GetQfi(), packet);

    return true;
}

void
NrGnbRrc::SetForwardUpCallback(Callback<void, Ptr<Packet>> cb)
{
    m_forwardUpCallback = cb;
}

void
NrGnbRrc::ConnectionRequestTimeout(uint16_t rnti)
{
    NS_LOG_FUNCTION(this << rnti);
    NS_ASSERT_MSG(GetUeManager(rnti)->GetState() == NrUeManager::INITIAL_RANDOM_ACCESS,
                  "ConnectionRequestTimeout in unexpected state "
                      << ToString(GetUeManager(rnti)->GetState()));
    m_rrcTimeoutTrace(GetUeManager(rnti)->GetImsi(),
                      rnti,
                      ComponentCarrierToCellId(GetUeManager(rnti)->GetComponentCarrierId()),
                      "ConnectionRequestTimeout");
    RemoveUe(rnti);
}

void
NrGnbRrc::ConnectionSetupTimeout(uint16_t rnti)
{
    NS_LOG_FUNCTION(this << rnti);
    NS_ASSERT_MSG(GetUeManager(rnti)->GetState() == NrUeManager::CONNECTION_SETUP,
                  "ConnectionSetupTimeout in unexpected state "
                      << ToString(GetUeManager(rnti)->GetState()));
    m_rrcTimeoutTrace(GetUeManager(rnti)->GetImsi(),
                      rnti,
                      ComponentCarrierToCellId(GetUeManager(rnti)->GetComponentCarrierId()),
                      "ConnectionSetupTimeout");
    RemoveUe(rnti);
}

void
NrGnbRrc::ConnectionRejectedTimeout(uint16_t rnti)
{
    NS_LOG_FUNCTION(this << rnti);
    NS_ASSERT_MSG(GetUeManager(rnti)->GetState() == NrUeManager::CONNECTION_REJECTED,
                  "ConnectionRejectedTimeout in unexpected state "
                      << ToString(GetUeManager(rnti)->GetState()));
    m_rrcTimeoutTrace(GetUeManager(rnti)->GetImsi(),
                      rnti,
                      ComponentCarrierToCellId(GetUeManager(rnti)->GetComponentCarrierId()),
                      "ConnectionRejectedTimeout");
    RemoveUe(rnti);
}

void
NrGnbRrc::HandoverJoiningTimeout(uint16_t rnti)
{
    NS_LOG_FUNCTION(this << rnti);
    NS_ASSERT_MSG(GetUeManager(rnti)->GetState() == NrUeManager::HANDOVER_JOINING,
                  "HandoverJoiningTimeout in unexpected state "
                      << ToString(GetUeManager(rnti)->GetState()));
    m_handoverFailureJoiningTrace(
        GetUeManager(rnti)->GetImsi(),
        rnti,
        ComponentCarrierToCellId(GetUeManager(rnti)->GetComponentCarrierId()));
    // check if the RNTI to be removed is not stale
    if (HasUeManager(rnti))
    {
        /**
         * When the handover joining timer expires at the target cell,
         * then notify the source cell to release the RRC connection and
         * delete the UE context at gNB and SGW/PGW. The
         * HandoverPreparationFailure message is reused to notify the source cell
         * through the X2 interface instead of creating a new message.
         */
        Ptr<NrUeManager> ueManager = GetUeManager(rnti);
        NrEpcX2Sap::HandoverPreparationFailureParams msg = ueManager->BuildHoPrepFailMsg();
        m_x2SapProvider->SendHandoverPreparationFailure(msg);
        RemoveUe(rnti);
    }
}

void
NrGnbRrc::HandoverLeavingTimeout(uint16_t rnti)
{
    NS_LOG_FUNCTION(this << rnti);
    NS_ASSERT_MSG(GetUeManager(rnti)->GetState() == NrUeManager::HANDOVER_LEAVING,
                  "HandoverLeavingTimeout in unexpected state "
                      << ToString(GetUeManager(rnti)->GetState()));
    m_handoverFailureLeavingTrace(
        GetUeManager(rnti)->GetImsi(),
        rnti,
        ComponentCarrierToCellId(GetUeManager(rnti)->GetComponentCarrierId()));
    // check if the RNTI to be removed is not stale
    if (HasUeManager(rnti))
    {
        /**
         * Send HO cancel msg to the target gNB and release the RRC connection
         * with the UE and also delete UE context at the source gNB and bearer
         * info at SGW and PGW.
         */
        Ptr<NrUeManager> ueManager = GetUeManager(rnti);
        NrEpcX2Sap::HandoverCancelParams msg = ueManager->BuildHoCancelMsg();
        m_x2SapProvider->SendHandoverCancel(msg);
        ueManager->SendRrcConnectionRelease();
    }
}

void
NrGnbRrc::SendHandoverRequest(uint16_t rnti, uint16_t cellId)
{
    NS_LOG_FUNCTION(this << rnti << cellId);
    NS_LOG_LOGIC("Request to send HANDOVER REQUEST");
    NS_ASSERT(m_configured);

    // Guards that protect GetUeManager() from crashing.
    // This path can be reached if SendHandoverRequest is called directly
    // (e.g. from A3 event triggers in the scheduler) rather than through
    // NrHelper::DoHandoverRequest.
    if (rnti == 0)
    {
        NS_LOG_WARN("NrGnbRrc::SendHandoverRequest: ignoring RNTI=0 "
                    "(UE disconnected). cellId="
                    << cellId);
        return;
    }

    if (!HasUeManager(rnti))
    {
        NS_LOG_WARN("NrGnbRrc::SendHandoverRequest: no UeManager for RNTI="
                    << rnti << ". UE context was already removed "
                    << "(T300 timeout / RLF / rejection). "
                    << "Ignoring HO to cellId=" << cellId);
        return;
    }

    Ptr<NrUeManager> ueManager = GetUeManager(rnti);
    ueManager->PrepareHandover(cellId);
}

void
NrGnbRrc::DoCompleteSetupUe(uint16_t rnti, NrGnbRrcSapProvider::CompleteSetupUeParameters params)
{
    NS_LOG_FUNCTION(this << rnti);
    GetUeManager(rnti)->CompleteSetupUe(params);
}

void
NrGnbRrc::DoRecvRrcConnectionRequest(uint16_t rnti, NrRrcSap::RrcConnectionRequest msg)
{
    NS_LOG_FUNCTION(this << rnti);
    GetUeManager(rnti)->RecvRrcConnectionRequest(msg);
}

void
NrGnbRrc::DoRecvRrcConnectionSetupCompleted(uint16_t rnti,
                                            NrRrcSap::RrcConnectionSetupCompleted msg)
{
    NS_LOG_FUNCTION(this << rnti);
    GetUeManager(rnti)->RecvRrcConnectionSetupCompleted(msg);
}

void
NrGnbRrc::DoRecvRrcConnectionReconfigurationCompleted(
    uint16_t rnti,
    NrRrcSap::RrcConnectionReconfigurationCompleted msg)
{
    NS_LOG_FUNCTION(this << rnti);
    if (!HasUeManager(rnti))
    {
        NS_LOG_WARN("DoRecvRrcConnectionReconfigurationCompleted: RNTI "
                    << rnti << " not found, likely post-HandoverJoiningTimeout race. Dropping.");
        return;
    }
    m_rxRrcConnectionReconfigurationCompletedTrace(rnti);
    GetUeManager(rnti)->RecvRrcConnectionReconfigurationCompleted(msg);
}

void
NrGnbRrc::DoRecvRrcConnectionReestablishmentRequest(
    uint16_t rnti,
    NrRrcSap::RrcConnectionReestablishmentRequest msg)
{
    NS_LOG_FUNCTION(this << rnti);
    GetUeManager(rnti)->RecvRrcConnectionReestablishmentRequest(msg);
}

void
NrGnbRrc::DoRecvRrcConnectionReestablishmentComplete(
    uint16_t rnti,
    NrRrcSap::RrcConnectionReestablishmentComplete msg)
{
    NS_LOG_FUNCTION(this << rnti);
    GetUeManager(rnti)->RecvRrcConnectionReestablishmentComplete(msg);
}

void
NrGnbRrc::DoRecvMeasurementReport(uint16_t rnti, NrRrcSap::MeasurementReport msg)
{
    NS_LOG_FUNCTION(this << rnti);
    if (m_handoverDecisionDelay.IsStrictlyPositive())
    {
        // Model the measurement-report processing (handover decision) delay by
        // delivering the report after m_handoverDecisionDelay. The delayed event
        // must go to DeliverMeasurementReport, not back here, or the report would
        // reschedule itself forever and never reach the UE manager.
        Simulator::Schedule(m_handoverDecisionDelay,
                            &NrGnbRrc::DeliverMeasurementReport,
                            this,
                            rnti,
                            msg);
        return;
    }
    DeliverMeasurementReport(rnti, msg);
}

void
NrGnbRrc::DeliverMeasurementReport(uint16_t rnti, NrRrcSap::MeasurementReport msg)
{
    NS_LOG_FUNCTION(this << rnti);
    // The UE may have detached or failed while the report was being delayed.
    if (!HasUeManager(rnti))
    {
        NS_LOG_WARN("UE with RNTI " << rnti
                                    << " was removed before the delayed measurement "
                                       "report could be processed; dropping report");
        return;
    }
    GetUeManager(rnti)->RecvMeasurementReport(msg);
}

void
NrGnbRrc::DoInitialContextSetupRequest(NrEpcGnbS1SapUser::InitialContextSetupRequestParameters msg)
{
    NS_LOG_FUNCTION(this);
    Ptr<NrUeManager> ueManager = GetUeManager(msg.rnti);
    ueManager->InitialContextSetupRequest();
}

void
NrGnbRrc::DoRecvIdealUeContextRemoveRequest(uint16_t rnti)
{
    NS_LOG_FUNCTION(this << rnti);

    // check if the RNTI to be removed is not stale
    if (HasUeManager(rnti))
    {
        Ptr<NrUeManager> ueManager = GetUeManager(rnti);

        if (ueManager->GetState() == NrUeManager::HANDOVER_JOINING)
        {
            m_handoverFailureMaxRachTrace(
                GetUeManager(rnti)->GetImsi(),
                rnti,
                ComponentCarrierToCellId(GetUeManager(rnti)->GetComponentCarrierId()));
            /**
             * During the HO, when the RACH failure due to the maximum number of
             * re-attempts is reached the UE request the target gNB to deletes its
             * context. Upon which, the target gNB sends handover preparation
             * failure to the source eNB.
             */
            NrEpcX2Sap::HandoverPreparationFailureParams msg = ueManager->BuildHoPrepFailMsg();
            m_x2SapProvider->SendHandoverPreparationFailure(msg);
        }

        GetUeManager(rnti)->RecvIdealUeContextRemoveRequest(rnti);
        // delete the UE context at the eNB
        RemoveUe(rnti);
    }
}

void
NrGnbRrc::DoRecvIdealBwpSwitchIndication(uint16_t rnti, uint8_t bwpId)
{
    NS_LOG_FUNCTION(this << rnti << +bwpId);

    if (!HasUeManager(rnti))
    {
        NS_LOG_WARN("BWP-switch indication for unknown/stale RNTI " << rnti);
        return;
    }
    NS_LOG_INFO("UE " << rnti << " reported same-cell primary BWP switch -> " << +bwpId
                      << "; updating gNB DL routing");
    // Track the UE's new primary BWP and re-point its DL scheduling to it.
    GetUeManager(rnti)->SetPrimaryBwp(bwpId);
}

void
NrGnbRrc::DoDataRadioBearerSetupRequest(
    NrEpcGnbS1SapUser::DataRadioBearerSetupRequestParameters request)
{
    NS_LOG_FUNCTION(this);
    Ptr<NrUeManager> ueManager = GetUeManager(request.rnti);
    ueManager->SetupDataRadioBearer(request.flow,
                                    request.qfi,
                                    request.gtpTeid,
                                    request.transportLayerAddress);
}

void
NrGnbRrc::DoPathSwitchRequestAcknowledge(
    NrEpcGnbS1SapUser::PathSwitchRequestAcknowledgeParameters params)
{
    NS_LOG_FUNCTION(this);
    Ptr<NrUeManager> ueManager = GetUeManager(params.rnti);
    ueManager->SendUeContextRelease();
}

void
NrGnbRrc::DoRecvHandoverRequest(NrEpcX2SapUser::HandoverRequestParams req)
{
    NS_LOG_FUNCTION(this);

    NS_LOG_LOGIC("Recv X2 message: HANDOVER REQUEST");

    NS_LOG_LOGIC("oldGnbUeX2apId = " << req.oldGnbUeX2apId);
    NS_LOG_LOGIC("sourceCellId = " << req.sourceCellId);
    NS_LOG_LOGIC("targetCellId = " << req.targetCellId);
    NS_LOG_LOGIC("mmeUeS1apId = " << req.mmeUeS1apId);

    // if no SRS index is available, then do not accept the handover
    if (!m_admitHandoverRequest || IsMaxSrsReached())
    {
        NS_LOG_INFO("rejecting handover request from cellId " << req.sourceCellId);
        NrEpcX2Sap::HandoverPreparationFailureParams res;
        res.oldGnbUeX2apId = req.oldGnbUeX2apId;
        res.sourceCellId = req.sourceCellId;
        res.targetCellId = req.targetCellId;
        res.cause = 0;
        res.criticalityDiagnostics = 0;
        m_x2SapProvider->SendHandoverPreparationFailure(res);
        return;
    }

    uint8_t componentCarrierId = CellToComponentCarrierId(req.targetCellId);
    uint16_t rnti = AddUe(NrUeManager::HANDOVER_JOINING, componentCarrierId);
    Ptr<NrUeManager> ueManager = GetUeManager(rnti);
    ueManager->SetSource(req.sourceCellId, req.oldGnbUeX2apId);
    ueManager->SetImsi(req.mmeUeS1apId);
    // The handover random access arrives on the cell's UL carrier, so the
    // non-contention preamble must be reserved on that carrier's MAC (which
    // differs from the target CC's for FDD)
    uint8_t ulComponentCarrierId = componentCarrierId;
    for (auto& it : m_componentCarrierPhyConf)
    {
        if (!it.second->GetPhy()->HasDlSlot())
        {
            ulComponentCarrierId = it.first;
            break;
        }
    }
    NrGnbCmacSapProvider::AllocateNcRaPreambleReturnValue anrcrv =
        m_cmacSapProvider.at(ulComponentCarrierId)->AllocateNcRaPreamble(rnti);
    if (!anrcrv.valid)
    {
        NS_LOG_INFO(
            this
            << " failed to allocate a preamble for non-contention based RA => cannot accept HO");
        m_handoverFailureNoPreambleTrace(
            GetUeManager(rnti)->GetImsi(),
            rnti,
            ComponentCarrierToCellId(GetUeManager(rnti)->GetComponentCarrierId()));
        /**
         * When the maximum non-contention based preambles is reached, then it is considered
         * handover has failed and source cell is notified to release the RRC connection and delete
         * the UE context at gNB and SGW/PGW.
         */
        ueManager = GetUeManager(rnti);
        NrEpcX2Sap::HandoverPreparationFailureParams msg = ueManager->BuildHoPrepFailMsg();
        m_x2SapProvider->SendHandoverPreparationFailure(msg);
        RemoveUe(rnti); // remove the UE from the target eNB
        return;
    }

    NrEpcX2SapProvider::HandoverRequestAckParams ackParams;
    ackParams.oldGnbUeX2apId = req.oldGnbUeX2apId;
    ackParams.newGnbUeX2apId = rnti;
    ackParams.sourceCellId = req.sourceCellId;
    ackParams.targetCellId = req.targetCellId;

    for (auto it = req.bearers.begin(); it != req.bearers.end(); ++it)
    {
        ueManager->SetupDataRadioBearer(it->erabLevelQosParameters,
                                        it->erabId,
                                        it->gtpTeid,
                                        it->transportLayerAddress);
        NrEpcX2Sap::ErabAdmittedItem i;
        i.erabId = it->erabId;
        ackParams.admittedBearers.push_back(i);
    }

    NrRrcSap::RrcConnectionReconfiguration handoverCommand =
        ueManager->GetRrcConnectionReconfigurationForHandover(componentCarrierId);

    handoverCommand.mobilityControlInfo.newUeIdentity = rnti;
    handoverCommand.mobilityControlInfo.haveRachConfigDedicated = true;
    handoverCommand.mobilityControlInfo.rachConfigDedicated.raPreambleIndex = anrcrv.raPreambleId;
    handoverCommand.mobilityControlInfo.rachConfigDedicated.raPrachMaskIndex =
        anrcrv.raPrachMaskIndex;

    NrGnbCmacSapProvider::RachConfig rc = m_cmacSapProvider.at(componentCarrierId)->GetRachConfig();
    handoverCommand.mobilityControlInfo.radioResourceConfigCommon.rachConfigCommon.preambleInfo
        .numberOfRaPreambles = rc.numberOfRaPreambles;
    handoverCommand.mobilityControlInfo.radioResourceConfigCommon.rachConfigCommon.raSupervisionInfo
        .preambleTransMax = rc.preambleTransMax;
    handoverCommand.mobilityControlInfo.radioResourceConfigCommon.rachConfigCommon.raSupervisionInfo
        .raResponseWindowSize = rc.raResponseWindowSize;
    handoverCommand.mobilityControlInfo.radioResourceConfigCommon.rachConfigCommon.txFailParam
        .connEstFailCount = rc.connEstFailCount;

    Ptr<Packet> encodedHandoverCommand = m_rrcSapUser->EncodeHandoverCommand(handoverCommand);

    ackParams.rrcContext = encodedHandoverCommand;

    NS_LOG_LOGIC("Send X2 message: HANDOVER REQUEST ACK");

    NS_LOG_LOGIC("oldGnbUeX2apId = " << ackParams.oldGnbUeX2apId);
    NS_LOG_LOGIC("newGnbUeX2apId = " << ackParams.newGnbUeX2apId);
    NS_LOG_LOGIC("sourceCellId = " << ackParams.sourceCellId);
    NS_LOG_LOGIC("targetCellId = " << ackParams.targetCellId);

    m_x2SapProvider->SendHandoverRequestAck(ackParams);

    // Arm the HANDOVER JOINING watchdog only now that the ACK is committed.
    ueManager->StartHandoverJoiningTimer();
}

void
NrGnbRrc::DoRecvHandoverRequestAck(NrEpcX2SapUser::HandoverRequestAckParams params)
{
    NS_LOG_FUNCTION(this);

    NS_LOG_LOGIC("Recv X2 message: HANDOVER REQUEST ACK");

    NS_LOG_LOGIC("oldGnbUeX2apId = " << params.oldGnbUeX2apId);
    NS_LOG_LOGIC("newGnbUeX2apId = " << params.newGnbUeX2apId);
    NS_LOG_LOGIC("sourceCellId = " << params.sourceCellId);
    NS_LOG_LOGIC("targetCellId = " << params.targetCellId);

    uint16_t rnti = params.oldGnbUeX2apId;
    Ptr<NrUeManager> ueManager = GetUeManager(rnti);
    ueManager->RecvHandoverRequestAck(params);
}

void
NrGnbRrc::DoRecvHandoverPreparationFailure(NrEpcX2SapUser::HandoverPreparationFailureParams params)
{
    NS_LOG_FUNCTION(this);

    NS_LOG_LOGIC("Recv X2 message: HANDOVER PREPARATION FAILURE");

    NS_LOG_LOGIC("oldGnbUeX2apId = " << params.oldGnbUeX2apId);
    NS_LOG_LOGIC("sourceCellId = " << params.sourceCellId);
    NS_LOG_LOGIC("targetCellId = " << params.targetCellId);
    NS_LOG_LOGIC("cause = " << params.cause);
    NS_LOG_LOGIC("criticalityDiagnostics = " << params.criticalityDiagnostics);

    uint16_t rnti = params.oldGnbUeX2apId;

    // check if the RNTI is not stale
    if (HasUeManager(rnti))
    {
        Ptr<NrUeManager> ueManager = GetUeManager(rnti);
        ueManager->RecvHandoverPreparationFailure(params.targetCellId);
    }
}

void
NrGnbRrc::DoRecvSnStatusTransfer(NrEpcX2SapUser::SnStatusTransferParams params)
{
    NS_LOG_FUNCTION(this);

    NS_LOG_LOGIC("Recv X2 message: SN STATUS TRANSFER");

    NS_LOG_LOGIC("oldGnbUeX2apId = " << params.oldGnbUeX2apId);
    NS_LOG_LOGIC("newGnbUeX2apId = " << params.newGnbUeX2apId);
    NS_LOG_LOGIC("erabsSubjectToStatusTransferList size = "
                 << params.erabsSubjectToStatusTransferList.size());

    uint16_t rnti = params.newGnbUeX2apId;

    // check if the RNTI to receive SN transfer for is not stale
    if (HasUeManager(rnti))
    {
        Ptr<NrUeManager> ueManager = GetUeManager(rnti);
        ueManager->RecvSnStatusTransfer(params);
    }
}

void
NrGnbRrc::DoRecvUeContextRelease(NrEpcX2SapUser::UeContextReleaseParams params)
{
    NS_LOG_FUNCTION(this);

    NS_LOG_LOGIC("Recv X2 message: UE CONTEXT RELEASE");

    NS_LOG_LOGIC("oldGnbUeX2apId = " << params.oldGnbUeX2apId);
    NS_LOG_LOGIC("newGnbUeX2apId = " << params.newGnbUeX2apId);

    uint16_t rnti = params.oldGnbUeX2apId;

    // check if the RNTI to be removed is not stale
    if (HasUeManager(rnti))
    {
        GetUeManager(rnti)->RecvUeContextRelease(params);
        RemoveUe(rnti);
    }
}

void
NrGnbRrc::DoRecvLoadInformation(NrEpcX2SapUser::LoadInformationParams params)
{
    NS_LOG_FUNCTION(this);

    NS_LOG_LOGIC("Recv X2 message: LOAD INFORMATION");

    NS_LOG_LOGIC("Number of cellInformationItems = " << params.cellInformationList.size());
}

void
NrGnbRrc::DoRecvResourceStatusUpdate(NrEpcX2SapUser::ResourceStatusUpdateParams params)
{
    NS_LOG_FUNCTION(this);

    NS_LOG_LOGIC("Recv X2 message: RESOURCE STATUS UPDATE");

    NS_LOG_LOGIC(
        "Number of cellMeasurementResultItems = " << params.cellMeasurementResultList.size());

    NS_ASSERT("Processing of RESOURCE STATUS UPDATE X2 message IS NOT IMPLEMENTED");
}

void
NrGnbRrc::DoRecvUeData(NrEpcX2SapUser::UeDataParams params)
{
    NS_LOG_FUNCTION(this);

    NS_LOG_LOGIC("Recv UE DATA FORWARDING through X2 interface");
    NS_LOG_LOGIC("sourceCellId = " << params.sourceCellId);
    NS_LOG_LOGIC("targetCellId = " << params.targetCellId);
    NS_LOG_LOGIC("gtpTeid = " << params.gtpTeid);
    NS_LOG_LOGIC("ueData = " << params.ueData);
    NS_LOG_LOGIC("ueData size = " << params.ueData->GetSize());

    auto teidInfoIt = m_x2uTeidInfoMap.find(params.gtpTeid);
    if (teidInfoIt != m_x2uTeidInfoMap.end())
    {
        GetUeManager(teidInfoIt->second.rnti)->SendData(teidInfoIt->second.drbid, params.ueData);
    }
    else
    {
        // The X2-U TEID mapping is registered on the target gNB while the UE
        // manager is in HANDOVER_JOINING state (SetupDataRadioBearer), and is
        // removed once the bearer is released after the path switch. Packets
        // forwarded over X2-U can race against either edge of that window:
        // they may arrive before the target bearer is set up, or after it has
        // been torn down at handover completion. Such a packet has no valid
        // target bearer, so drop it (the lost user-plane packet is recovered by
        // higher-layer retransmission) instead of aborting the simulation.
        NS_LOG_WARN("X2-U data received for unknown TEID "
                    << params.gtpTeid << " (no X2uTeidInfo): forwarded packet arrived outside the "
                    << "handover data-forwarding window; dropping it");
        // Notify interested observers (e.g. tests, flow monitors) so this drop
        // can be detected without parsing logs.
        m_x2DataForwardingDropTrace(params.sourceCellId,
                                    params.targetCellId,
                                    params.gtpTeid,
                                    params.ueData);
    }
}

void
NrGnbRrc::DoRecvHandoverCancel(NrEpcX2SapUser::HandoverCancelParams params)
{
    NS_LOG_FUNCTION(this);

    NS_LOG_LOGIC("Recv X2 message: HANDOVER CANCEL");

    NS_LOG_LOGIC("oldGnbUeX2apId = " << params.oldGnbUeX2apId);
    NS_LOG_LOGIC("newGnbUeX2apId = " << params.newGnbUeX2apId);
    NS_LOG_LOGIC("sourceCellId = " << params.sourceCellId);
    NS_LOG_LOGIC("targetCellId = " << params.targetCellId);
    NS_LOG_LOGIC("cause = " << params.cause);

    uint16_t rnti = params.newGnbUeX2apId;
    if (HasUeManager(rnti))
    {
        Ptr<NrUeManager> ueManager = GetUeManager(rnti);
        ueManager->RecvHandoverCancel(params);
        GetUeManager(rnti)->RecvIdealUeContextRemoveRequest(rnti);
    }
}

uint16_t
NrGnbRrc::DoAllocateTemporaryCellRnti(uint8_t componentCarrierId)
{
    NS_LOG_FUNCTION(this << +componentCarrierId);
    // if no SRS index is available, then do not create a new UE context.
    if (IsMaxSrsReached())
    {
        NS_LOG_WARN("Not enough SRS configuration indices, UE context not created");
        return 0; // return 0 since new RNTI was not assigned for the received preamble
    }
    return AddUe(NrUeManager::INITIAL_RANDOM_ACCESS, componentCarrierId);
}

void
NrGnbRrc::DoRrcConfigurationUpdateInd(NrGnbCmacSapUser::UeConfig cmacParams)
{
    Ptr<NrUeManager> ueManager = GetUeManager(cmacParams.m_rnti);
    ueManager->CmacUeConfigUpdateInd(cmacParams);
}

void
NrGnbRrc::DoNotifyLcConfigResult(uint16_t rnti, uint8_t lcid, bool success)
{
    NS_LOG_FUNCTION(this << (uint32_t)rnti);
    NS_FATAL_ERROR("not implemented");
}

std::vector<uint8_t>
NrGnbRrc::DoAddUeMeasReportConfigForHandover(NrRrcSap::ReportConfigEutra reportConfig)
{
    NS_LOG_FUNCTION(this);
    std::vector<uint8_t> measIds = AddUeMeasReportConfig(reportConfig);
    m_handoverMeasIds.insert(measIds.begin(), measIds.end());
    return measIds;
}

uint8_t
NrGnbRrc::DoAddUeMeasReportConfigForComponentCarrier(NrRrcSap::ReportConfigEutra reportConfig)
{
    NS_LOG_FUNCTION(this);
    uint8_t measId = AddUeMeasReportConfig(reportConfig).at(0);
    m_componentCarrierMeasIds.insert(measId);
    return measId;
}

void
NrGnbRrc::DoSetNumberOfComponentCarriers(uint16_t numberOfComponentCarriers)
{
    m_numberOfComponentCarriers = numberOfComponentCarriers;
}

void
NrGnbRrc::DoTriggerHandover(uint16_t rnti, uint16_t targetCellId)
{
    NS_LOG_FUNCTION(this << rnti << targetCellId);

    // Stamp the A3-trigger instant (condition met at the source gNB) so the total
    // handover time can be measured when the handover completes. This precedes the
    // triggering delay, so that delay is included in the reported total.
    if (HasUeManager(rnti))
    {
        m_handoverTriggerTime[GetUeManager(rnti)->GetImsi()] = Simulator::Now();
    }

    if (m_handoverTriggeringDelay.IsStrictlyPositive())
    {
        NS_LOG_INFO("Scheduling handover for RNTI " << rnti << " to cell " << targetCellId
                                                    << " with delay " << m_handoverTriggeringDelay);
        // The delayed event must go to ExecuteHandover, not back here, or the
        // handover would reschedule itself forever and never execute.
        Simulator::Schedule(m_handoverTriggeringDelay,
                            &NrGnbRrc::ExecuteHandover,
                            this,
                            rnti,
                            targetCellId);
        return;
    }
    ExecuteHandover(rnti, targetCellId);
}

void
NrGnbRrc::ExecuteHandover(uint16_t rnti, uint16_t targetCellId)
{
    NS_LOG_FUNCTION(this << rnti << targetCellId);

    // The UE may have detached or failed while the handover was being delayed.
    if (!HasUeManager(rnti))
    {
        NS_LOG_WARN("UE with RNTI " << rnti
                                    << " was removed before the delayed handover could "
                                       "be executed; canceling handover");
        return;
    }

    bool isHandoverAllowed = true;

    Ptr<NrUeManager> ueManager = GetUeManager(rnti);
    NS_ASSERT_MSG(ueManager, "Cannot find UE context with RNTI " << rnti);

    if (m_anrSapProvider != nullptr && !HasCellId(targetCellId))
    {
        // ensure that proper neighbour relationship exists between source and target cells
        bool noHo = m_anrSapProvider->GetNoHo(targetCellId);
        bool noX2 = m_anrSapProvider->GetNoX2(targetCellId);
        NS_LOG_DEBUG(this << " cellId="
                          << ComponentCarrierToCellId(ueManager->GetComponentCarrierId())
                          << " targetCellId=" << targetCellId << " NRT.NoHo=" << noHo
                          << " NRT.NoX2=" << noX2);

        if (noHo || noX2)
        {
            isHandoverAllowed = false;
            NS_LOG_LOGIC(this << " handover to cell " << targetCellId << " is not allowed by ANR");
        }
    }

    if (ueManager->GetState() != NrUeManager::CONNECTED_NORMALLY)
    {
        isHandoverAllowed = false;
        NS_LOG_LOGIC(this << " handover is not allowed because the UE"
                          << " rnti=" << rnti << " is in " << ToString(ueManager->GetState())
                          << " state");
    }

    // Reversal-only ping-pong guard: suppress a handover only if it sends the UE BACK to
    // the cell it just came from (target == the source of the handover that brought the UE
    // here) within HandoverMinTimeOfStay of arriving. This breaks A->B->A oscillation -- the
    // A3 algorithm alone does not prevent it when the net A3 margin is near zero (e.g. a
    // small/negative offset with no hysteresis) -- WITHOUT stranding a UE that genuinely needs
    // to move forward (A->B->C is still allowed, unlike a blunt suppress-any-handover guard).
    if (isHandoverAllowed && m_handoverMinTimeOfStay.IsStrictlyPositive() &&
        targetCellId == ueManager->GetSourceCellId())
    {
        const Time timeOfStay = Simulator::Now() - ueManager->GetConnectedNormallyAt();
        if (timeOfStay < m_handoverMinTimeOfStay)
        {
            isHandoverAllowed = false;
            NS_LOG_LOGIC(this << " handover of rnti=" << rnti << " back to source cell "
                              << targetCellId << " suppressed by reversal ping-pong guard: "
                              << "time of stay " << timeOfStay.As(Time::MS) << " < "
                              << m_handoverMinTimeOfStay.As(Time::MS));
        }
    }

    if (isHandoverAllowed)
    {
        // initiate handover execution
        ueManager->PrepareHandover(targetCellId);
    }
    else
    {
        // Handover was triggered but suppressed: drop the pending trigger timestamp
        // so it does not leak or later mismatch a subsequent handover.
        m_handoverTriggerTime.erase(ueManager->GetImsi());
    }
}

uint8_t
NrGnbRrc::DoAddUeMeasReportConfigForAnr(NrRrcSap::ReportConfigEutra reportConfig)
{
    NS_LOG_FUNCTION(this);
    uint8_t measId = AddUeMeasReportConfig(reportConfig).at(0);
    m_anrMeasIds.insert(measId);
    return measId;
}

void
NrGnbRrc::DoSetPdschConfigDedicated(uint16_t rnti,
                                    NrRrcSap::PdschConfigDedicated pdschConfigDedicated)
{
    NS_LOG_FUNCTION(this);
    Ptr<NrUeManager> ueManager = GetUeManager(rnti);
    ueManager->SetPdschConfigDedicated(pdschConfigDedicated);
}

void
NrGnbRrc::DoSendLoadInformation(NrEpcX2Sap::LoadInformationParams params)
{
    NS_LOG_FUNCTION(this);

    m_x2SapProvider->SendLoadInformation(params);
}

uint16_t
NrGnbRrc::AddUe(NrUeManager::State state, uint8_t componentCarrierId)
{
    NS_LOG_FUNCTION(this);
    bool found = false;
    uint16_t rnti;
    for (rnti = m_lastAllocatedRnti + 1; (rnti != m_lastAllocatedRnti - 1) && (!found); ++rnti)
    {
        if ((rnti != 0) && (m_ueMap.find(rnti) == m_ueMap.end()))
        {
            found = true;
            break;
        }
    }

    NS_ASSERT_MSG(found, "no more RNTIs available (do you have more than 65535 UEs in a cell?)");
    m_lastAllocatedRnti = rnti;
    Ptr<NrUeManager> ueManager = CreateObject<NrUeManager>(this, rnti, state, componentCarrierId);
    m_ccmRrcSapProvider->AddUe(rnti, (uint8_t)state);
    m_ueMap.insert(std::pair<uint16_t, Ptr<NrUeManager>>(rnti, ueManager));
    ueManager->Configure();

    const uint16_t cellId = ComponentCarrierToCellId(componentCarrierId);
    NS_LOG_DEBUG(this << " New UE RNTI " << rnti << " cellId " << cellId << " srs CI "
                      << ueManager->GetSrsConfigurationIndex());
    m_newUeContextTrace(cellId, rnti);
    return rnti;
}

void
NrGnbRrc::RemoveUe(uint16_t rnti)
{
    NS_LOG_FUNCTION(this << (uint32_t)rnti);
    auto it = m_ueMap.find(rnti);
    NS_ASSERT_MSG(it != m_ueMap.end(), "request to remove UE info with unknown rnti " << rnti);
    uint64_t imsi = it->second->GetImsi();
    uint16_t srsCi = (*it).second->GetSrsConfigurationIndex();
    // Drop any pending handover-trigger timestamp for a UE that leaves without
    // completing a handover (e.g. handover failure), so the map does not leak.
    m_handoverTriggerTime.erase(imsi);
    // cancel pending events
    it->second->CancelPendingEvents();
    // fire trace upon connection release
    m_connectionReleaseTrace(imsi,
                             ComponentCarrierToCellId(it->second->GetComponentCarrierId()),
                             rnti);
    m_ueMap.erase(it);
    for (uint16_t i = 0; i < m_numberOfComponentCarriers; i++)
    {
        m_cmacSapProvider.at(i)->RemoveUe(rnti);
        m_cphySapProvider.at(i)->RemoveUe(rnti);
    }
    if (m_s1SapProvider != nullptr)
    {
        m_s1SapProvider->UeContextRelease(rnti);
    }
    m_ccmRrcSapProvider->RemoveUe(rnti);
    // need to do this after NrUeManager has been deleted
    if (srsCi != 0)
    {
        RemoveSrsConfigurationIndex(srsCi);
    }

    m_rrcSapUser->RemoveUe(rnti); // Remove UE context at RRC protocol
}

TypeId
NrGnbRrc::GetRlcType(NrQosFlow flow)
{
    switch (m_qosFlowToRlcMapping)
    {
    case RLC_SM_ALWAYS:
        return NrRlcSm::GetTypeId();

    case RLC_UM_ALWAYS:
        return NrRlcUm::GetTypeId();

    case RLC_AM_ALWAYS:
        return NrRlcAm::GetTypeId();

    case PER_BASED:
        if (flow.GetPacketErrorLossRate() > 1.0e-5)
        {
            return NrRlcUm::GetTypeId();
        }
        else
        {
            return NrRlcAm::GetTypeId();
        }

    default:
        return NrRlcSm::GetTypeId();
    }
}

void
NrGnbRrc::AddX2Neighbour(uint16_t cellId)
{
    NS_LOG_FUNCTION(this << cellId);

    if (m_anrSapProvider != nullptr)
    {
        m_anrSapProvider->AddNeighbourRelation(cellId);
    }
}

void
NrGnbRrc::SetCsgId(uint32_t csgId, bool csgIndication)
{
    NS_LOG_FUNCTION(this << csgId << csgIndication);
    for (std::size_t componentCarrierId = 0; componentCarrierId < m_sib1.size();
         componentCarrierId++)
    {
        m_sib1.at(componentCarrierId).cellAccessRelatedInfo.csgIdentity = csgId;
        m_sib1.at(componentCarrierId).cellAccessRelatedInfo.csgIndication = csgIndication;
        m_cphySapProvider.at(componentCarrierId)
            ->SetSystemInformationBlockType1(m_sib1.at(componentCarrierId));
    }
}

uint16_t
NrGnbRrc::GetNewSrsConfigurationIndex()
{
    NS_LOG_FUNCTION(this << m_ueSrsConfigurationIndexSet.size());

    uint16_t configIndex = 0;
    if (IsMaxSrsReached() && m_unusedUeSrsConfigurationIndexSet.empty())
    {
        // There are absolutely no more SRS offsets, and SRS periodicity cannot be further
        // increased, so we need to interrupt
        NS_ABORT_MSG("Out of SRS configuration indices");
    }
    else if (!IsMaxSrsReached() && m_unusedUeSrsConfigurationIndexSet.empty())
    {
        // We ran out of configuration indices, but we still can have more
        // since we can have more SRS offsets available, so create a new one
        configIndex = m_lastAllocatedConfigurationIndex++;
        m_ueSrsConfigurationIndexSet.emplace(m_lastAllocatedConfigurationIndex);
    }
    else
    {
        // We have available configuration indices, so use them
        auto it = m_unusedUeSrsConfigurationIndexSet.begin();
        configIndex = *it;
        m_unusedUeSrsConfigurationIndexSet.erase(it);
        m_ueSrsConfigurationIndexSet.emplace(configIndex);
    }
    return configIndex;
}

void
NrGnbRrc::RemoveSrsConfigurationIndex(uint16_t srcCi)
{
    NS_LOG_FUNCTION(this << srcCi);
    auto it = m_ueSrsConfigurationIndexSet.find(srcCi);
    NS_ASSERT_MSG(it != m_ueSrsConfigurationIndexSet.end(),
                  "request to remove unknown SRS CI " << srcCi);
    m_unusedUeSrsConfigurationIndexSet.emplace(*it);
    m_ueSrsConfigurationIndexSet.erase(it);
}

bool
NrGnbRrc::IsMaxSrsReached() const
{
    return m_cmacSapProvider.at(0)->IsMaxSrsReached();
}

uint8_t
NrGnbRrc::GetLogicalChannelGroup(NrQosFlow flow)
{
    if (flow.GetResourceType() > 0) // 1, 2 for GBR and DC-GBR
    {
        return 1;
    }
    else
    {
        return 2;
    }
}

uint8_t
NrGnbRrc::GetLogicalChannelPriority(NrQosFlow flow)
{
    return flow.GetPriority();
}

NrQosFlow::FiveQi
NrGnbRrc::GetLogicalChannelFiveQi(NrQosFlow flow)
{
    return flow.fiveQi;
}

void
NrGnbRrc::SendSystemInformation()
{
    // NS_LOG_FUNCTION (this);

    for (auto& it : m_componentCarrierPhyConf)
    {
        uint8_t ccId = it.first;

        NrRrcSap::SystemInformation si{};
        si.haveSib2 = true;
        si.sib2.freqInfo.ulCarrierFreq = it.second->GetArfcn();
        si.sib2.freqInfo.ulBandwidth = it.second->GetUlBandwidth();
        si.sib2.radioResourceConfigCommon.pdschConfigCommon.referenceSignalPower =
            m_cphySapProvider.at(ccId)->GetReferenceSignalPower();
        si.sib2.radioResourceConfigCommon.pdschConfigCommon.pb = 0;

        NrGnbCmacSapProvider::RachConfig rc = m_cmacSapProvider.at(ccId)->GetRachConfig();
        NrRrcSap::RachConfigCommon rachConfigCommon{};
        rachConfigCommon.preambleInfo.numberOfRaPreambles = rc.numberOfRaPreambles;
        rachConfigCommon.raSupervisionInfo.preambleTransMax = rc.preambleTransMax;
        rachConfigCommon.raSupervisionInfo.raResponseWindowSize = rc.raResponseWindowSize;
        rachConfigCommon.txFailParam.connEstFailCount = rc.connEstFailCount;
        si.sib2.radioResourceConfigCommon.rachConfigCommon = rachConfigCommon;

        m_rrcSapUser->SendSystemInformation(it.second->GetCellId(), si);
    }

    /*
     * For simplicity, we use the same periodicity for all SIBs. Note that in real
     * systems the periodicy of each SIBs could be different.
     */
    Simulator::Schedule(m_systemInformationPeriodicity, &NrGnbRrc::SendSystemInformation, this);
}

bool
NrGnbRrc::IsRandomAccessCompleted(uint16_t rnti)
{
    NS_LOG_FUNCTION(this << (uint32_t)rnti);
    Ptr<NrUeManager> ueManager = GetUeManager(rnti);
    switch (ueManager->GetState())
    {
    case NrUeManager::CONNECTED_NORMALLY:
    case NrUeManager::CONNECTION_RECONFIGURATION:
        return true;
    default:
        return false;
    }
}

} // namespace ns3
